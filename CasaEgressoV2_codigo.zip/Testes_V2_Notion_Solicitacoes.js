/** Testes de instalação/entrada. Não executam cadastro, abertura ou encerramento. */
function TESTE_NOTION_SOLICITACOES_01_INSTALACAO(){
 return NOTION_V2_VALIDAR_SOLICITACOES();
}
function TESTE_NOTION_SOLICITACOES_02_REGRAS(){
 const ss=n2Autorizar_(),testes=[];
 function garantir(cond,nome){if(!cond)throw new Error('Falhou: '+nome);testes.push({teste:nome,ok:true});}
 function bloquear(fn,nome){let erro=false;try{fn();}catch(e){erro=true;}garantir(erro,nome);}
 function modelo(){
  const props={};Object.keys(N3_MAPA_).forEach(k=>props[k]={type:'rich_text',rich_text:[]});
  ['Data de Nascimento','Data de Entrada','Data de Saída Prevista','Data de Saída Efetiva'].forEach(k=>props[k]={type:'date',date:null});
  props.Pessoa={type:'relation',relation:[]};props.Passagem={type:'relation',relation:[]};
  props['Ação']={type:'select',select:{name:'Cadastrar pessoa'}};props.Enviar={type:'checkbox',checkbox:true};
  const id=Object.keys(N3_AUTORES_)[0];
  return {id:'11111111-1111-1111-1111-111111111111',parent:{data_source_id:N3_SOURCE_},properties:props,
   created_by:{id:id},last_edited_by:{id:id}};
 }
 let p=modelo();garantir(n3Extrair_(p).acao==='Cadastrar pessoa','Ação conhecida');
 p=modelo();p.parent.data_source_id='outra-base';bloquear(()=>n3Extrair_(p),'Base externa bloqueada');
 p=modelo();p.properties['Ação'].select.name='Excluir pessoa';bloquear(()=>n3Extrair_(p),'Ação não permitida bloqueada');
 p=modelo();p.properties['Data de Entrada'].date={start:'2026-10-06T10:00:00-03:00'};bloquear(()=>n3Extrair_(p),'Data com horário bloqueada');
 p=modelo();p.properties.Pessoa.relation=[{id:'a'},{id:'b'}];bloquear(()=>n3Extrair_(p),'Duas pessoas bloqueadas');
 p=modelo();p.last_edited_by.id='outro-editor';bloquear(()=>n3Autor_(p,ss),'Editor divergente bloqueado');
 p=modelo();p.created_by.id=p.last_edited_by.id='desconhecido';bloquear(()=>n3Autor_(p,ss),'Autor sem vínculo bloqueado');
 p=modelo();const autor=n3Autor_(p,ss);
 garantir(autor.usuario.perfil==='ADMIN'&&autor.usuario.ativo,'Autor cadastrado como ADMIN ativo');
 const email=n3ComAutor_(autor,ss,()=>exigirAcessoPlanilhaV2_().usuario.email);
 garantir(email===autor.usuario.email,'Contexto do autor reconhecido pela segurança');
 garantir(contextoNotionSolicitacaoV2_===null,'Contexto removido após uso');
 const r={ok:true,testes:testes,gravouRegistros:false};console.log(JSON.stringify(r,null,2));return r;
}
