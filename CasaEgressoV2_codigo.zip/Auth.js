function currentUser_(){
  const email=userEmail_();
  if(!email) throw new Error("Não foi possível identificar o usuário Google.");
  const sh=getSpreadsheet_().getSheetByName("EQUIPE");
  if(!sh) throw new Error("A aba EQUIPE não existe.");
  const rec=findRowByField_(sh,"E-mail",email);
  if(!rec || String(rec.data["Ativo"]).toUpperCase()!=="TRUE") throw new Error("Usuário não cadastrado na equipe.");
  return rec.data;
}
function requireRole_(roles){
  const u=currentUser_();
  const p=String(u.Perfil||"").toUpperCase();
  if(!roles.map(String).map(x=>x.toUpperCase()).includes(p)) throw new Error("Perfil sem permissão: "+p);
  return u;
}
function withLock_(fn){
  const lock=LockService.getScriptLock(); lock.waitLock(30000);
  try{return fn();} finally{lock.releaseLock();}
}
