/** Portaria: requer interfaces anteriores, Visitantes e Veículos. */
function abrirPortariaV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Portaria')
    .setWidth(920).setHeight(720),'Casa • Portaria');
}
function uiConsultarPortariaV2() {
  exigirAcessoPlanilhaV2_();
  return {ok:true,presentes:serializarAcompV2_(obterVisitantesPresentesV2()),
    veiculosFora:serializarAcompV2_(obterVeiculosForaV2()),agora:agoraMovV2_(),fuso:configV2Core_().TIMEZONE};
}
function uiHistoricoPortariaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['tipo','chave']);
  if(!d.chave)throw new Error('Informe documento ou identificação do veículo.');
  if(d.tipo!=='Visitante'&&d.tipo!=='Veículo')throw new Error('Tipo de consulta inválido.');
  return {ok:true,registros:serializarAcompV2_(d.tipo==='Visitante'?obterRegistrosVisitanteV2(d.chave):obterHistoricoVeiculoV2(d.chave))};
}
function uiEntradaVisitanteV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['data','hora','nomeVisitante','documento','cpfVisitado','destinoMotivo','observacoes']);
  if(d.cpfVisitado){const p=obterPessoaV2PorCPF_(cpfUiV2_(d.cpfVisitado));if(!p)throw new Error('Pessoa visitada não encontrada pelo CPF.');d.idPessoa=p.ID_Pessoa;}
  const r=registrarEntradaVisitanteV2(d);
  return {ok:true,id:r.entrada.ID_Visitante,mensagem:'Entrada do visitante registrada.'};
}
function uiSaidaVisitanteV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['idEntrada','data','hora','observacoes']);
  const r=registrarSaidaVisitanteV2(d);
  return {ok:true,id:r.saida.ID_Visitante,reutilizado:!!r.reutilizado,mensagem:'Saída do visitante registrada.'};
}
function uiSaidaVeiculoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['data','hora','veiculo','condutor','km','destinoObjetivo','observacoes']);
  const r=registrarSaidaVeiculoV2(d);
  return {ok:true,id:r.saida.ID_VeiculoRegistro,mensagem:'Saída do veículo registrada.'};
}
function uiRetornoVeiculoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['idSaida','data','hora','condutor','km','observacoes']);
  const r=registrarRetornoVeiculoV2(d);
  return {ok:true,id:r.retorno.ID_VeiculoRegistro,reutilizado:!!r.reutilizado,distanciaKm:r.distanciaKm,
    mensagem:'Retorno registrado. Distância: '+r.distanciaKm+' km.'};
}
