/** Testes 85–87: somente leitura e validação; não criam tarefas nem executam rotinas. */
function TESTE_V2_85_VALIDAR_PAINEL_TAREFAS_ROTINAS() {
  const r=uiInicioV2();VALIDAR_TAREFAS_ROTINAS_V2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Tarefas_Rotinas').getContent();
  ['uiCriarTarefaV2','uiCriarRotinaV2','uiExecutarRotinaV2','uiStatusRotinaV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_86_CONSULTAR_TAREFAS_ROTINAS_INTERFACE() {
  const r=uiConsultarTarefasRotinasV2();
  if(!Array.isArray(r.tarefas)||!Array.isArray(r.rotinas))throw new Error('Listas inválidas.');
  const resultado={ok:true,tarefas:r.tarefas.length,rotinas:r.rotinas.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_87_VALIDAR_DADOS_TAREFAS_ROTINAS() {
  exigirAcessoPlanilhaV2_();
  const t={titulo:'Teste',responsavel:'Teste'},r={rotina:'Teste',responsavel:'Teste',frequencia:'Diária',proximaExecucao:'2026-10-05'};
  const casos=[['Título vazio',function(){validarTarefaTrV2_(Object.assign({},t,{titulo:''}));},/titulo/],
    ['Prioridade inválida',function(){validarTarefaTrV2_(Object.assign({},t,{prioridade:'Outra'}));},/Prioridade/],
    ['Prazo inexistente',function(){validarTarefaTrV2_(Object.assign({},t,{prazo:'31/02/2026'}));},/data inválida/],
    ['Responsável vazio',function(){validarRotinaTrV2_(Object.assign({},r,{responsavel:''}));},/responsavel/],
    ['Frequência inválida',function(){validarRotinaTrV2_(Object.assign({},r,{frequencia:'Outra'}));},/Frequência/]];
  const testes=casos.map(function(c){let erro;try{c[1]();}catch(e){erro=e;}
    if(!erro||!c[2].test(erro.message))throw new Error('Bloqueio não confirmado: '+c[0]);return {teste:c[0],bloqueado:true};});
  if(proximaDataRotinaV2_('31/01/2026','Mensal')!=='28/02/2026')throw new Error('Avanço mensal incorreto.');
  const resultado={ok:true,testes:testes,avancoMensalConferido:true,somenteLeitura:true};console.log(JSON.stringify(resultado,null,2));return resultado;
}
