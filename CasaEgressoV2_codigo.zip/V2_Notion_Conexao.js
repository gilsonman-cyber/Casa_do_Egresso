/** CASA V2 — CONEXÃO 1: Sheets -> Notion. Não recebe comandos nem grava no Sheets.
 * Adicionar como arquivo novo. Não substituir núcleo, segurança ou onOpen.
 * Credencial: propriedade de script CASA_V2_NOTION_TOKEN.
 */
const N2_BASES_ = {
  PESSOAS: {source:'16d563bc-a753-4cf0-befb-70ebbf8074fc', id:'ID_Pessoa', titulo:'Nome Completo'},
  PASSAGENS: {source:'7ab3c534-bc73-4add-aae6-e7f269ca60a3', id:'ID_Passagem', titulo:'ID_Passagem'}
};
const N2_PLANILHA_ = '1w1016P49nJJ-nUgXBZFODBtWUt5SsB5GcYmJ7q0gBxw';
const N2_VERSAO_API_ = '2025-09-03';

function n2Props_() { return PropertiesService.getScriptProperties(); }
function n2Token_() {
  const t = String(n2Props_().getProperty('CASA_V2_NOTION_TOKEN') || '').trim();
  if (!t || /[\r\n]/.test(t)) throw new Error('Configure CASA_V2_NOTION_TOKEN nas propriedades do script.');
  return t;
}
function n2Autorizar_() {
  const email = String(Session.getEffectiveUser().getEmail() || '').trim().toLowerCase();
  const autorizado = n2Props_().getProperty('CASA_V2_NOTION_EXECUTOR');
  if (!email || email !== autorizado) throw new Error('Executor não autorizado. Execute NOTION_V2_AUTORIZAR_EXECUTOR com o ADMIN.');
  if (String(configV2Core_().SPREADSHEET_ID) !== N2_PLANILHA_) throw new Error('Planilha do núcleo difere do destino desta conexão.');
  const ss = SpreadsheetApp.openById(N2_PLANILHA_);
  const equipe = ss.getSheetByName('EQUIPE');
  if (!equipe) throw new Error('EQUIPE ausente.');
  const v = equipe.getDataRange().getValues();
  autorizarSegV2_(email, registrosEquipeSegV2_(v[0], v.slice(1)));
  return ss;
}
function NOTION_V2_AUTORIZAR_EXECUTOR() {
  const c = exigirAcessoPlanilhaV2_();
  const efetivo = String(Session.getEffectiveUser().getEmail() || '').trim().toLowerCase();
  if (c.id !== N2_PLANILHA_ || c.usuario.email !== efetivo) throw new Error('Execute diretamente no editor, usando o ADMIN da base V2.');
  n2Props_().setProperty('CASA_V2_NOTION_EXECUTOR', efetivo);
  return {ok:true, executor:efetivo, modo:'Somente Sheets para Notion'};
}
function n2Api_(method, path, payload) {
  // Não repetir automaticamente mutações: uma resposta perdida pode ter sido gravada.
  Utilities.sleep(360);
  let response;
  try {
    response = UrlFetchApp.fetch('https://api.notion.com/v1/' + path, {
      method:method, contentType:'application/json', muteHttpExceptions:true, followRedirects:false,
      headers:{Authorization:'Bearer ' + n2Token_(), 'Notion-Version':N2_VERSAO_API_},
      ...(payload === undefined ? {} : {payload:JSON.stringify(payload)})
    });
  } catch (e) { throw new Error('Falha de transporte na API Notion. Consulte a pendência antes de repetir uma criação.'); }
  const code = response.getResponseCode();
  if (code < 200 || code >= 300) {
    // Não imprimir corpo da resposta, token ou dados pessoais.
    throw new Error('Notion HTTP ' + code + '. Confira credencial, acesso às bases ou limite de requisições.');
  }
  return JSON.parse(response.getContentText());
}
function n2Ler_(ss, nome) {
  const aba = ss.getSheetByName(nome);
  if (!aba) throw new Error('Aba ausente: ' + nome);
  const matriz = aba.getDataRange().getValues();
  const cab = matriz[0].map(v=>String(v).trim());
  if (cab.some(v=>!v) || new Set(cab).size !== cab.length) throw new Error('Cabeçalhos vazios ou duplicados: ' + nome);
  const b = N2_BASES_[nome];
  [b.id,b.titulo].forEach(c=>{if (!cab.includes(c)) throw new Error('Campo ausente: '+c);});
  const ids = new Set(), registros = [];
  matriz.slice(1).forEach(l=>{
    if (l.every(v=>v === '' || v === null)) return;
    const r = {}; cab.forEach((c,i)=>r[c]=l[i]);
    const id = String(r[b.id] || '').trim();
    if (!id || ids.has(id)) throw new Error('ID ausente ou duplicado em '+nome+'. Corrija a origem antes de sincronizar.');
    ids.add(id); registros.push(r);
  });
  return {cab:cab, registros:registros};
}
function n2Texto_(v) {
  const s = v === null || v === undefined ? '' : String(v);
  if (s.length > 100000) throw new Error('Texto excede capacidade deste conector.');
  const a=[];
  for (let i=0;i<s.length;) {
    let fim=Math.min(i+1900,s.length);
    if (fim<s.length && /[\uD800-\uDBFF]/.test(s[fim-1])) fim--;
    a.push({type:'text',text:{content:s.slice(i,fim)}});i=fim;
  }
  return a;
}
function n2Data_(v, campo) {
  if (v === '' || v === null || v === undefined) return null;
  const instante = ['Criado_Em','Atualizado_Em','Data de Cadastro'].includes(campo);
  if (Object.prototype.toString.call(v) === '[object Date]') {
    if (isNaN(v.getTime())) throw new Error('Data inválida: '+campo);
    return {start:instante ? v.toISOString() : Utilities.formatDate(v,configV2Core_().TIMEZONE,'yyyy-MM-dd')};
  }
  if (instante) {
    // Não interpretar strings locais ambíguas como UTC.
    if (!/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/.test(String(v))) throw new Error('Instante sem fuso: '+campo);
    const d=new Date(v);if(isNaN(d.getTime())) throw new Error('Instante inválido: '+campo);
    return {start:d.toISOString()};
  }
  return {start:dataAtendimentoV2_(v,campo).iso};
}
function n2Converter_(r, esquema, b) {
  const p={};
  Object.keys(r).forEach(c=>{
    const def=esquema.properties[c];
    if (!def) throw new Error('Campo do Sheets não existe no Notion: '+c);
    const v=r[c], vazio=v === '' || v === null || v === undefined;
    switch(def.type) {
      case 'title': p[c]={title:n2Texto_(v)}; break;
      case 'rich_text':
        // CPF numérico de 10 dígitos pode ter perdido o zero inicial na planilha.
        // Não inventar correção silenciosa; solicitar ajuste explícito na origem.
        if(c==='CPF' && typeof v==='number' && String(v).length!==11) throw new Error('CPF numérico sem 11 dígitos: corrija como texto na origem.');
        p[c]={rich_text:n2Texto_(v)}; break;
      case 'date': p[c]={date:n2Data_(v,c)}; break;
      case 'number':
        if(!vazio && !Number.isFinite(Number(v))) throw new Error('Número inválido: '+c);
        p[c]={number:vazio?null:Number(v)}; break;
      case 'url': p[c]={url:vazio?null:String(v)}; break;
      case 'select':
        if(!vazio && !def.select.options.some(o=>o.name===String(v))) throw new Error('Opção não prevista: '+c);
        p[c]={select:vazio?null:{name:String(v)}}; break;
      default: throw new Error('Tipo não suportado: '+c+' / '+def.type);
    }
  });
  if(!String(r[b.titulo]||'').trim()) throw new Error('Título vazio na origem.');
  p['Sincronização']={select:{name:'Confirmado'}};
  p['Última sincronização']={date:{start:new Date().toISOString()}};
  return p;
}
function n2Buscar_(b,id) {
  const tipo = b.id===b.titulo?'title':'rich_text';
  const f={property:b.id};f[tipo]={equals:String(id)};
  const r=n2Api_('post','data_sources/'+b.source+'/query',{filter:f,page_size:2});
  if (r.has_more || r.results.length>1) throw new Error('ID duplicado no Notion. Não será escolhido um registro arbitrariamente.');
  return r.results[0] || null;
}
function n2Gravar_(nome,r,esquema) {
  const b=N2_BASES_[nome], id=String(r[b.id]), prop=n2Props_();
  const properties=n2Converter_(r,esquema,b);
  if(nome==='PASSAGENS') {
    const pessoa=n2Buscar_(N2_BASES_.PESSOAS,String(r.ID_Pessoa));
    if(!pessoa) throw new Error('Pessoa ainda não sincronizada. Conclua PESSOAS primeiro.');
    properties['Pessoa vinculada']={relation:[{id:pessoa.id}]};
  }
  const existente=n2Buscar_(b,id);
  if(existente) {
    n2Api_('patch','pages/'+existente.id,{properties:properties});
    return 'atualizado';
  }
  // Diário persistido ANTES da requisição. Se houver timeout, bloqueia nova criação.
  prop.setProperty('CASA_V2_NOTION_CRIACAO_PENDENTE',JSON.stringify({base:nome,id:id,em:new Date().toISOString()}));
  n2Api_('post','pages',{parent:{type:'data_source_id',data_source_id:b.source},properties:properties});
  prop.deleteProperty('CASA_V2_NOTION_CRIACAO_PENDENTE');
  return 'criado';
}
function n2VerificarPendente_() {
  const s=n2Props_().getProperty('CASA_V2_NOTION_CRIACAO_PENDENTE');
  if(!s) return;
  const p=JSON.parse(s), b=N2_BASES_[p.base];
  if(!b) throw new Error('Pendência desconhecida. Revisão necessária.');
  if(n2Buscar_(b,p.id)) {
    n2Props_().deleteProperty('CASA_V2_NOTION_CRIACAO_PENDENTE');return;
  }
  throw new Error('Criação de resultado incerto ('+p.base+' / '+p.id+'). Não repetir automaticamente. Consulte o Notion e revise CASA_V2_NOTION_CRIACAO_PENDENTE.');
}
function n2Esquemas_() {
  const s={};Object.keys(N2_BASES_).forEach(n=>s[n]=n2Api_('get','data_sources/'+N2_BASES_[n].source));return s;
}
function NOTION_V2_VALIDAR_CONEXAO() {
  const ss=n2Autorizar_(), schemas=n2Esquemas_(), contagens={};
  Object.keys(N2_BASES_).forEach(n=>{
    const dados=n2Ler_(ss,n), schema=schemas[n];
    dados.cab.forEach(c=>{if(!schema.properties[c]) throw new Error('Campo ausente no Notion: '+n+'.'+c);});
    ['Sincronização','Última sincronização'].forEach(c=>{if(!schema.properties[c])throw new Error('Campo ausente: '+c);});
    dados.registros.forEach(r=>n2Converter_(r,schema,N2_BASES_[n]));
    contagens[n]=dados.registros.length;
  });
  const r={ok:true,modo:'Sheets para Notion',registros:contagens,gravouDados:false};
  console.log(JSON.stringify(r));return r;
}
function NOTION_V2_SINCRONIZAR_LOTE() {
  const lock=LockService.getScriptLock();
  if(!lock.tryLock(1000)) return {ok:false,motivo:'Outra execução do projeto está em andamento.'};
  try {
    const inicio=Date.now(),ss=n2Autorizar_(),prop=n2Props_();
    n2VerificarPendente_();
    const schemas=n2Esquemas_();
    let estado=JSON.parse(prop.getProperty('CASA_V2_NOTION_CURSOR')||'{"base":"PESSOAS","indice":0}');
    if(!N2_BASES_[estado.base] || !Number.isInteger(estado.indice) || estado.indice<0) throw new Error('Cursor inválido.');
    let feitos=0,criados=0,atualizados=0,ciclo=false;
    const dados={PESSOAS:n2Ler_(ss,'PESSOAS'),PASSAGENS:n2Ler_(ss,'PASSAGENS')};
    while(feitos<10 && Date.now()-inicio<200000) {
      const lista=dados[estado.base].registros;
      if(estado.indice>=lista.length) {
        if(estado.base==='PESSOAS') estado={base:'PASSAGENS',indice:0};
        else {estado={base:'PESSOAS',indice:0};ciclo=true;}
        prop.setProperty('CASA_V2_NOTION_CURSOR',JSON.stringify(estado));
        if(ciclo) break;else continue;
      }
      const resultado=n2Gravar_(estado.base,lista[estado.indice],schemas[estado.base]);
      if(resultado==='criado')criados++;else atualizados++;
      estado.indice++;feitos++;
      prop.setProperty('CASA_V2_NOTION_CURSOR',JSON.stringify(estado));
    }
    const r={ok:true,processados:feitos,criados:criados,atualizados:atualizados,cicloConcluido:ciclo,proximo:estado};
    console.log(JSON.stringify(r));return r;
  } finally {lock.releaseLock();}
}
function NOTION_V2_ATIVAR_ATUALIZACAO() {
  exigirAcessoPlanilhaV2_(); NOTION_V2_VALIDAR_CONEXAO();
  const fn='NOTION_V2_SINCRONIZAR_LOTE';
  if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()===fn)) ScriptApp.newTrigger(fn).timeBased().everyMinutes(5).create();
  return {ok:true,intervaloMinutos:5,modo:'Sheets para Notion'};
}
function NOTION_V2_PAUSAR_ATUALIZACAO() {
  exigirAcessoPlanilhaV2_();
  ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='NOTION_V2_SINCRONIZAR_LOTE').forEach(t=>ScriptApp.deleteTrigger(t));
  return {ok:true,pausado:true};
}
