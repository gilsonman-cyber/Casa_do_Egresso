/** Execute individualmente, em ordem. Nenhum teste grava na planilha.
 * Os testes negativos são simulações puras, sem trocar o usuário real.
 */
function TESTE_V2_64_VALIDAR_SEGURANCA() {
  const r = VALIDAR_SEGURANCA_V2();
  console.log(JSON.stringify(r, null, 2)); return r;
}
function TESTE_V2_65_CONFERIR_INTEGRACAO_NUCLEO() {
  const antes = chamadasSegV2_;
  const planilha = obterSpreadsheetV2Core_();
  if (chamadasSegV2_ <= antes) throw new Error('Substitua obterSpreadsheetV2Core_ conforme o guia.');
  const depois = chamadasSegV2_;
  const autor = usuarioV2Core_();
  if (chamadasSegV2_ <= depois) throw new Error('Substitua usuarioV2Core_ conforme o guia.');
  const c = exigirAcessoPlanilhaV2_();
  if (planilha.getId() !== c.id || autor !== c.usuario.email) throw new Error('Planilha ou autoria divergente.');
  const perfil = obterMeuPerfilV2();
  if (!perfil.ok || perfil.usuario.email !== autor) throw new Error('Integração com controles divergente.');
  const r = {ok: true, acessoNucleoProtegido: true, autoriaConfirmada: true,
    controlesIntegrados: true, email: autor, somenteLeitura: true};
  console.log(JSON.stringify(r, null, 2)); return r;
}
function TESTE_V2_66_BLOQUEAR_ACESSOS_INVALIDOS() {
  const admin = {'E-mail': 'admin@example.com', Nome: 'Teste', Perfil: 'ADMIN', Ativo: true};
  const casos = [
    ['Sem identidade', function() { autorizarSegV2_('', [admin]); }, /não identificado/],
    ['Não cadastrado', function() { autorizarSegV2_('outro@example.com', [admin]); }, /não cadastrado/],
    ['Inativo', function() { autorizarSegV2_('admin@example.com', [Object.assign({}, admin, {Ativo:false})]); }, /inativo/],
    ['Sem perfil ADMIN', function() { autorizarSegV2_('admin@example.com', [Object.assign({}, admin, {Perfil:'OUTRO'})]); }, /ADMIN/],
    ['E-mail duplicado', function() { autorizarSegV2_('admin@example.com', [admin, Object.assign({}, admin, {'E-mail':'ADMIN@example.com'})]); }, /duplicado/],
    ['Ativo inválido', function() { autorizarSegV2_('admin@example.com', [Object.assign({}, admin, {Ativo:'talvez'})]); }, /Ativo/],
    ['Cabeçalho ausente', function() { registrosEquipeSegV2_(['Nome'], []); }, /ausente/],
    ['Cabeçalho duplicado', function() { registrosEquipeSegV2_(['Nome','Nome'], []); }, /duplicado/]
  ];
  const testes = casos.map(function(c) {
    let erro = null;
    try { c[1](); } catch(e) { erro = e; }
    if (!erro || !c[2].test(erro.message)) throw new Error('Bloqueio não confirmado: '+c[0]+(erro ? ': '+erro.message : ''));
    return {teste: c[0], bloqueado: true};
  });
  const r = {ok: true, modo: 'Simulação sem alteração da EQUIPE', testes: testes};
  console.log(JSON.stringify(r, null, 2)); return r;
}
