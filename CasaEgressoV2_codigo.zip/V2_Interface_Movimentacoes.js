/** Painel de saídas e retornos. Requer interfaces anteriores e V2_Movimentacoes. */
function abrirMovimentacoesV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Movimentacoes')
    .setWidth(880).setHeight(700),'Casa • Movimentações');
}
function uiInicioMovimentacoesV2() {
  const r=uiInicioV2();r.agora=agoraMovV2_();r.fuso=configV2Core_().TIMEZONE;return r;
}
function serializarMovUiV2_(lista) {
  return lista.map(function(r){const copia=Object.assign({},r);
    ['Data/Hora Prevista de Retorno','Data/Hora Real de Retorno'].forEach(function(c){
      if(copia[c])copia[c]=lerMomentoMovV2_(copia[c],c).texto;
    });return serializarAcompV2_([copia])[0];});
}
function uiConsultarMovimentacoesV2(dados) {
  exigirAcessoPlanilhaV2_();const v=vinculoAcompV2_(dados);
  const passagem=obterPassagemV2PorId_(v.idPassagem);
  const movimentos=obterMovimentacoesPassagemV2(v.idPassagem);
  const pendentes=obterMovimentacoesPessoaV2(v.idPessoa).filter(function(r){return !textoMovV2_(r['Data/Hora Real de Retorno']);});
  return {ok:true,statusPassagem:passagem.Status,movimentacoes:serializarMovUiV2_(movimentos),
    pendentesPessoa:serializarMovUiV2_(pendentes),agora:agoraMovV2_()};
}
function uiRegistrarSaidaV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAcompV2_(dados,['data','hora','retornoPrevisto','destino','motivo','observacoes','justificativaHistorico']);
  d.historico=dados.historico===true;
  const r=registrarSaidaV2(d);
  return {ok:true,id:r.movimentacao['ID_Movimentação'],mensagem:'Saída registrada.'};
}
function uiRegistrarRetornoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAcompV2_(dados,['idMovimentacao','retornoEfetivo','observacoes']);
  const r=obterMovimentacaoV2PorId(d.idMovimentacao);
  if(!r||r.ID_Pessoa!==d.idPessoa||r.ID_Passagem!==d.idPassagem) throw new Error('Movimentação não pertence à pessoa e passagem selecionadas.');
  const result=registrarRetornoV2(d);
  return {ok:true,id:d.idMovimentacao,semAlteracao:!!result.semAlteracao,
    mensagem:result.semAlteracao?'Retorno já estava registrado.':'Retorno registrado.'};
}
