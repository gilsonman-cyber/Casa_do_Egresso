/** Execute 31 a 35. Cria apenas dois eventos para VEICULO-TESTE-V2-01. */
function fixtureVeiV2_(){
  return {veiculo:'VEICULO-TESTE-V2-01',condutor:'CONDUTOR TESTE V2',data:'30/09/2026',hora:'09:00',
    km:10000,destinoObjetivo:'[TESTE-VEI-V2-01] Deslocamento fictício',observacoes:'Saída fictícia para validação.'};
}
function saidaTesteVeiV2_(){
  const d=fixtureVeiV2_(),lista=obterHistoricoVeiculoV2(d.veiculo);
  if(lista.length>2||lista.some(function(r){return r.Condutor!==d.condutor||r['Destino / Objetivo']!==d.destinoObjetivo;})) {
    throw new Error('Histórico inesperado para o veículo fictício.');
  }return lista[0]||null;
}
function TESTE_V2_31_VALIDAR_VEICULOS(){
  const r=VALIDAR_VEICULOS_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_32_REGISTRAR_SAIDA_VEICULO(){
  const existente=saidaTesteVeiV2_();
  const r=existente?{ok:true,reutilizado:true,saida:existente}:registrarSaidaVeiculoV2(fixtureVeiV2_());
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_33_CONSULTAR_VEICULO_E_BLOQUEIO(){
  const saida=saidaTesteVeiV2_(),d=fixtureVeiV2_();if(!saida) throw new Error('Execute o teste 32.');
  const r=obterRegistroVeiculoV2PorId(saida.ID_VeiculoRegistro),historico=obterHistoricoVeiculoV2(d.veiculo);
  if(!r||r.Km!==d.km||r.Condutor!==d.condutor||r['Movimentação']!=='Saída') throw new Error('Divergência na saída gravada.');
  const fora=obterVeiculosForaV2().some(function(v){return v.ID_VeiculoRegistro===saida.ID_VeiculoRegistro;});
  const resultado={ok:true,consultaHistorico:true,veiculoFora:fora,saida:r};
  if(historico.length===1){
    if(!fora) throw new Error('Veículo deveria constar como fora.');
    let bloqueado=false;
    try{registrarSaidaVeiculoV2(d);}catch(e){if(String(e.message).indexOf('saída sem retorno')<0) throw e;bloqueado=true;}
    if(!bloqueado) throw new Error('Segunda saída foi aceita.');resultado.segundaSaidaBloqueada=true;
  }else if(fora){throw new Error('Veículo retornado ainda consta como fora.');}
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_34_REGISTRAR_RETORNO_VEICULO(){
  const saida=saidaTesteVeiV2_();if(!saida) throw new Error('Execute o teste 32.');
  const r=registrarRetornoVeiculoV2({idSaida:saida.ID_VeiculoRegistro,data:'30/09/2026',hora:'10:30',
    km:10025,observacoes:'Retorno fictício confirmado.'});
  const salvo=obterRegistroVeiculoV2PorId(r.retorno.ID_VeiculoRegistro);
  if(!salvo||salvo['Movimentação']!=='Retorno'||salvo.Km!==10025||r.distanciaKm!==25||
    obterHistoricoVeiculoV2(fixtureVeiV2_().veiculo).length!==2||
    obterRegistroVeiculoV2PorId(saida.ID_VeiculoRegistro)['Observações']!==fixtureVeiV2_().observacoes) {
    throw new Error('Falha no retorno, distância ou preservação da saída.');
  }
  if(obterVeiculosForaV2().some(function(v){return chaveVeiV2_(v['Veículo / Placa'])===chaveVeiV2_(saida['Veículo / Placa']);})) {
    throw new Error('Veículo ainda consta como fora.');
  }
  r.saidaPreservada=true;r.veiculoFora=false;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_35_BLOQUEAR_VEICULOS_INVALIDOS(){
  const d=fixtureVeiV2_(),casos=[
    {nome:'Veículo vazio',dados:{veiculo:''},erro:'Campo obrigatório: veiculo'},
    {nome:'Condutor vazio',dados:{condutor:''},erro:'Campo obrigatório: condutor'},
    {nome:'Km negativo',dados:{km:-1},erro:'Km inválido'},
    {nome:'Hora inválida',dados:{hora:'25:00'},erro:'hora inválida'},
    {nome:'Data inexistente',dados:{data:'31/02/2026'},erro:'data inválida'}
  ];
  const testes=casos.map(function(c){
    try{validarSaidaVeiV2_(Object.assign({},d,c.dados));}catch(e){
      if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;
    }throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const saida=saidaTesteVeiV2_();if(!saida) throw new Error('Execute o teste 32.');
  [{nome:'Km de retorno menor',km:9999,hora:'10:30',erro:'menor que o da saída'},
   {nome:'Retorno anterior à saída',km:10025,hora:'08:00',erro:'anterior à saída'}].forEach(function(c){
    let bloqueado=false;
    try{registrarRetornoVeiculoV2({idSaida:saida.ID_VeiculoRegistro,data:'30/09/2026',hora:c.hora,km:c.km});}
    catch(e){if(String(e.message).indexOf(c.erro)<0) throw e;bloqueado=true;}
    if(!bloqueado) throw new Error('Dados inválidos aceitos: '+c.nome);testes.push({teste:c.nome,bloqueado:true});
  });
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
