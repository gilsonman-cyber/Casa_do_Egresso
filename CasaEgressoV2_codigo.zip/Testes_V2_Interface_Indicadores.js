/** Testes 91–93: não gravam INDICADORES nem LOG. */
function TESTE_V2_91_VALIDAR_PAINEL_INDICADORES() {
  const r=uiInicioV2();const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Indicadores').getContent();
  ['uiConsultarIndicadoresV2','uiGravarIndicadoresV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_92_CONSULTAR_INDICADORES_INTERFACE() {
  const r=uiConsultarIndicadoresV2();
  if(r.indicadores.length!==9||r.gravado!==false)throw new Error('Resposta inválida.');
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_93_VALIDAR_VALORES_INDICADORES() {
  exigirAcessoPlanilhaV2_();const base={};V2_UI_INDICADORES.forEach(function(m){base[m[0]]=0;});
  base['Saldo financeiro realizado']=-10;
  if(prepararIndicadoresUiV2_(base)[8].valor!==-10)throw new Error('Saldo negativo válido foi alterado.');
  const casos=[['Ausente',function(){const b=Object.assign({},base);delete b['Pessoas ativas'];return b;}],
    ['Texto em vez de número',function(){return Object.assign({},base,{'Pessoas ativas':'1'});}],
    ['Contagem fracionária',function(){return Object.assign({},base,{'Pessoas ativas':1.5});}],
    ['Contagem negativa',function(){return Object.assign({},base,{'Tarefas pendentes':-1});}],
    ['Valor infinito',function(){return Object.assign({},base,{'Receitas realizadas':Infinity});}],
    ['Despesa negativa',function(){return Object.assign({},base,{'Despesas realizadas':-1});}]];
  const testes=casos.map(function(c){let erro;try{prepararIndicadoresUiV2_(c[1]());}catch(e){erro=e;}
    if(!erro||!/inválid/.test(erro.message))throw new Error('Bloqueio não confirmado: '+c[0]);
    return {teste:c[0],bloqueado:true};});
  const r={ok:true,testes:testes,saldoNegativoPreservado:true,somenteLeitura:true};console.log(JSON.stringify(r,null,2));return r;
}
