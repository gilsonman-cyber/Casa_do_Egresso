/** CONTROLES V2: EQUIPE (consulta), CONFIG, LOG e INDICADORES.
 * Novas operações públicas exigem usuário ativo cadastrado; ADMIN para configuração,
 * indicadores e validação. Não altera EQUIPE nem concede permissões.
 * IMPORTANTE: este arquivo não protege automaticamente os módulos anteriores.
 * Aplicação uniforme das permissões nos demais módulos será uma etapa separada.
 * CONFIG armazena parâmetros; não substitui CONFIG_V2_CORE nem muda o comportamento
 * dos módulos que ainda não consultam esses parâmetros. Não guardar senhas/tokens.
 * Indicadores incluem todos os registros, inclusive os fictícios de implantação.
 */
const V2_CTRL_SCHEMAS={
  EQUIPE:['E-mail','Nome','Perfil','Ativo'],CONFIG:['Parâmetro','Valor','Descrição'],
  LOG:['ID_Log','DataHora','Usuario','Perfil','Operacao','Entidade','ID_Registro','Resultado','Origem','Detalhes'],
  INDICADORES:['Indicador','Valor','Atualizado em']
};
function textoCtrlV2_(v){return v===undefined||v===null?'':String(v).trim();}
function seguroCtrlV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function estruturaCtrlV2_(nome){
  const aba=obterAbaV2Core_(nome);if(!aba.getLastColumn()) throw new Error(nome+' sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoCtrlV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em '+nome);
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);mapa[c]=i;
  });
  (V2_CTRL_SCHEMAS[nome]||[]).forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente em '+nome+': '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function linhasCtrlV2_(nome){
  const e=estruturaCtrlV2_(nome),n=e.aba.getLastRow()-1,r=[];if(n<1) return r;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i){
    if(linha.every(function(v){return textoCtrlV2_(v)==='';})) return;
    const obj={};e.cab.forEach(function(c,j){obj[c]=linha[j];});r.push({registro:obj,linha:i+2});
  });return r;
}
function ativoCtrlV2_(v){
  if(v===true||v===1||textoCtrlV2_(v).toUpperCase()==='TRUE') return true;
  if(v===false||v===0||textoCtrlV2_(v).toUpperCase()==='FALSE') return false;
  throw new Error('Ativo deve ser TRUE ou FALSE.');
}
function validarEquipeCtrlV2_(registros){
  const emails={};return registros.map(function(r){
    const email=textoCtrlV2_(r['E-mail']).toLowerCase(),nome=textoCtrlV2_(r.Nome),perfil=textoCtrlV2_(r.Perfil).toUpperCase();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('E-mail inválido em EQUIPE.');
    if(emails[email]) throw new Error('E-mail duplicado em EQUIPE.');emails[email]=true;
    if(!nome||!perfil) throw new Error('Nome e Perfil são obrigatórios em EQUIPE.');
    return {email:email,nome:nome,perfil:perfil,ativo:ativoCtrlV2_(r.Ativo)};
  });
}
function autorizarEquipeCtrlV2_(email,equipe,admin){
  email=textoCtrlV2_(email).toLowerCase();
  if(!email) throw new Error('Usuário não identificado. Execute pelo editor com a conta autorizada.');
  const usuario=equipe.filter(function(v){return v.email===email;})[0];
  if(!usuario||!usuario.ativo) throw new Error('Usuário não cadastrado ou inativo em EQUIPE.');
  if(admin&&usuario.perfil!=='ADMIN') throw new Error('Operação exige perfil ADMIN.');
  return usuario;
}
function usuarioControleV2_(admin){
  // Não usa getEffectiveUser: não substitui o usuário ativo pela conta do proprietário.
  const email=Session.getActiveUser().getEmail();
  const equipe=validarEquipeCtrlV2_(linhasCtrlV2_('EQUIPE').map(function(v){return v.registro;}));
  return autorizarEquipeCtrlV2_(email,equipe,admin);
}
function obterMeuPerfilV2(){return {ok:true,usuario:usuarioControleV2_(false)};}
function VALIDAR_CONTROLES_V2(){
  const usuario=usuarioControleV2_(true),r={ok:true,usuario:usuario};
  Object.keys(V2_CTRL_SCHEMAS).forEach(function(nome){
    const e=estruturaCtrlV2_(nome);r[nome]={camposObrigatorios:V2_CTRL_SCHEMAS[nome].length,registros:Math.max(0,e.aba.getLastRow()-1)};
  });return r;
}
function indicesUnicosCtrlV2_(linhas,campo){
  const mapa={};linhas.forEach(function(v){
    const chave=textoCtrlV2_(v.registro[campo]);
    if(!chave||Object.prototype.hasOwnProperty.call(mapa,chave)) throw new Error(campo+' vazio ou duplicado.');
    mapa[chave]=v;
  });return mapa;
}
function validarConfigCtrlV2_(dados){
  dados=dados||{};const chave=textoCtrlV2_(dados.parametro),descricao=textoCtrlV2_(dados.descricao),valor=dados.valor;
  if(!/^[A-Z][A-Z0-9_]{0,79}$/.test(chave)) throw new Error('Parâmetro inválido: use letras maiúsculas, números e sublinhado.');
  if(!descricao) throw new Error('Descrição da configuração é obrigatória.');
  if(['string','number','boolean'].indexOf(typeof valor)<0||(typeof valor==='number'&&!Number.isFinite(valor))) {
    throw new Error('Valor de configuração deve ser texto, número finito ou booleano.');
  }return {'Parâmetro':chave,'Valor':valor,'Descrição':descricao};
}
function registrarLogControleV2_(usuario,operacao,entidade,id,resultado,detalhes){
  const e=estruturaCtrlV2_('LOG'),r={ID_Log:gerarIdV2Core_('LOG'),DataHora:new Date(),Usuario:usuario.email,Perfil:usuario.perfil,
    Operacao:operacao,Entidade:entidade,ID_Registro:id,Resultado:resultado,Origem:'V2_Controles',Detalhes:JSON.stringify(detalhes)};
  e.aba.getRange(e.aba.getLastRow()+1,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroCtrlV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();return r.ID_Log;
}
function obterConfiguracaoV2(parametro){
  usuarioControleV2_(true);
  const mapa=indicesUnicosCtrlV2_(linhasCtrlV2_('CONFIG'),'Parâmetro');
  const chave=textoCtrlV2_(parametro);
  return Object.prototype.hasOwnProperty.call(mapa,chave)?mapa[chave].registro:null;
}
function definirConfiguracaoV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);let iniciou=false;
  try{
    const usuario=usuarioControleV2_(true),r=validarConfigCtrlV2_(dados),e=estruturaCtrlV2_('CONFIG');
    const mapa=indicesUnicosCtrlV2_(linhasCtrlV2_('CONFIG'),'Parâmetro');
    const existente=Object.prototype.hasOwnProperty.call(mapa,r['Parâmetro'])?mapa[r['Parâmetro']]:null;
    if(existente&&existente.registro.Valor===r.Valor&&existente.registro['Descrição']===r['Descrição']) {
      return {ok:true,semAlteracao:true,configuracao:existente.registro};
    }
    registrarLogControleV2_(usuario,'DEFINIR_CONFIG','CONFIG',r['Parâmetro'],'INICIADO',{existia:!!existente});iniciou=true;
    const n=existente?existente.linha:e.aba.getLastRow()+1;
    if(existente){
      ['Valor','Descrição'].forEach(function(c){e.aba.getRange(n,e.mapa[c]+1).setValue(seguroCtrlV2_(r[c]));});
    }else{
      e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroCtrlV2_(r[c]===undefined?'':r[c]);})]);
    }
    SpreadsheetApp.flush();
    const idLog=registrarLogControleV2_(usuario,'DEFINIR_CONFIG','CONFIG',r['Parâmetro'],'CONCLUIDO',{tipoValor:typeof r.Valor});
    return {ok:true,configuracao:r,idLog:idLog};
  }catch(e){
    if(iniciou) throw new Error('Confira CONFIG e LOG antes de repetir; a gravação pode ter sido parcial. '+e.message);throw e;
  }finally{lock.releaseLock();}
}
function calcularIndicadoresControleV2_(){
  const ler=function(nome,campos){
    const e=estruturaCtrlV2_(nome);
    campos.forEach(function(c){if(!Object.prototype.hasOwnProperty.call(e.mapa,c)) throw new Error('Campo ausente em '+nome+': '+c);});
    return linhasCtrlV2_(nome).map(function(v){return v.registro;});
  };
  const pessoas=ler('PESSOAS',['ID_Pessoa','Status da Pessoa']);
  const passagens=ler('PASSAGENS',['ID_Passagem','Status']);
  const atendimentos=ler('ATENDIMENTOS',['ID_Atendimento']);
  const encaminhamentos=ler('ENCAMINHAMENTOS',['ID_Encaminhamento','Status']);
  const tarefas=ler('TAREFAS',['ID_Tarefa','Status']),rotinas=ler('ROTINAS',['ID_Rotina','Status']);
  const financeiro=resumoFinanceiroV2();
  return {
    'Pessoas ativas':pessoas.filter(function(r){return r['Status da Pessoa']==='Ativa';}).length,
    'Passagens abertas':passagens.filter(function(r){return r.Status==='Aberta';}).length,
    'Atendimentos registrados':atendimentos.length,
    'Encaminhamentos pendentes':encaminhamentos.filter(function(r){return ['Pendente','Em andamento'].indexOf(r.Status)>=0;}).length,
    'Tarefas pendentes':tarefas.filter(function(r){return ['Pendente','Em andamento'].indexOf(r.Status)>=0;}).length,
    'Rotinas ativas':rotinas.filter(function(r){return r.Status==='Ativa';}).length,
    'Receitas realizadas':financeiro.realizado.entradas,
    'Despesas realizadas':financeiro.realizado.saidas,
    'Saldo financeiro realizado':financeiro.realizado.saldo
  };
}
function consultarIndicadoresV2(){
  usuarioControleV2_(true);return {ok:true,incluiDadosDeTeste:true,indicadores:calcularIndicadoresControleV2_()};
}
function atualizarIndicadoresV2(){
  const lock=LockService.getScriptLock();lock.waitLock(20000);let iniciou=false;
  try{
    const usuario=usuarioControleV2_(true),valores=calcularIndicadoresControleV2_(),e=estruturaCtrlV2_('INDICADORES');
    const mapa=indicesUnicosCtrlV2_(linhasCtrlV2_('INDICADORES'),'Indicador'),agora=new Date();
    registrarLogControleV2_(usuario,'ATUALIZAR_INDICADORES','INDICADORES','GERAL','INICIADO',{quantidade:Object.keys(valores).length});iniciou=true;
    Object.keys(valores).forEach(function(nome){
      const existente=Object.prototype.hasOwnProperty.call(mapa,nome)?mapa[nome]:null;
      if(existente){
        e.aba.getRange(existente.linha,e.mapa.Valor+1).setValue(valores[nome]);
        e.aba.getRange(existente.linha,e.mapa['Atualizado em']+1).setValue(agora);
      }else{
        const r={'Indicador':nome,'Valor':valores[nome],'Atualizado em':agora};
        e.aba.getRange(e.aba.getLastRow()+1,1,1,e.cab.length).setValues([e.cab.map(function(c){return r[c]===undefined?'':r[c];})]);
      }
    });
    SpreadsheetApp.flush();const idLog=registrarLogControleV2_(usuario,'ATUALIZAR_INDICADORES','INDICADORES','GERAL','CONCLUIDO',{quantidade:Object.keys(valores).length});
    return {ok:true,incluiDadosDeTeste:true,indicadores:valores,idLog:idLog};
  }catch(e){
    if(iniciou) throw new Error('Confira INDICADORES e LOG; atualização pode ter sido parcial. '+e.message);throw e;
  }finally{lock.releaseLock();}
}
