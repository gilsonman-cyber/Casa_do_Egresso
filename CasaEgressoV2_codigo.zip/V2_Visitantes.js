/** VISITANTES V2 — depende do núcleo, V2_Atendimentos e V2_Movimentacoes.
 * Uma linha por evento: Entrada ou Saída. ID_Visitante identifica o evento,
 * não a identidade permanente do visitante. Documento identifica a sequência.
 * Uma pessoa visitante pode ter somente uma entrada pendente de saída.
 * ID_Pessoa é opcional para visita institucional; Pessoa Visitada vem de PESSOAS.
 * Não cria pessoas, passagens, pastas ou colunas. Não controla autorização EQUIPE.
 */
const V2_VIS_CAMPOS=['ID_Visitante','Data','Hora','Nome do Visitante','Documento',
  'ID_Pessoa','Pessoa Visitada','Movimentação','Destino / Motivo','Observações','Usuário'];
function textoVisV2_(v) { return v===null||v===undefined?'':String(v).trim(); }
function documentoVisV2_(v) { return textoVisV2_(v).toUpperCase().replace(/[^A-Z0-9]/g,''); }
function seguroVisV2_(v) { return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v; }
function estruturaVisV2_() {
  const aba=obterAbaV2Core_('VISITANTES');
  if(!aba.getLastColumn()) throw new Error('VISITANTES sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoVisV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em VISITANTES.');
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);
    mapa[c]=i;
  });
  V2_VIS_CAMPOS.forEach(function(c){
    if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);
  });
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_VISITANTES_V2() {
  if(typeof momentoMovV2_!=='function'||typeof agoraMovV2_!=='function') throw new Error('Mantenha V2_Movimentacoes.gs no projeto.');
  const e=estruturaVisV2_();
  return {ok:true,aba:'VISITANTES',camposObrigatorios:11,registros:Math.max(0,e.aba.getLastRow()-1)};
}
function registrosVisV2_() {
  const e=estruturaVisV2_(),n=e.aba.getLastRow()-1;
  if(n<1) return [];
  const lista=[],ids={};
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha){
    if(linha.every(function(v){return textoVisV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,i){r[c]=linha[i];});
    const id=textoVisV2_(r.ID_Visitante);
    if(!id||ids[id]) throw new Error('ID_Visitante ausente ou duplicado.');
    ids[id]=true;lista.push(r);
  });
  return lista;
}
function obterRegistroVisitanteV2PorId(idRegistro) {
  const id=textoVisV2_(idRegistro);
  if(!id) throw new Error('ID_Visitante é obrigatório.');
  return registrosVisV2_().filter(function(r){return textoVisV2_(r.ID_Visitante)===id;})[0]||null;
}
function sequenciaVisV2_(documento,registros) {
  const doc=documentoVisV2_(documento);
  if(!doc) throw new Error('Documento do visitante é obrigatório.');
  const lista=(registros||registrosVisV2_()).filter(function(r){return documentoVisV2_(r.Documento)===doc;});
  let anterior='',entrada=null;
  lista.forEach(function(r,i){
    const hora=momentoMovV2_(r.Data,r.Hora,'Evento existente').chave;
    if(hora<anterior) throw new Error('Histórico do visitante fora de ordem cronológica.');
    anterior=hora;
    if(r['Movimentação']!==(i%2===0?'Entrada':'Saída')) throw new Error('Sequência de entrada/saída inconsistente.');
    if(i%2===0) entrada=r;
    else if(textoVisV2_(r.ID_Pessoa)!==textoVisV2_(entrada.ID_Pessoa)||r['Nome do Visitante']!==entrada['Nome do Visitante']) {
      throw new Error('Saída existente não corresponde à entrada do visitante.');
    }
  });
  return lista;
}
function obterRegistrosVisitanteV2(documento) { return sequenciaVisV2_(documento); }
function obterRegistrosVisitantesPessoaV2(idPessoa) {
  const id=textoVisV2_(idPessoa);
  if(!id||!obterPessoaV2PorId_(id)) throw new Error('Pessoa visitada não encontrada.');
  return registrosVisV2_().filter(function(r){return textoVisV2_(r.ID_Pessoa)===id;});
}
function obterVisitantesPresentesV2() {
  const registros=registrosVisV2_(),documentos={};
  registros.forEach(function(r){
    const doc=documentoVisV2_(r.Documento);
    if(!doc) throw new Error('Registro de visitante sem documento.');
    documentos[doc]=true;
  });
  const presentes=[];
  Object.keys(documentos).forEach(function(doc){
    const lista=sequenciaVisV2_(doc,registros);
    if(lista.length%2===1) presentes.push(lista[lista.length-1]);
  });
  return presentes;
}
function validarEntradaVisV2_(dados) {
  dados=dados||{};
  ['nomeVisitante','documento','destinoMotivo'].forEach(function(c){
    if(!textoVisV2_(dados[c])) throw new Error('Campo obrigatório: '+c);
  });
  if(!documentoVisV2_(dados.documento)) throw new Error('Documento sem caracteres válidos.');
  const momento=momentoMovV2_(dados.data,dados.hora,'Entrada do visitante');
  if(momento.chave>agoraMovV2_()) throw new Error('Entrada efetiva não pode ser futura.');
  const idPessoa=textoVisV2_(dados.idPessoa);
  let nomePessoa='';
  if(idPessoa){
    const pessoa=obterPessoaV2PorId_(idPessoa);
    if(!pessoa) throw new Error('Pessoa visitada não encontrada.');
    nomePessoa=pessoa['Nome Completo'];
  }
  return {'Data':momento.data,'Hora':momento.hora,'Nome do Visitante':textoVisV2_(dados.nomeVisitante),
    'Documento':textoVisV2_(dados.documento),'ID_Pessoa':idPessoa,'Pessoa Visitada':nomePessoa,
    'Movimentação':'Entrada','Destino / Motivo':textoVisV2_(dados.destinoMotivo),'Observações':textoVisV2_(dados.observacoes)};
}
function gravarEventoVisV2_(r) {
  const e=estruturaVisV2_();
  r.ID_Visitante=gerarIdV2Core_('VIS');
  if(obterRegistroVisitanteV2PorId(r.ID_Visitante)) throw new Error('ID já existente; tente novamente.');
  r['Usuário']=usuarioV2Core_();
  const n=e.aba.getLastRow()+1;
  ['Data','Hora','Documento'].forEach(function(c){e.aba.getRange(n,e.mapa[c]+1).setNumberFormat('@');});
  e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroVisV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();return r;
}
function registrarEntradaVisitanteV2(dados) {
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    estruturaVisV2_();
    const r=validarEntradaVisV2_(dados),historico=sequenciaVisV2_(r.Documento);
    if(historico.length%2===1) throw new Error('Visitante já possui entrada sem saída.');
    if(historico.length){
      const ultima=historico[historico.length-1];
      if(momentoMovV2_(r.Data,r.Hora,'Entrada').chave<momentoMovV2_(ultima.Data,ultima.Hora,'Última saída').chave) {
        throw new Error('Nova entrada anterior à última saída.');
      }
    }
    return {ok:true,entrada:gravarEventoVisV2_(r)};
  }finally{lock.releaseLock();}
}
function registrarSaidaVisitanteV2(dados) {
  dados=dados||{};
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const entrada=obterRegistroVisitanteV2PorId(dados.idEntrada);
    if(!entrada||entrada['Movimentação']!=='Entrada') throw new Error('Entrada do visitante não encontrada.');
    const momento=momentoMovV2_(dados.data,dados.hora,'Saída do visitante');
    if(momento.chave<momentoMovV2_(entrada.Data,entrada.Hora,'Entrada').chave) throw new Error('Saída anterior à entrada do visitante.');
    if(momento.chave>agoraMovV2_()) throw new Error('Saída efetiva não pode ser futura.');
    const lista=sequenciaVisV2_(entrada.Documento);
    const indice=lista.findIndex(function(r){return r.ID_Visitante===entrada.ID_Visitante;});
    if(indice<0) throw new Error('Entrada ausente no histórico.');
    const existente=lista[indice+1];
    if(existente){
      if(momentoMovV2_(existente.Data,existente.Hora,'Saída existente').chave!==momento.chave) {
        throw new Error('Saída já registrada com outro horário.');
      }
      return {ok:true,reutilizado:true,idEntrada:entrada.ID_Visitante,saida:existente};
    }
    const r=Object.assign({},entrada,{'Data':momento.data,'Hora':momento.hora,'Movimentação':'Saída',
      'Observações':['Saída vinculada à entrada '+entrada.ID_Visitante,textoVisV2_(dados.observacoes)].filter(Boolean).join('\n\n')});
    return {ok:true,idEntrada:entrada.ID_Visitante,saida:gravarEventoVisV2_(r)};
  }finally{lock.releaseLock();}
}
