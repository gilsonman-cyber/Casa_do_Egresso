/** FINANCEIRO V2. Depende do núcleo e V2_Atendimentos.
 * Valor gravado: Entrada positivo, Saída negativo (compatível com exportação Notion).
 * API recebe valor positivo; Tipo determina o sinal. Valores monetários em centavos.
 * Resumo separa Realizado e Previsto; Cancelado não compõe totais.
 * Data = data prevista ou efetiva conforme Status. Efetivação atualiza Data.
 * Não efetua pagamentos, não integra banco/Notion, não altera COMPRAS.
 * Usa LOG existente para intenção e conclusão das gravações; não há transação
 * atômica entre abas. Em falha, informa ID e exige consulta antes de nova tentativa.
 * Controle de permissões EQUIPE continua para etapa posterior.
 */
const V2_FIN_SCHEMAS={
  FINANCEIRO:['ID_Lancamento','Data','Tipo','Categoria','Descrição','Valor','Responsável','Status','Comprovante_Drive'],
  LOG:['ID_Log','DataHora','Usuario','Perfil','Operacao','Entidade','ID_Registro','Resultado','Origem','Detalhes']
};
function textoFinV2_(v){return v===null||v===undefined?'':String(v).trim();}
function seguroFinV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function estruturaFinV2_(nome){
  if(!Object.prototype.hasOwnProperty.call(V2_FIN_SCHEMAS,nome)) throw new Error('Aba financeira desconhecida.');
  const aba=obterAbaV2Core_(nome);if(!aba.getLastColumn()) throw new Error(nome+' sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoFinV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em '+nome);
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);mapa[c]=i;
  });
  V2_FIN_SCHEMAS[nome].forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente em '+nome+': '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_FINANCEIRO_V2(){
  if(typeof dataAtendimentoV2_!=='function') throw new Error('Mantenha V2_Atendimentos.gs no projeto.');
  const r={ok:true};Object.keys(V2_FIN_SCHEMAS).forEach(function(nome){
    const e=estruturaFinV2_(nome);r[nome]={camposObrigatorios:V2_FIN_SCHEMAS[nome].length,registros:Math.max(0,e.aba.getLastRow()-1)};
  });return r;
}
function centavosFinV2_(valor){
  if(typeof valor!=='number'&&!(typeof valor==='string'&&/^\d+(?:[.,]\d{1,2})?$/.test(valor.trim()))) {
    throw new Error('Valor inválido: use valor positivo sem separador de milhar, como 1234,56.');
  }
  const n=typeof valor==='number'?valor:Number(valor.trim().replace(',','.'));
  if(!Number.isFinite(n)||n<=0||n>1000000000000||Math.abs(n*100-Math.round(n*100))>0.00001) {
    throw new Error('Valor inválido: deve ser positivo, com até duas casas decimais.');
  }return Math.round(n*100);
}
function linhasFinV2_(){
  const e=estruturaFinV2_('FINANCEIRO'),n=e.aba.getLastRow()-1,lista=[],ids={};if(n<1) return lista;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i){
    if(linha.every(function(v){return textoFinV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,j){r[c]=linha[j];});
    const id=textoFinV2_(r.ID_Lancamento);if(!id||ids[id]) throw new Error('ID_Lancamento ausente ou duplicado.');
    ids[id]=true;lista.push({registro:r,linha:i+2});
  });return lista;
}
function localizarFinV2_(id){
  id=textoFinV2_(id);if(!id) throw new Error('ID_Lancamento é obrigatório.');
  return linhasFinV2_().filter(function(v){return v.registro.ID_Lancamento===id;})[0]||null;
}
function obterLancamentoFinanceiroV2PorId(id){const v=localizarFinV2_(id);return v?v.registro:null;}
function listarLancamentosFinanceirosV2(filtros){
  filtros=filtros||{};
  const inicio=filtros.dataInicio?dataAtendimentoV2_(filtros.dataInicio,'Data inicial').iso:'';
  const fim=filtros.dataFim?dataAtendimentoV2_(filtros.dataFim,'Data final').iso:'';
  if(inicio&&fim&&inicio>fim) throw new Error('Período de consulta inválido.');
  return linhasFinV2_().map(function(v){return v.registro;}).filter(function(r){
    const data=dataAtendimentoV2_(r.Data,'Data do lançamento').iso;
    return (!inicio||data>=inicio)&&(!fim||data<=fim)&&(!filtros.tipo||r.Tipo===filtros.tipo)&&
      (!filtros.status||r.Status===filtros.status)&&(!filtros.categoria||r.Categoria===filtros.categoria)&&
      (!filtros.responsavel||r['Responsável']===filtros.responsavel);
  });
}
function resumoFinanceiroV2(filtros){
  const totais={Realizado:{entradas:0,saidas:0},Previsto:{entradas:0,saidas:0}},lista=listarLancamentosFinanceirosV2(filtros);
  let cancelados=0;
  lista.forEach(function(r){
    if(['Entrada','Saída'].indexOf(r.Tipo)<0||['Realizado','Previsto','Cancelado'].indexOf(r.Status)<0) throw new Error('Tipo ou status inválido em '+r.ID_Lancamento);
    if(typeof r.Valor!=='number'||(r.Tipo==='Entrada'?r.Valor<=0:r.Valor>=0)) throw new Error('Sinal do valor incompatível em '+r.ID_Lancamento);
    const centavos=centavosFinV2_(Math.abs(r.Valor));
    if(r.Status==='Cancelado'){cancelados++;return;}
    const campo=r.Tipo==='Entrada'?'entradas':'saidas';
    totais[r.Status][campo]+=centavos;
    if(!Number.isSafeInteger(totais[r.Status][campo])) throw new Error('Total excede precisão monetária segura.');
  });
  const converter=function(t){return {entradas:t.entradas/100,saidas:t.saidas/100,saldo:(t.entradas-t.saidas)/100};};
  return {ok:true,realizado:converter(totais.Realizado),previsto:converter(totais.Previsto),cancelados:cancelados,registros:lista.length};
}
function comprovanteFinV2_(id){
  id=textoFinV2_(id);if(!id) return '';
  if(!/^[A-Za-z0-9_-]+$/.test(id)) throw new Error('Informe apenas o ID do comprovante.');
  let arquivo;try{arquivo=DriveApp.getFileById(id);}catch(e){throw new Error('Comprovante não encontrado ou sem acesso.');}
  if(arquivo.isTrashed()) throw new Error('Comprovante está na lixeira.');
  return arquivo.getUrl();
}
function validarLancamentoFinV2_(dados){
  dados=dados||{};
  ['categoria','descricao','responsavel'].forEach(function(c){if(!textoFinV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  const tipo=textoFinV2_(dados.tipo),status=textoFinV2_(dados.status)||'Realizado';
  if(['Entrada','Saída'].indexOf(tipo)<0) throw new Error('Tipo deve ser Entrada ou Saída.');
  if(['Realizado','Previsto'].indexOf(status)<0) throw new Error('Status inicial inválido.');
  const data=dataAtendimentoV2_(dados.data,'Data do lançamento');
  if(status==='Realizado'&&data.iso>Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')) {
    throw new Error('Lançamento realizado não pode ter data futura.');
  }
  return {'Data':data.br,'Tipo':tipo,'Categoria':textoFinV2_(dados.categoria),'Descrição':textoFinV2_(dados.descricao),
    'Valor':centavosFinV2_(dados.valor)/100*(tipo==='Saída'?-1:1),'Responsável':textoFinV2_(dados.responsavel),'Status':status};
}
function logFinV2_(operacao,id,resultado,detalhes){
  const e=estruturaFinV2_('LOG');
  const r={'ID_Log':gerarIdV2Core_('LOG'),'DataHora':new Date(),'Usuario':usuarioV2Core_(),'Perfil':'',
    'Operacao':operacao,'Entidade':'FINANCEIRO','ID_Registro':id,'Resultado':resultado,'Origem':'V2_Financeiro',
    'Detalhes':JSON.stringify(detalhes)};
  e.aba.getRange(e.aba.getLastRow()+1,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroFinV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();
}
function registrarLancamentoFinanceiroV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);let id='';
  try{
    VALIDAR_FINANCEIRO_V2();const e=estruturaFinV2_('FINANCEIRO'),r=validarLancamentoFinV2_(dados);
    r.Comprovante_Drive=comprovanteFinV2_(dados.idComprovanteDrive);
    id=gerarIdV2Core_('FIN');r.ID_Lancamento=id;
    if(localizarFinV2_(id)) throw new Error('ID já existente.');
    logFinV2_('CRIAR',id,'INICIADO',{depois:r});
    const n=e.aba.getLastRow()+1;
    e.aba.getRange(n,e.mapa.Data+1).setNumberFormat('@');
    e.aba.getRange(n,e.mapa.Valor+1).setNumberFormat('0.00');
    e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroFinV2_(r[c]===undefined?'':r[c]);})]);
    SpreadsheetApp.flush();logFinV2_('CRIAR',id,'CONCLUIDO',{depois:r});
    return {ok:true,lancamento:r};
  }catch(e){
    if(id) throw new Error('Operação não concluída integralmente. Consulte '+id+' em FINANCEIRO e LOG antes de repetir. Detalhe: '+e.message);
    throw e;
  }finally{lock.releaseLock();}
}
function atualizarStatusFinanceiroV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);let iniciou=false;
  try{
    VALIDAR_FINANCEIRO_V2();const e=estruturaFinV2_('FINANCEIRO'),achado=localizarFinV2_(dados.idLancamento);
    if(!achado) throw new Error('Lançamento não encontrado.');
    const antes=achado.registro,status=textoFinV2_(dados.status),motivo=textoFinV2_(dados.motivo);
    if(['Realizado','Cancelado'].indexOf(status)<0) throw new Error('Destino de status inválido.');
    if(['Previsto','Realizado','Cancelado'].indexOf(antes.Status)<0) throw new Error('Status atual inválido.');
    const depois=Object.assign({},antes);
    if(status==='Realizado'){
      const data=dataAtendimentoV2_(dados.dataEfetiva,'Data efetiva');
      if(data.iso>Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')) throw new Error('Data efetiva não pode ser futura.');
      depois.Data=data.br;
    }
    if(antes.Status===status){
      if(status==='Realizado'&&dataAtendimentoV2_(antes.Data,'Data atual').br!==depois.Data) throw new Error('Lançamento já realizado com outra data.');
      return {ok:true,semAlteracao:true,lancamento:antes};
    }
    if(antes.Status==='Cancelado') throw new Error('Lançamento cancelado não pode ser reativado.');
    if(!motivo) throw new Error('Motivo da alteração é obrigatório.');
    depois.Status=status;
    logFinV2_('ALTERAR_STATUS',antes.ID_Lancamento,'INICIADO',{motivo:motivo,antes:antes,depois:depois});iniciou=true;
    if(status==='Realizado') e.aba.getRange(achado.linha,e.mapa.Data+1).setNumberFormat('@').setValue(depois.Data);
    e.aba.getRange(achado.linha,e.mapa.Status+1).setValue(status);
    SpreadsheetApp.flush();logFinV2_('ALTERAR_STATUS',antes.ID_Lancamento,'CONCLUIDO',{motivo:motivo,antes:antes,depois:depois});
    return {ok:true,lancamento:obterLancamentoFinanceiroV2PorId(antes.ID_Lancamento)};
  }catch(e){
    if(iniciou) throw new Error('Confira '+dados.idLancamento+' em FINANCEIRO e LOG antes de repetir; a atualização pode ter sido parcial. Detalhe: '+e.message);
    throw e;
  }finally{lock.releaseLock();}
}
