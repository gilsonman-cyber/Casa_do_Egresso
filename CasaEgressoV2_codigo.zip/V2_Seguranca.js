/** Acesso V2: ADMIN ativo. Depende dos validadores puros de V2_Controles.
 * Instalar também as duas substituições descritas no guia.
 * Cache somente nesta execução; nova execução relê EQUIPE.
 * Não modifica compartilhamentos nativos nem protege código V1 independente.
 */
var contextoSegV2_ = null;
var chamadasSegV2_ = 0;

function registrosEquipeSegV2_(cabecalhos, linhas) {
  const cab = cabecalhos.map(function(v) { return String(v).trim(); });
  const vistos = Object.create(null);
  cab.forEach(function(c) {
    if (!c || vistos[c]) throw new Error('Cabeçalho vazio ou duplicado em EQUIPE.');
    vistos[c] = true;
  });
  ['E-mail', 'Nome', 'Perfil', 'Ativo'].forEach(function(c) {
    if (!vistos[c]) throw new Error('Campo ausente em EQUIPE: ' + c);
  });
  return linhas.filter(function(l) {
    return l.some(function(v) { return String(v).trim() !== ''; });
  }).map(function(l) {
    const r = {};
    cab.forEach(function(c, i) { r[c] = l[i]; });
    return r;
  });
}

function autorizarSegV2_(email, registros) {
  return autorizarEquipeCtrlV2_(email, validarEquipeCtrlV2_(registros), true);
}

function exigirAcessoPlanilhaV2_() {
  chamadasSegV2_++;

  // Usa o autor validado quando a operação vem de uma solicitação do Notion.
  if (
    typeof contextoNotionSolicitacaoV2_ !== 'undefined' &&
    contextoNotionSolicitacaoV2_
  ) {
    return exigirContextoNotionSolicitacaoV2_();
  }

  const email = String(
    Session.getActiveUser().getEmail() || ''
  ).trim().toLowerCase();

  if (!email) {
    throw new Error(
      'Acesso negado: usuário ativo não identificado. Execute com sua conta autorizada.'
    );
  }

  const id = String(
    configV2Core_().SPREADSHEET_ID || ''
  ).trim();

  if (!id) {
    throw new Error('SPREADSHEET_ID não configurado.');
  }

  if (
    contextoSegV2_ &&
    contextoSegV2_.id === id &&
    contextoSegV2_.usuario.email === email
  ) {
    return contextoSegV2_;
  }

  contextoSegV2_ = null;

  // Leitura direta para evitar recursão com as funções do núcleo.
  const planilha = SpreadsheetApp.openById(id);
  const aba = planilha.getSheetByName('EQUIPE');

  if (!aba || aba.getLastColumn() < 1) {
    throw new Error('EQUIPE ausente ou sem cabeçalhos.');
  }

  const valores = aba.getRange(
    1,
    1,
    Math.max(1, aba.getLastRow()),
    aba.getLastColumn()
  ).getValues();

  const usuario = autorizarSegV2_(
    email,
    registrosEquipeSegV2_(valores[0], valores.slice(1))
  );

  contextoSegV2_ = {
    id: id,
    planilha: planilha,
    usuario: Object.freeze(usuario)
  };

  return contextoSegV2_;
}

function VALIDAR_SEGURANCA_V2() {
  const c = exigirAcessoPlanilhaV2_();
  return {ok: true, email: c.usuario.email, perfil: c.usuario.perfil,
    ativo: c.usuario.ativo, politica: 'ADMIN ativo', cache: 'Somente nesta execução'};
}
