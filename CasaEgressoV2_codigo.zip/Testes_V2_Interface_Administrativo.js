/** Testes 79–81: somente leitura e validações; não gravam dados. */
function TESTE_V2_79_VALIDAR_PAINEL_ADMINISTRATIVO() {
  const r=uiInicioV2();VALIDAR_FINANCEIRO_V2();VALIDAR_COMPRAS_V2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Administrativo').getContent();
  ['uiConsultarAdministrativoV2','uiRegistrarFinanceiroV2','uiAtualizarCompraV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_80_CONSULTAR_ADMINISTRATIVO_INTERFACE() {
  const r=uiConsultarAdministrativoV2({});
  if(!Array.isArray(r.financeiro)||!Array.isArray(r.compras)||!r.resumo.ok)throw new Error('Resposta inválida.');
  const resultado={ok:true,lancamentos:r.financeiro.length,compras:r.compras.length,resumo:r.resumo,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_81_VALIDAR_DADOS_ADMINISTRATIVOS() {
  exigirAcessoPlanilhaV2_();const hoje=uiInicioV2().hoje;
  const f={data:hoje,tipo:'Entrada',categoria:'Teste',descricao:'Teste',valor:'10,50',responsavel:'Teste',status:'Previsto'};
  const c={item:'Teste',quantidade:'2',solicitante:'Teste',dataSolicitacao:hoje,valorEstimado:'20,00'};
  const casos=[['Valor negativo',function(){validarLancamentoFinV2_(Object.assign({},f,{valor:'-1'}));},/Valor/],
    ['Precisão monetária',function(){validarLancamentoFinV2_(Object.assign({},f,{valor:'10,001'}));},/Valor/],
    ['Tipo inválido',function(){validarLancamentoFinV2_(Object.assign({},f,{tipo:'Outro'}));},/Tipo/],
    ['Quantidade zero',function(){validarCompraComV2_(Object.assign({},c,{quantidade:'0'}));},/Quantidade/],
    ['Solicitante vazio',function(){validarCompraComV2_(Object.assign({},c,{solicitante:''}));},/solicitante/],
    ['Prioridade inválida',function(){validarCompraComV2_(Object.assign({},c,{prioridade:'Outra'}));},/Prioridade/]];
  const testes=casos.map(function(caso){let erro;try{caso[1]();}catch(e){erro=e;}
    if(!erro||!caso[2].test(erro.message))throw new Error('Bloqueio não confirmado: '+caso[0]);return {teste:caso[0],bloqueado:true};});
  const r={ok:true,testes:testes,somenteLeitura:true};console.log(JSON.stringify(r,null,2));return r;
}
