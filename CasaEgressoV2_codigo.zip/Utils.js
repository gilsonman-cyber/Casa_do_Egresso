function normalize_(v){ return String(v == null ? "" : v).trim(); }
function onlyDigits_(v){ return normalize_(v).replace(/\D/g,""); }
function validarCPF_(cpf){
  cpf=onlyDigits_(cpf); if(cpf.length!==11 || /^(\d)\1{10}$/.test(cpf)) return false;
  let s=0; for(let i=0;i<9;i++) s+=+cpf[i]*(10-i); let d=(s*10)%11; if(d===10)d=0; if(d!==+cpf[9])return false;
  s=0; for(let i=0;i<10;i++) s+=+cpf[i]*(11-i); d=(s*10)%11; if(d===10)d=0; return d===+cpf[10];
}
function headers_(sh){ return sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String); }
function rowObject_(headers,row){ const o={}; headers.forEach((h,i)=>o[h]=row[i]); return o; }
function appendObject_(sh,obj){
  const hs=headers_(sh); const row=hs.map(h=>obj[h]!==undefined?obj[h]:""); sh.appendRow(row);
}
function findRowByField_(sh,field,value){
  const hs=headers_(sh); const idx=hs.indexOf(field); if(idx<0) throw new Error("Campo não encontrado: "+field);
  if(sh.getLastRow()<2) return null;
  const vals=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues();
  for(let i=0;i<vals.length;i++) if(String(vals[i][idx]).trim().toLowerCase()===String(value).trim().toLowerCase()) return {row:i+2,data:rowObject_(hs,vals[i])};
  return null;
}
function newId_(prefix){ return prefix+"-"+Utilities.getUuid().replace(/-/g,"").slice(0,10).toUpperCase(); }
