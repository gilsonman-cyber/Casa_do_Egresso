/**
 * TESTES DO NÚCLEO V2 — NOVA PLANILHA
 * Execute uma função por vez, nesta ordem.
 */

function TESTE_V2_01_VALIDAR_BASE_NOVA() {
  const r = VALIDAR_NUCLEO_V2();
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_02_LOCALIZAR_PESSOA_EXISTENTE() {
  const cpf = '529.982.247-25';
  const pessoa = obterPessoaV2PorCPF_(cpf);

  if (!pessoa) {
    throw new Error('Pessoa de teste não encontrada na nova planilha pelo CPF ' + cpf + '.');
  }

  console.log(JSON.stringify(pessoa, null, 2));
  return pessoa;
}

function TESTE_V2_03_ABRIR_PASSAGEM_NOVA_BASE() {
  const cpf = '529.982.247-25';

  const resultado = abrirPassagemV2({
    cpf: cpf,
    dataEntrada: '25/09/2026',
    dataPrevistaSaida: '02/10/2026',
    tipo: 'Saída Temporária',
    modalidade: '7 Dias',
    motivoObjetivo: 'Teste do núcleo V2 na nova planilha.',
    quarto: 'Teste',
    responsavel: 'Responsável Teste',
    observacoesEntrada: 'Passagem criada exclusivamente para validação da nova base V2.'
  });

  console.log(JSON.stringify(resultado, null, 2));
  return resultado;
}

function TESTE_V2_04_CONSULTAR_PASSAGEM_ABERTA() {
  const pessoa = obterPessoaV2PorCPF_('529.982.247-25');
  if (!pessoa) throw new Error('Pessoa de teste não encontrada.');

  const passagem = obterPassagemAbertaV2_(pessoa.ID_Pessoa);
  if (!passagem) throw new Error('Nenhuma passagem aberta encontrada para a pessoa de teste.');

  console.log(JSON.stringify(passagem, null, 2));
  return passagem;
}

function TESTE_V2_05_ENCERRAR_PASSAGEM() {
  const pessoa = obterPessoaV2PorCPF_('529.982.247-25');
  if (!pessoa) throw new Error('Pessoa de teste não encontrada.');

  const passagem = obterPassagemAbertaV2_(pessoa.ID_Pessoa);
  if (!passagem) throw new Error('Nenhuma passagem aberta encontrada para encerrar.');

  const resultado = encerrarPassagemV2({
    idPassagem: passagem.ID_Passagem,
    dataSaidaEfetiva: '02/10/2026',
    observacoesSaida: 'Passagem encerrada após teste do núcleo V2.'
  });

  console.log(JSON.stringify(resultado, null, 2));
  return resultado;
}
