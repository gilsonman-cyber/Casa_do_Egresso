function criarPessoa(dados){
  return withLock_(function(){
    const u=requireRole_(["ADMIN","COORDENACAO","TECNICO"]);
    const sh=getSpreadsheet_().getSheetByName("PESSOAS");
    const nome=normalize_(dados.nome||dados["Nome Completo"]);
    if(!nome) throw new Error("Nome Completo é obrigatório.");
    const cpf=onlyDigits_(dados.cpf||dados.CPF||"");
    if(cpf && !validarCPF_(cpf)) throw new Error("CPF inválido.");
    if(cpf && findRowByField_(sh,"CPF",cpf)) throw new Error("CPF já cadastrado.");
    const id=newId_("PES");
    const obj={"ID_Pessoa":id,"Nome Completo":nome,"CPF":cpf,"Data de Cadastro":now_(),"Status da Pessoa":"Ativa","Criado_Por":u["E-mail"],"Atualizado_Em":now_(),"Atualizado_Por":u["E-mail"],"Versao":1};
    ["Nome Social / Alcunha","RG","Data de Nascimento","Nome da Mãe","Gênero","Telefone","Contato de Emergência","Escolaridade","Profissões / Habilidades","Interesse em Cursos","Informações Familiares","Observações Gerais"].forEach(k=>{if(dados[k]!==undefined)obj[k]=dados[k]});
    appendObject_(sh,obj); log_("CRIAR","PESSOAS",id,"SUCESSO","Apps Script","Pessoa criada"); return obj;
  });
}
