/** MOVIMENTACOES V2 — manter núcleo V2 e V2_Atendimentos no mesmo projeto.
 * Uma linha representa uma saída e seu retorno: não cria segunda linha no retorno.
 * Tipo de Movimentação = Saída; retorno vazio = pendente.
 * Situação é calculada nas consultas, sem acrescentar coluna à planilha.
 * Horários são locais de CONFIG_V2_CORE.TIMEZONE, armazenados como texto.
 * Passagem encerrada: somente lançamento histórico explicitamente autorizado
 * por dados.historico === true e com justificativaHistorico, dentro da permanência.
 * Nenhuma alteração de Pessoas, Passagens ou Drive por este módulo.
 * Não substitui regras institucionais de autorização de saída ou controle EQUIPE.
 */
const V2_MOV_CAMPOS = ['ID_Movimentação','ID_Pessoa','ID_Passagem','Data','Hora',
  'Tipo de Movimentação','Destino','Motivo','Data/Hora Prevista de Retorno',
  'Data/Hora Real de Retorno','Observações','Usuário'];

function textoMovV2_(v) { return v === undefined || v === null ? '' : String(v).trim(); }
function seguroMovV2_(v) { return typeof v==='string' && /^[=+@-]/.test(v) ? "'"+v : v; }
function agoraMovV2_() {
  return Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,"yyyy-MM-dd'T'HH:mm");
}
function momentoMovV2_(data,hora,campo) {
  const d=dataAtendimentoV2_(data,campo), h=textoMovV2_(hora);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(h)) throw new Error(campo+': hora inválida; use HH:mm.');
  return {chave:d.iso+'T'+h,data:d.br,hora:h,texto:d.br+' '+h};
}
function lerMomentoMovV2_(valor,campo) {
  let s;
  if (Object.prototype.toString.call(valor)==='[object Date]' && !isNaN(valor.getTime())) {
    s=Utilities.formatDate(valor,configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm');
  } else { s=textoMovV2_(valor); }
  const m=/^(\d{2}\/\d{2}\/\d{4}|\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})$/.exec(s);
  if (!m) throw new Error(campo+': informe dd/MM/aaaa HH:mm.');
  return momentoMovV2_(m[1],m[2],campo);
}
function estruturaMovV2_() {
  const aba=obterAbaV2Core_('MOVIMENTACOES');
  if (!aba.getLastColumn()) throw new Error('MOVIMENTACOES sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoMovV2_);
  const mapa={};
  cab.forEach(function(c,i) {
    if (!c) throw new Error('Cabeçalho vazio em MOVIMENTACOES.');
    if (Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);
    mapa[c]=i;
  });
  V2_MOV_CAMPOS.forEach(function(c) {
    if (!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);
  });
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_MOVIMENTACOES_V2() {
  if (typeof dataAtendimentoV2_!=='function') throw new Error('Mantenha V2_Atendimentos.gs no projeto.');
  const e=estruturaMovV2_();
  return {ok:true,aba:'MOVIMENTACOES',camposObrigatorios:V2_MOV_CAMPOS.length,
    registros:Math.max(0,e.aba.getLastRow()-1)};
}
function registrosMovV2_() {
  const e=estruturaMovV2_(), n=e.aba.getLastRow()-1;
  if (n<1) return [];
  const linhas=[];
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i) {
    if (linha.every(function(v) { return textoMovV2_(v)===''; })) return;
    const r={}; e.cab.forEach(function(c,j) { r[c]=linha[j]; });
    if (!textoMovV2_(r['ID_Movimentação'])) throw new Error('Movimentação sem ID na linha '+(i+2));
    linhas.push({registro:r,linha:i+2});
  });
  return linhas;
}
function registroPorIdMovV2_(id) {
  const chave=textoMovV2_(id);
  if (!chave) throw new Error('ID_Movimentação é obrigatório.');
  const lista=registrosMovV2_().filter(function(v) { return textoMovV2_(v.registro['ID_Movimentação'])===chave; });
  if (lista.length>1) throw new Error('ID_Movimentação duplicado.');
  return lista[0]||null;
}
function situacaoMovV2_(r) {
  const copia=Object.assign({},r);
  if (textoMovV2_(r['Data/Hora Real de Retorno'])) copia.Situacao='Retornado';
  else copia.Situacao=lerMomentoMovV2_(r['Data/Hora Prevista de Retorno'],'Retorno previsto').chave < agoraMovV2_()
    ? 'Atrasado' : 'Fora';
  return copia;
}
function obterMovimentacaoV2PorId(idMovimentacao) {
  const achado=registroPorIdMovV2_(idMovimentacao);
  return achado?situacaoMovV2_(achado.registro):null;
}
function obterMovimentacoesPessoaV2(idPessoa) {
  const id=textoMovV2_(idPessoa);
  if (!id || !obterPessoaV2PorId_(id)) throw new Error('Pessoa não encontrada.');
  return registrosMovV2_().filter(function(v) { return textoMovV2_(v.registro.ID_Pessoa)===id; })
    .map(function(v) { return situacaoMovV2_(v.registro); });
}
function obterMovimentacoesPassagemV2(idPassagem) {
  const id=textoMovV2_(idPassagem);
  if (!id || !obterPassagemV2PorId_(id)) throw new Error('Passagem não encontrada.');
  return registrosMovV2_().filter(function(v) { return textoMovV2_(v.registro.ID_Passagem)===id; })
    .map(function(v) { return situacaoMovV2_(v.registro); });
}
function validarSaidaMovV2_(dados) {
  dados=dados||{};
  const id=textoMovV2_(dados.idPassagem);
  if (!id) throw new Error('ID_Passagem é obrigatório.');
  const p=obterPassagemV2PorId_(id);
  if (!p) throw new Error('Passagem não encontrada.');
  if (p.Status!=='Aberta' && p.Status!=='Encerrada') throw new Error('Passagem cancelada ou inválida.');
  const pessoa=textoMovV2_(p.ID_Pessoa);
  if (!obterPessoaV2PorId_(pessoa)) throw new Error('Pessoa da passagem não encontrada.');
  if (dados.idPessoa && textoMovV2_(dados.idPessoa)!==pessoa) throw new Error('Pessoa não corresponde à passagem.');
  const justificativa=textoMovV2_(dados.justificativaHistorico);
  if (p.Status==='Encerrada' && (dados.historico!==true || !justificativa)) {
    throw new Error('Passagem encerrada exige lançamento histórico e justificativa.');
  }
  const saida=momentoMovV2_(dados.data,dados.hora,'Saída');
  const prevista=lerMomentoMovV2_(dados.retornoPrevisto,'Retorno previsto');
  if (saida.chave>agoraMovV2_()) throw new Error('Saída efetiva não pode ser futura.');
  if (prevista.chave<=saida.chave) throw new Error('Retorno previsto deve ser posterior à saída.');
  const entrada=dataAtendimentoV2_(p['Data de Entrada'],'Entrada da passagem').iso;
  if (saida.chave.slice(0,10)<entrada) throw new Error('Saída anterior à entrada na Casa.');
  if (p.Status==='Encerrada') {
    const fim=dataAtendimentoV2_(p['Data de Saída Efetiva'],'Saída da passagem').iso;
    if (saida.chave.slice(0,10)>fim) throw new Error('Movimentação posterior ao encerramento da passagem.');
  }
  ['destino','motivo'].forEach(function(c) {
    if (!textoMovV2_(dados[c])) throw new Error('Campo obrigatório: '+c);
  });
  const obs=[textoMovV2_(dados.observacoes),p.Status==='Encerrada'?'Lançamento histórico: '+justificativa:'']
    .filter(Boolean).join('\n\n');
  return {'ID_Pessoa':pessoa,'ID_Passagem':id,'Data':saida.data,'Hora':saida.hora,
    'Tipo de Movimentação':'Saída','Destino':textoMovV2_(dados.destino),'Motivo':textoMovV2_(dados.motivo),
    'Data/Hora Prevista de Retorno':prevista.texto,'Data/Hora Real de Retorno':'','Observações':obs};
}
function registrarSaidaV2(dados) {
  const lock=LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const e=estruturaMovV2_(), r=validarSaidaMovV2_(dados);
    const saida=momentoMovV2_(r.Data,r.Hora,'Saída');
    const anteriores=registrosMovV2_().filter(function(v) { return textoMovV2_(v.registro.ID_Pessoa)===r.ID_Pessoa; });
    anteriores.forEach(function(v) {
      const a=v.registro;
      if (a['Tipo de Movimentação']!=='Saída') throw new Error('Tipo de movimentação anterior não suportado; revise os registros.');
      if (!textoMovV2_(a['Data/Hora Real de Retorno'])) throw new Error('Já existe saída sem retorno para esta pessoa.');
      const fim=lerMomentoMovV2_(a['Data/Hora Real de Retorno'],'Retorno anterior');
      // Mantém ordem cronológica: inserções retroativas antes de saídas já registradas
      // precisam de rotina específica de correção, ainda não implementada.
      if (saida.chave<fim.chave) throw new Error('Saída anterior ao último retorno registrado.');
    });
    r['ID_Movimentação']=gerarIdV2Core_('MOV');
    if (registroPorIdMovV2_(r['ID_Movimentação'])) throw new Error('ID já existente; tente novamente.');
    r['Usuário']=usuarioV2Core_();
    const n=e.aba.getLastRow()+1;
    ['Data','Hora','Data/Hora Prevista de Retorno','Data/Hora Real de Retorno'].forEach(function(c) {
      e.aba.getRange(n,e.mapa[c]+1).setNumberFormat('@');
    });
    e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c) {
      return seguroMovV2_(r[c]===undefined?'':r[c]);
    })]);
    SpreadsheetApp.flush();
    return {ok:true,movimentacao:situacaoMovV2_(r)};
  } finally { lock.releaseLock(); }
}
function validarRetornoMovV2_(registro,dados) {
  const retorno=lerMomentoMovV2_(dados.retornoEfetivo,'Retorno efetivo');
  const saida=momentoMovV2_(registro.Data,registro.Hora,'Saída');
  if (retorno.chave<saida.chave) throw new Error('Retorno anterior à saída.');
  if (retorno.chave>agoraMovV2_()) throw new Error('Retorno efetivo não pode ser futuro.');
  const p=obterPassagemV2PorId_(registro.ID_Passagem);
  if (!p || ['Aberta','Encerrada'].indexOf(p.Status)<0) throw new Error('Passagem inválida para registrar retorno.');
  if (textoMovV2_(p.ID_Pessoa)!==textoMovV2_(registro.ID_Pessoa)) throw new Error('Vínculo Pessoa/Passagem inconsistente.');
  if (p.Status==='Encerrada' && retorno.chave.slice(0,10)>dataAtendimentoV2_(p['Data de Saída Efetiva'],'Saída da passagem').iso) {
    throw new Error('Retorno posterior ao encerramento da passagem.');
  }
  return retorno;
}
function registrarRetornoV2(dados) {
  dados=dados||{};
  const lock=LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const e=estruturaMovV2_(), encontrado=registroPorIdMovV2_(dados.idMovimentacao);
    if (!encontrado) throw new Error('Movimentação não encontrada.');
    const r=encontrado.registro;
    if (r['Tipo de Movimentação']!=='Saída') throw new Error('Tipo de movimentação não permite retorno.');
    const retorno=validarRetornoMovV2_(r,dados);
    const anterior=textoMovV2_(r['Data/Hora Real de Retorno']);
    if (anterior) {
      if (lerMomentoMovV2_(anterior,'Retorno gravado').chave!==retorno.chave) throw new Error('Retorno já registrado com outro horário.');
      return {ok:true,semAlteracao:true,movimentacao:situacaoMovV2_(r)};
    }
    const obs='Retorno em '+retorno.texto+' | registrado por '+usuarioV2Core_()+
      (textoMovV2_(dados.observacoes)?'\n'+textoMovV2_(dados.observacoes):'');
    r['Observações']=[textoMovV2_(r['Observações']),obs].filter(Boolean).join('\n\n');
    r['Data/Hora Real de Retorno']=retorno.texto;
    e.aba.getRange(encontrado.linha,e.mapa['Observações']+1).setValue(seguroMovV2_(r['Observações']));
    e.aba.getRange(encontrado.linha,e.mapa['Data/Hora Real de Retorno']+1).setNumberFormat('@').setValue(retorno.texto);
    SpreadsheetApp.flush();
    return {ok:true,movimentacao:obterMovimentacaoV2PorId(r['ID_Movimentação'])};
  } finally { lock.releaseLock(); }
}
/** Chamar dentro de encerrarPassagemV2, antes de escrever qualquer célula. */
function exigirSemSaidaPendenteV2_(idPassagem) {
  const pendentes=obterMovimentacoesPassagemV2(idPassagem).filter(function(r) {
    return !textoMovV2_(r['Data/Hora Real de Retorno']);
  });
  if (pendentes.length) throw new Error('Passagem possui saída sem retorno; regularize a movimentação antes de encerrar.');
  return true;
}
