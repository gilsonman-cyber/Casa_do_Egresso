/** Interface documental. Requer V2_Interface, V2_Interface_Acompanhamento e V2_Documentos. */
function criarMenuDocumentosV2() {
  SpreadsheetApp.getUi().createMenu('Documentos • V2')
    .addItem('Consultar e registrar documentos','abrirDocumentosV2').addToUi();
}
function abrirDocumentosV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Documentos')
    .setWidth(880).setHeight(700),'Casa • Documentos');
}
function idArquivoUiDocV2_(valor) {
  const s=String(valor||'').trim();
  if(/^[A-Za-z0-9_-]+$/.test(s)) return s;
  // Somente links oficiais de arquivo. Links de pasta não são aceitos.
  const m=/^https:\/\/(?:drive\.google\.com\/file\/d\/|docs\.google\.com\/(?:document|spreadsheets|presentation)\/d\/)([A-Za-z0-9_-]+)(?:[/?#].*)?$/.exec(s);
  if(m) return m[1];
  const q=/^https:\/\/drive\.google\.com\/(?:open|uc)\?([^#]+)(?:#.*)?$/.exec(s);
  if(q){const p=q[1].split('&').filter(function(x){return x.indexOf('id=')===0;});
    if(p.length===1&&/^id=[A-Za-z0-9_-]+$/.test(p[0])) return p[0].slice(3);}
  throw new Error('Informe o ID ou um link de arquivo do Google Drive. Links de pasta não são aceitos.');
}
function uiConsultarDocumentosV2(dados) {
  exigirAcessoPlanilhaV2_();
  const v=vinculoAcompV2_(dados);
  return {ok:true,documentos:serializarAcompV2_(obterDocumentosPassagemV2(v.idPassagem))};
}
function uiRegistrarDocumentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAcompV2_(dados,['data','categoria','tipoDocumento','idArquivoDrive','observacoes']);
  d.idArquivoDrive=idArquivoUiDocV2_(d.idArquivoDrive);
  const r=registrarDocumentoV2(d);
  return {ok:true,id:r.documento.ID_Documento,reutilizado:!!r.reutilizado,
    mensagem:r.reutilizado?'Documento já registrado; cadastro existente mantido.':'Documento registrado.'};
}
function uiConferirDocumentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAcompV2_(dados,['idDocumento','observacoes']);
  const r=obterDocumentoV2PorId(d.idDocumento);
  if(!r||r.ID_Pessoa!==d.idPessoa||r.ID_Passagem!==d.idPassagem) throw new Error('Documento não pertence à pessoa e passagem selecionadas.');
  const resultado=conferirDocumentoV2(d);
  return {ok:true,id:d.idDocumento,semAlteracao:!!resultado.semAlteracao,
    mensagem:resultado.semAlteracao?'Documento já estava conferido.':'Conferência registrada.'};
}
