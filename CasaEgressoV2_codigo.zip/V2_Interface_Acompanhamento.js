/** Painel de acompanhamento. Depende de V2_Interface e módulos existentes. */
function criarMenuAcompanhamentoV2() {
  SpreadsheetApp.getUi().createMenu('Acompanhamento • V2')
    .addItem('Atendimentos e encaminhamentos','abrirAcompanhamentoV2').addToUi();
}
function abrirAcompanhamentoV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Acompanhamento')
    .setWidth(900).setHeight(700),'Casa • Acompanhamento');
}
function vinculoAcompV2_(dados) {
  dados = dados || {};
  const idPessoa = String(dados.idPessoa || '').trim();
  const idPassagem = String(dados.idPassagem || '').trim();
  const p = obterPassagemV2PorId_(idPassagem);
  if (!idPessoa || !p || p.ID_Pessoa !== idPessoa) throw new Error('Pessoa e passagem divergentes. Consulte novamente.');
  return {idPessoa:idPessoa,idPassagem:idPassagem};
}
function dadosAcompV2_(d, campos) {
  const r = vinculoAcompV2_(d);
  campos.forEach(function(c) {
    const s = String(d[c] === undefined || d[c] === null ? '' : d[c]).trim();
    if(s.length > 5000) throw new Error(c+': máximo de 5000 caracteres.');
    r[c] = s;
  });return r;
}
function serializarAcompV2_(r) {
  // Datas de registro técnico são ISO; datas de calendário usam o fuso do projeto.
  return r.map(function(registro) {
    const novo = {};
    Object.keys(registro).forEach(function(k) {
      if(k==='_linha') return;
      const v = registro[k];
      novo[k] = Object.prototype.toString.call(v)==='[object Date]'
        ? (k==='Data'||k==='Prazo' ? dataAtendimentoV2_(v,k).br : k==='Hora'
          ? Utilities.formatDate(v,configV2Core_().TIMEZONE,'HH:mm') : v.toISOString()) : v;
    });return novo;
  });
}
function uiConsultarAcompanhamentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const v = vinculoAcompV2_(dados);
  return {ok:true,atendimentos:serializarAcompV2_(obterAtendimentosPassagemV2(v.idPassagem)),
    encaminhamentos:serializarAcompV2_(obterEncaminhamentosPassagemV2(v.idPassagem))};
}
function uiRegistrarAtendimentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d = dadosAcompV2_(dados,['data','hora','tipo','assunto','responsavel','registro','resultado','proximosPassos','status','anexos']);
  const r = registrarAtendimentoV2(d);
  return {ok:true,id:r.atendimento.ID_Atendimento,mensagem:'Atendimento registrado.'};
}
function uiRegistrarEncaminhamentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d = dadosAcompV2_(dados,['data','area','destino','motivo','responsavel','prazo','status','observacoes']);
  const r = registrarEncaminhamentoV2(d);
  return {ok:true,id:r.encaminhamento.ID_Encaminhamento,mensagem:'Encaminhamento registrado.'};
}
function uiAtualizarEncaminhamentoV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d = dadosAcompV2_(dados,['idEncaminhamento','status','resultado','observacoes']);
  const r = obterEncaminhamentoV2PorId(d.idEncaminhamento);
  if(!r || r.ID_Pessoa!==d.idPessoa || r.ID_Passagem!==d.idPassagem) throw new Error('Encaminhamento não pertence à pessoa e passagem selecionadas.');
  const atualizado = atualizarEncaminhamentoV2(d);
  return {ok:true,id:d.idEncaminhamento,semAlteracao:!!atualizado.semAlteracao,mensagem:'Encaminhamento atualizado.'};
}
