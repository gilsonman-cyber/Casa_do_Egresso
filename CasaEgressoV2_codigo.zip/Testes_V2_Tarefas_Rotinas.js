/** Execute 36 a 41. Cria uma tarefa e uma rotina fictícias. */
function fixtureTrV2_(){
  const p=obterPessoaV2PorId_('PES-F1C07550EC5D'),s=obterPassagemV2PorId_('PAS-F5E882F87A8E');
  if(!p||p['Nome Completo']!=='PESSOA TESTE V2'||!s||s.ID_Pessoa!==p.ID_Pessoa) throw new Error('Cadastro fictício não confirmado.');
  return {tarefa:{titulo:'[TESTE-TAR-V2-01] Conferência fictícia',descricao:'Descrição original da tarefa de teste.',
      responsavel:'Responsável Teste',prioridade:'Alta',prazo:'05/10/2026',idPessoa:p.ID_Pessoa,idPassagem:s.ID_Passagem},
    rotina:{rotina:'[TESTE-ROT-V2-01] Verificação diária fictícia',frequencia:'Diária',responsavel:'Responsável Teste',
      proximaExecucao:'30/09/2026',observacoes:'Observações originais da rotina de teste.'}};
}
function tarefaTesteTrV2_(){
  const titulo=fixtureTrV2_().tarefa.titulo,lista=listarTarefasV2().filter(function(r){return r['Título']===titulo;});
  if(lista.length>1) throw new Error('Tarefa de teste duplicada.');return lista[0]||null;
}
function rotinaTesteTrV2_(){
  const nome=fixtureTrV2_().rotina.rotina,lista=listarRotinasV2().filter(function(r){return r.Rotina===nome;});
  if(lista.length>1) throw new Error('Rotina de teste duplicada.');return lista[0]||null;
}
function TESTE_V2_36_VALIDAR_TAREFAS_ROTINAS(){
  const r=VALIDAR_TAREFAS_ROTINAS_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_37_CRIAR_TAREFA(){
  const existente=tarefaTesteTrV2_(),r=existente?{ok:true,reutilizado:true,tarefa:existente}:criarTarefaV2(fixtureTrV2_().tarefa);
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_38_CONSULTAR_E_CONCLUIR_TAREFA(){
  let t=tarefaTesteTrV2_();if(!t) throw new Error('Execute o teste 37.');
  const d=fixtureTrV2_().tarefa;
  if(t.ID_Pessoa!==d.idPessoa||t.ID_Passagem!==d.idPassagem||t.Prazo!==d.prazo||
      !listarTarefasV2({idPessoa:d.idPessoa,idPassagem:d.idPassagem}).some(function(r){return r.ID_Tarefa===t.ID_Tarefa;})) {
    throw new Error('Dados ou consultas da tarefa divergentes.');
  }
  if(t.Status==='Pendente') t=atualizarStatusTarefaV2({idTarefa:t.ID_Tarefa,status:'Em andamento',observacoes:'Teste iniciado.'}).tarefa;
  const r=atualizarStatusTarefaV2({idTarefa:t.ID_Tarefa,status:'Concluída',observacoes:'[TESTE-TAR-CONCLUSAO] Conferência fictícia concluída.'});
  const salvo=obterTarefaV2PorId(t.ID_Tarefa);
  if(salvo.Status!=='Concluída'||salvo['Descrição'].indexOf(d.descricao)<0||salvo['Descrição'].indexOf('[TESTE-TAR-CONCLUSAO]')<0) {
    throw new Error('Falha na conclusão ou preservação da descrição.');
  }
  r.consultaPorVinculo=true;r.descricaoPreservada=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_39_CRIAR_ROTINA(){
  const existente=rotinaTesteTrV2_(),r=existente?{ok:true,reutilizado:true,rotina:existente}:criarRotinaV2(fixtureTrV2_().rotina);
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_40_EXECUTAR_ROTINA(){
  const rotina=rotinaTesteTrV2_();if(!rotina) throw new Error('Execute o teste 39.');
  if(rotina['Próxima Execução']==='01/10/2026'&&String(rotina['Observações']).indexOf('[TESTE-ROT-EXECUCAO]')>=0){
    const r={ok:true,reutilizado:true,rotina:rotina};console.log(JSON.stringify(r,null,2));return r;
  }
  const r=registrarExecucaoRotinaV2({idRotina:rotina.ID_Rotina,dataPrevista:'30/09/2026',dataExecucao:'30/09/2026',
    observacoes:'[TESTE-ROT-EXECUCAO] Verificação fictícia realizada.'});
  const salvo=obterRotinaV2PorId(rotina.ID_Rotina);
  if(salvo['Próxima Execução']!=='01/10/2026'||salvo.Status!=='Ativa'||
      salvo['Observações'].indexOf(fixtureTrV2_().rotina.observacoes)<0||salvo['Observações'].indexOf('[TESTE-ROT-EXECUCAO]')<0) {
    throw new Error('Próxima data ou histórico incorreto.');
  }
  let bloqueado=false;
  try{registrarExecucaoRotinaV2({idRotina:rotina.ID_Rotina,dataPrevista:'30/09/2026',dataExecucao:'30/09/2026',observacoes:'Repetição indevida.'});}
  catch(e){if(String(e.message).indexOf('já foi atualizada')<0) throw e;bloqueado=true;}
  if(!bloqueado) throw new Error('Execução repetida foi aceita.');
  r.repeticaoBloqueada=true;r.observacoesPreservadas=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_41_BLOQUEAR_TAREFAS_ROTINAS_INVALIDAS(){
  const d=fixtureTrV2_(),casos=[
    {nome:'Título vazio',tipo:'tarefa',dados:{titulo:''},erro:'Campo obrigatório: titulo'},
    {nome:'Prioridade inválida',tipo:'tarefa',dados:{prioridade:'Inexistente'},erro:'Prioridade inválida'},
    {nome:'Pessoa divergente',tipo:'tarefa',dados:{idPessoa:'PES-DIVERGENTE'},erro:'não corresponde'},
    {nome:'Prazo inexistente',tipo:'tarefa',dados:{prazo:'31/02/2026'},erro:'data inválida'},
    {nome:'Frequência inválida',tipo:'rotina',dados:{frequencia:'Inexistente'},erro:'Frequência inválida'},
    {nome:'Responsável vazio',tipo:'rotina',dados:{responsavel:''},erro:'Campo obrigatório: responsavel'},
    {nome:'Data de rotina inválida',tipo:'rotina',dados:{proximaExecucao:'31/02/2026'},erro:'data inválida'}
  ];
  const testes=casos.map(function(c){
    try{(c.tipo==='tarefa'?validarTarefaTrV2_:validarRotinaTrV2_)(Object.assign({},d[c.tipo],c.dados));}
    catch(e){if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;}
    throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
