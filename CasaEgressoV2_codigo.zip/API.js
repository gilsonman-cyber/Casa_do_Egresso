function doPost(e){
  const token=getConfig_("API_TOKEN");
  const supplied=e && e.parameter ? e.parameter.token : "";
  if(!token || supplied!==token) return ContentService.createTextOutput(JSON.stringify({ok:false,error:"Token inválido"})).setMimeType(ContentService.MimeType.JSON);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}
