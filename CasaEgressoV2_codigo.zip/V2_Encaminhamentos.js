/** ENCAMINHAMENTOS V2
 * Adicionar ao mesmo projeto do núcleo V2 e de V2_Atendimentos.gs.
 * Reutiliza dataAtendimentoV2_ para validar datas; não precisa dos testes antigos.
 * Mantém os 13 cabeçalhos existentes. Não altera Pessoas, Passagens ou Drive.
 * Aceita lançamento histórico em passagem encerrada dentro da permanência.
 * O prazo pode ultrapassar a saída; encaminhamento pode ser concluído após a saída.
 * Status desta versão: Pendente, Em andamento, Concluído, Cancelado.
 * Usuário identifica quem criou. Atualizações são acrescentadas em Observações.
 * Não implementa interface, controle EQUIPE ou sincronização Notion.
 */
const V2_ENC_CAMPOS = [
  'ID_Encaminhamento','ID_Pessoa','ID_Passagem','Data','Área',
  'Instituição / Destino','Motivo','Responsável','Prazo','Status',
  'Resultado','Observações','Usuário'
];
const V2_ENC_STATUS = ['Pendente','Em andamento','Concluído','Cancelado'];

function textoEncV2_(valor) {
  return valor === null || valor === undefined ? '' : String(valor).trim();
}

function estruturaEncV2_() {
  const aba = obterAbaV2Core_('ENCAMINHAMENTOS');
  if (!aba.getLastColumn()) throw new Error('ENCAMINHAMENTOS sem cabeçalhos.');
  const cab = aba.getRange(1, 1, 1, aba.getLastColumn()).getDisplayValues()[0]
    .map(function(v) { return textoEncV2_(v); });
  const mapa = {};
  cab.forEach(function(c, i) {
    if (!c) throw new Error('Cabeçalho vazio em ENCAMINHAMENTOS.');
    if (Object.prototype.hasOwnProperty.call(mapa, c)) {
      throw new Error('Cabeçalho duplicado em ENCAMINHAMENTOS: ' + c);
    }
    mapa[c] = i;
  });
  V2_ENC_CAMPOS.forEach(function(c) {
    if (!Object.prototype.hasOwnProperty.call(mapa, c)) throw new Error('Campo ausente: ' + c);
  });
  return {aba: aba, cab: cab, mapa: mapa};
}

function VALIDAR_ENCAMINHAMENTOS_V2() {
  if (typeof dataAtendimentoV2_ !== 'function') {
    throw new Error('Mantenha V2_Atendimentos.gs no mesmo projeto.');
  }
  const e = estruturaEncV2_();
  return {ok: true, aba: 'ENCAMINHAMENTOS', camposObrigatorios: V2_ENC_CAMPOS.length,
    registros: Math.max(0, e.aba.getLastRow() - 1)};
}

function buscarEncV2_(campo, valor) {
  const e = estruturaEncV2_();
  const n = e.aba.getLastRow() - 1;
  if (n < 1) return [];
  const r = [];
  e.aba.getRange(2, 1, n, e.cab.length).getValues().forEach(function(linha, i) {
    if (textoEncV2_(linha[e.mapa[campo]]) !== valor) return;
    const registro = {};
    e.cab.forEach(function(c, j) { registro[c] = linha[j]; });
    r.push({registro: registro, linha: i + 2});
  });
  return r;
}

function obterEncaminhamentoV2PorId(idEncaminhamento) {
  const id = textoEncV2_(idEncaminhamento);
  if (!id) throw new Error('ID_Encaminhamento é obrigatório.');
  const r = buscarEncV2_('ID_Encaminhamento', id);
  if (r.length > 1) throw new Error('ID_Encaminhamento duplicado: ' + id);
  return r.length ? r[0].registro : null;
}

function obterEncaminhamentosPassagemV2(idPassagem) {
  const id = textoEncV2_(idPassagem);
  if (!id || !obterPassagemV2PorId_(id)) throw new Error('Passagem não encontrada.');
  return buscarEncV2_('ID_Passagem', id).map(function(v) { return v.registro; });
}

function obterEncaminhamentosPessoaV2(idPessoa) {
  const id = textoEncV2_(idPessoa);
  if (!id || !obterPessoaV2PorId_(id)) throw new Error('Pessoa não encontrada.');
  return buscarEncV2_('ID_Pessoa', id).map(function(v) { return v.registro; });
}

function validarRegistroEncV2_(dados) {
  dados = dados || {};
  const id = textoEncV2_(dados.idPassagem);
  if (!id) throw new Error('ID_Passagem é obrigatório.');
  const p = obterPassagemV2PorId_(id);
  if (!p) throw new Error('Passagem não encontrada.');
  if (['Aberta','Encerrada'].indexOf(p.Status) < 0) throw new Error('Passagem cancelada ou inválida.');
  const idPessoa = textoEncV2_(p.ID_Pessoa);
  if (!obterPessoaV2PorId_(idPessoa)) throw new Error('Pessoa da passagem não encontrada.');
  if (dados.idPessoa && textoEncV2_(dados.idPessoa) !== idPessoa) {
    throw new Error('Pessoa informada não corresponde à passagem.');
  }
  const data = dataAtendimentoV2_(dados.data, 'Data do encaminhamento');
  const entrada = dataAtendimentoV2_(p['Data de Entrada'], 'Data de entrada');
  if (data.iso < entrada.iso) throw new Error('Encaminhamento anterior à entrada.');
  if (p.Status === 'Encerrada' && data.iso > dataAtendimentoV2_(p['Data de Saída Efetiva'], 'Saída efetiva').iso) {
    throw new Error('Encaminhamento posterior à saída efetiva.');
  }
  if (data.iso > Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'yyyy-MM-dd')) {
    throw new Error('Data do encaminhamento não pode ser futura.');
  }
  let prazo = '';
  if (textoEncV2_(dados.prazo)) {
    const limite = dataAtendimentoV2_(dados.prazo, 'Prazo');
    if (limite.iso < data.iso) throw new Error('Prazo anterior ao encaminhamento.');
    prazo = limite.br;
  }
  ['area','destino','motivo','responsavel'].forEach(function(c) {
    if (!textoEncV2_(dados[c])) throw new Error('Campo obrigatório: ' + c);
  });
  const status = textoEncV2_(dados.status) || 'Pendente';
  if (['Pendente','Em andamento'].indexOf(status) < 0) {
    throw new Error('Novo encaminhamento deve iniciar Pendente ou Em andamento.');
  }
  return {
    'ID_Pessoa': idPessoa, 'ID_Passagem': id, 'Data': data.br,
    'Área': textoEncV2_(dados.area), 'Instituição / Destino': textoEncV2_(dados.destino),
    'Motivo': textoEncV2_(dados.motivo), 'Responsável': textoEncV2_(dados.responsavel),
    'Prazo': prazo, 'Status': status, 'Resultado': '',
    'Observações': textoEncV2_(dados.observacoes)
  };
}

function textoSeguroEncV2_(v) {
  return typeof v === 'string' && /^[=+@-]/.test(v) ? "'" + v : v;
}

function registrarEncaminhamentoV2(dados) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const e = estruturaEncV2_();
    const r = validarRegistroEncV2_(dados);
    r.ID_Encaminhamento = gerarIdV2Core_('ENC');
    if (obterEncaminhamentoV2PorId(r.ID_Encaminhamento)) throw new Error('ID já existente; tente novamente.');
    r['Usuário'] = usuarioV2Core_();
    const linha = e.cab.map(function(c) { return textoSeguroEncV2_(r[c] === undefined ? '' : r[c]); });
    const n = e.aba.getLastRow() + 1;
    e.aba.getRange(n, e.mapa.Data + 1).setNumberFormat('@');
    e.aba.getRange(n, e.mapa.Prazo + 1).setNumberFormat('@');
    e.aba.getRange(n, 1, 1, linha.length).setValues([linha]);
    SpreadsheetApp.flush();
    return {ok: true, encaminhamento: r};
  } finally { lock.releaseLock(); }
}

function atualizarEncaminhamentoV2(dados) {
  dados = dados || {};
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const id = textoEncV2_(dados.idEncaminhamento);
    if (!id) throw new Error('ID_Encaminhamento é obrigatório.');
    const e = estruturaEncV2_();
    const lista = buscarEncV2_('ID_Encaminhamento', id);
    if (lista.length !== 1) throw new Error('Encaminhamento não encontrado ou ID duplicado.');
    const r = lista[0].registro;
    if (V2_ENC_STATUS.indexOf(r.Status) < 0) throw new Error('Status atual inválido.');
    const status = textoEncV2_(dados.status);
    if (V2_ENC_STATUS.indexOf(status) < 0) throw new Error('Status solicitado inválido.');
    const resultado = dados.resultado === undefined ? textoEncV2_(r.Resultado) : textoEncV2_(dados.resultado);
    const observacao = textoEncV2_(dados.observacoes);
    if (['Concluído','Cancelado'].indexOf(status) >= 0 && !resultado) {
      throw new Error('Resultado é obrigatório para concluir ou cancelar.');
    }
    // Repetir a mesma conclusão sem observação adicional não altera o registro.
    if (status === r.Status && resultado === textoEncV2_(r.Resultado) && !observacao) {
      return {ok: true, semAlteracao: true, encaminhamento: r};
    }
    if (['Concluído','Cancelado'].indexOf(r.Status) >= 0) {
      throw new Error('Encaminhamento finalizado; reabertura não implementada.');
    }
    if (r.Status === 'Em andamento' && status === 'Pendente') {
      throw new Error('Não é permitido voltar de Em andamento para Pendente.');
    }
    const quando = Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'dd/MM/yyyy HH:mm:ss');
    const historico = quando + ' | ' + usuarioV2Core_() + ' | ' + r.Status + ' → ' + status +
      (resultado ? '\nResultado: ' + resultado : '') +
      (observacao ? '\nObservação: ' + observacao : '');
    const anteriores = textoEncV2_(r['Observações']);
    const anteriorResultado = textoEncV2_(r.Resultado);
    // Preserva também resultado legado que ainda não conste nas observações.
    const legado = anteriorResultado && anteriores.indexOf('Resultado: ' + anteriorResultado) < 0
      ? 'Resultado anterior: ' + anteriorResultado : '';
    r['Observações'] = [anteriores, legado, historico].filter(Boolean).join('\n\n');
    r.Status = status;
    r.Resultado = resultado;
    // Atualiza somente as três células gerenciadas; preserva outras colunas/fórmulas.
    ['Status','Resultado','Observações'].forEach(function(c) {
      e.aba.getRange(lista[0].linha, e.mapa[c] + 1).setValue(textoSeguroEncV2_(r[c]));
    });
    SpreadsheetApp.flush();
    return {ok: true, encaminhamento: obterEncaminhamentoV2PorId(id)};
  } finally { lock.releaseLock(); }
}
