/** Testes 76–78: leitura e bloqueios; não registram saídas ou retornos. */
function TESTE_V2_76_VALIDAR_PAINEL_MOVIMENTACOES() {
  const r=uiInicioMovimentacoesV2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Movimentacoes').getContent();
  ['uiConsultarMovimentacoesV2','uiRegistrarSaidaV2','uiRegistrarRetornoV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_77_CONSULTAR_MOVIMENTACOES_INTERFACE() {
  const pessoa=uiConsultarPessoaV2('529.982.247-25');
  if(!pessoa.encontrada) throw new Error('Pessoa fictícia não encontrada.');
  const r=uiConsultarMovimentacoesV2({idPessoa:pessoa.pessoa.id,idPassagem:'PAS-F5E882F87A8E'});
  if(!Array.isArray(r.movimentacoes)||!Array.isArray(r.pendentesPessoa))throw new Error('Listas inválidas.');
  const resultado={ok:true,statusPassagem:r.statusPassagem,movimentacoes:r.movimentacoes.length,
    pendenciasPessoa:r.pendentesPessoa.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_78_BLOQUEAR_VINCULOS_MOVIMENTACOES_INTERFACE() {
  exigirAcessoPlanilhaV2_();
  const d={idPessoa:'PESSOA-INEXISTENTE-TESTE',idPassagem:'PAS-F5E882F87A8E'};
  const testes=[uiConsultarMovimentacoesV2,uiRegistrarSaidaV2,uiRegistrarRetornoV2].map(function(f){
    let erro;try{f(d);}catch(e){erro=e;}
    if(!erro||erro.message.indexOf('Pessoa e passagem divergentes')<0)throw new Error('Bloqueio não confirmado: '+f.name);
    return {teste:f.name,bloqueado:true};});
  const r={ok:true,testes:testes,somenteLeitura:true};console.log(JSON.stringify(r,null,2));return r;
}
