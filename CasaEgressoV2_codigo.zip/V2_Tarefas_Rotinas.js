/** TAREFAS + ROTINAS V2. Depende do núcleo e V2_Atendimentos.
 * Preserva os cabeçalhos existentes. Histórico de tarefa na Descrição;
 * histórico de rotina nas Observações. Não cria gatilhos automáticos.
 * Rotina avança UM período a partir da data prevista, mesmo se estiver atrasada.
 * Mensal: conserva o dia quando possível e limita ao último dia do mês seguinte.
 * Não há controle de acesso EQUIPE neste módulo.
 */
const V2_TR_SCHEMAS={
  TAREFAS:['ID_Tarefa','Título','Descrição','Responsável','Prioridade','Prazo','Status','ID_Pessoa','ID_Passagem','Criado_Em'],
  ROTINAS:['ID_Rotina','Rotina','Frequência','Responsável','Próxima Execução','Status','Observações']
};
const V2_TR_STATUS_TAREFA=['Pendente','Em andamento','Concluída','Cancelada'];
const V2_TR_PRIORIDADES=['Baixa','Média','Alta','Urgente'];
const V2_TR_FREQUENCIAS=['Diária','Semanal','Quinzenal','Mensal'];
function textoTrV2_(v){return v===undefined||v===null?'':String(v).trim();}
function seguroTrV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function estruturaTrV2_(nome){
  if(!Object.prototype.hasOwnProperty.call(V2_TR_SCHEMAS,nome)) throw new Error('Módulo desconhecido.');
  const aba=obterAbaV2Core_(nome);
  if(!aba.getLastColumn()) throw new Error(nome+' sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoTrV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em '+nome);
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);
    mapa[c]=i;
  });
  V2_TR_SCHEMAS[nome].forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_TAREFAS_ROTINAS_V2(){
  if(typeof dataAtendimentoV2_!=='function') throw new Error('Mantenha V2_Atendimentos.gs no projeto.');
  const r={ok:true};
  Object.keys(V2_TR_SCHEMAS).forEach(function(nome){
    const e=estruturaTrV2_(nome);r[nome]={camposObrigatorios:V2_TR_SCHEMAS[nome].length,registros:Math.max(0,e.aba.getLastRow()-1)};
  });return r;
}
function registrosTrV2_(nome){
  const e=estruturaTrV2_(nome),n=e.aba.getLastRow()-1,lista=[],ids={};if(n<1) return lista;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i){
    if(linha.every(function(v){return textoTrV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,j){r[c]=linha[j];});
    const id=textoTrV2_(r[V2_TR_SCHEMAS[nome][0]]);
    if(!id||ids[id]) throw new Error('ID ausente ou duplicado em '+nome);
    ids[id]=true;lista.push({registro:r,linha:i+2});
  });return lista;
}
function localizarTrV2_(nome,id){
  id=textoTrV2_(id);if(!id) throw new Error('ID é obrigatório.');
  return registrosTrV2_(nome).filter(function(v){return v.registro[V2_TR_SCHEMAS[nome][0]]===id;})[0]||null;
}
function obterTarefaV2PorId(id){const v=localizarTrV2_('TAREFAS',id);return v?v.registro:null;}
function obterRotinaV2PorId(id){const v=localizarTrV2_('ROTINAS',id);return v?v.registro:null;}
function listarTarefasV2(filtros){
  filtros=filtros||{};
  return registrosTrV2_('TAREFAS').map(function(v){return v.registro;}).filter(function(r){
    return (!filtros.idPessoa||r.ID_Pessoa===filtros.idPessoa)&&(!filtros.idPassagem||r.ID_Passagem===filtros.idPassagem)&&
      (!filtros.status||r.Status===filtros.status)&&(!filtros.responsavel||r['Responsável']===filtros.responsavel);
  });
}
function listarRotinasV2(status){
  return registrosTrV2_('ROTINAS').map(function(v){return v.registro;}).filter(function(r){return !status||r.Status===status;});
}
function gravarTrV2_(nome,r,prefixo){
  const e=estruturaTrV2_(nome),campo=V2_TR_SCHEMAS[nome][0];r[campo]=gerarIdV2Core_(prefixo);
  if(localizarTrV2_(nome,r[campo])) throw new Error('ID já existente; tente novamente.');
  const n=e.aba.getLastRow()+1,campoData=nome==='TAREFAS'?'Prazo':'Próxima Execução';
  e.aba.getRange(n,e.mapa[campoData]+1).setNumberFormat('@');
  e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroTrV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();return r;
}
function atualizarCamposTrV2_(nome,encontrado,campos){
  const e=estruturaTrV2_(nome);
  Object.keys(campos).forEach(function(c){
    if(c==='Prazo'||c==='Próxima Execução') e.aba.getRange(encontrado.linha,e.mapa[c]+1).setNumberFormat('@');
    e.aba.getRange(encontrado.linha,e.mapa[c]+1).setValue(seguroTrV2_(campos[c]));
  });SpreadsheetApp.flush();
}
function historicoTrV2_(anterior,acao,nota){
  const hora=Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm:ss');
  return [textoTrV2_(anterior),hora+' | '+usuarioV2Core_()+' | '+acao+(nota?'\n'+nota:'')].filter(Boolean).join('\n\n');
}
function validarTarefaTrV2_(dados){
  dados=dados||{};
  ['titulo','responsavel'].forEach(function(c){if(!textoTrV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  const prioridade=textoTrV2_(dados.prioridade)||'Média';
  if(V2_TR_PRIORIDADES.indexOf(prioridade)<0) throw new Error('Prioridade inválida.');
  const prazo=textoTrV2_(dados.prazo)?dataAtendimentoV2_(dados.prazo,'Prazo').br:'';
  let pessoa=textoTrV2_(dados.idPessoa);const passagem=textoTrV2_(dados.idPassagem);
  if(passagem){
    const p=obterPassagemV2PorId_(passagem);if(!p) throw new Error('Passagem não encontrada.');
    if(pessoa&&pessoa!==p.ID_Pessoa) throw new Error('Pessoa não corresponde à passagem.');
    pessoa=p.ID_Pessoa;
  }
  if(pessoa&&!obterPessoaV2PorId_(pessoa)) throw new Error('Pessoa não encontrada.');
  return {'Título':textoTrV2_(dados.titulo),'Descrição':textoTrV2_(dados.descricao),'Responsável':textoTrV2_(dados.responsavel),
    'Prioridade':prioridade,'Prazo':prazo,'Status':'Pendente','ID_Pessoa':pessoa,'ID_Passagem':passagem,'Criado_Em':new Date()};
}
function criarTarefaV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{return {ok:true,tarefa:gravarTrV2_('TAREFAS',validarTarefaTrV2_(dados),'TAR')};}finally{lock.releaseLock();}
}
function atualizarStatusTarefaV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const achado=localizarTrV2_('TAREFAS',dados.idTarefa);if(!achado) throw new Error('Tarefa não encontrada.');
    const r=achado.registro,status=textoTrV2_(dados.status),nota=textoTrV2_(dados.observacoes);
    if(V2_TR_STATUS_TAREFA.indexOf(r.Status)<0||V2_TR_STATUS_TAREFA.indexOf(status)<0) throw new Error('Status de tarefa inválido.');
    if(status===r.Status) return {ok:true,semAlteracao:true,tarefa:r};
    if(['Concluída','Cancelada'].indexOf(r.Status)>=0) throw new Error('Tarefa finalizada; reabertura não implementada.');
    if(['Concluída','Cancelada'].indexOf(status)>=0&&!nota) throw new Error('Observação é obrigatória para finalizar tarefa.');
    if(r.Status==='Em andamento'&&status==='Pendente') throw new Error('Não é permitido retroceder para Pendente.');
    atualizarCamposTrV2_('TAREFAS',achado,{'Descrição':historicoTrV2_(r['Descrição'],r.Status+' → '+status,nota),'Status':status});
    return {ok:true,tarefa:obterTarefaV2PorId(r.ID_Tarefa)};
  }finally{lock.releaseLock();}
}
function validarRotinaTrV2_(dados){
  dados=dados||{};
  ['rotina','responsavel'].forEach(function(c){if(!textoTrV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  const frequencia=textoTrV2_(dados.frequencia);
  if(V2_TR_FREQUENCIAS.indexOf(frequencia)<0) throw new Error('Frequência inválida.');
  return {'Rotina':textoTrV2_(dados.rotina),'Frequência':frequencia,'Responsável':textoTrV2_(dados.responsavel),
    'Próxima Execução':dataAtendimentoV2_(dados.proximaExecucao,'Próxima execução').br,'Status':'Ativa','Observações':textoTrV2_(dados.observacoes)};
}
function criarRotinaV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{return {ok:true,rotina:gravarTrV2_('ROTINAS',validarRotinaTrV2_(dados),'ROT')};}finally{lock.releaseLock();}
}
function proximaDataRotinaV2_(valor,frequencia){
  if(V2_TR_FREQUENCIAS.indexOf(frequencia)<0) throw new Error('Frequência inválida.');
  const iso=dataAtendimentoV2_(valor,'Data prevista').iso;
  const partes=iso.split('-').map(Number),d=new Date(Date.UTC(partes[0],partes[1]-1,partes[2]));
  if(frequencia==='Mensal'){
    const limite=new Date(Date.UTC(partes[0],partes[1]+1,0)).getUTCDate();
    d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+1);d.setUTCDate(Math.min(partes[2],limite));
  }else{d.setUTCDate(d.getUTCDate()+({'Diária':1,'Semanal':7,'Quinzenal':14}[frequencia]));}
  return dataAtendimentoV2_(d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0'),'Próxima execução').br;
}
function registrarExecucaoRotinaV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const achado=localizarTrV2_('ROTINAS',dados.idRotina);if(!achado) throw new Error('Rotina não encontrada.');
    const r=achado.registro;if(r.Status!=='Ativa') throw new Error('Rotina não está ativa.');
    const prevista=dataAtendimentoV2_(r['Próxima Execução'],'Data prevista');
    const esperada=dataAtendimentoV2_(dados.dataPrevista,'Data prevista informada');
    if(prevista.iso!==esperada.iso) throw new Error('Data prevista já foi atualizada; consulte a rotina antes de repetir.');
    const executada=dataAtendimentoV2_(dados.dataExecucao,'Data da execução');
    if(executada.iso<prevista.iso) throw new Error('Execução anterior à data prevista.');
    if(executada.iso>Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')) throw new Error('Execução não pode ser futura.');
    const nota=textoTrV2_(dados.observacoes);if(!nota) throw new Error('Observação da execução é obrigatória.');
    const proxima=proximaDataRotinaV2_(prevista.br,r['Frequência']);
    atualizarCamposTrV2_('ROTINAS',achado,{'Observações':historicoTrV2_(r['Observações'],
      'Execução prevista para '+prevista.br+' realizada em '+executada.br,nota),'Próxima Execução':proxima});
    return {ok:true,rotina:obterRotinaV2PorId(r.ID_Rotina),dataPrevistaExecutada:prevista.br};
  }finally{lock.releaseLock();}
}
function atualizarStatusRotinaV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const achado=localizarTrV2_('ROTINAS',dados.idRotina);if(!achado) throw new Error('Rotina não encontrada.');
    const r=achado.registro,status=textoTrV2_(dados.status),nota=textoTrV2_(dados.observacoes);
    if(['Ativa','Pausada'].indexOf(status)<0||['Ativa','Pausada'].indexOf(r.Status)<0) throw new Error('Status de rotina inválido.');
    if(status===r.Status) return {ok:true,semAlteracao:true,rotina:r};
    if(!nota) throw new Error('Observação da mudança de status é obrigatória.');
    atualizarCamposTrV2_('ROTINAS',achado,{'Observações':historicoTrV2_(r['Observações'],r.Status+' → '+status,nota),'Status':status});
    return {ok:true,rotina:obterRotinaV2PorId(r.ID_Rotina)};
  }finally{lock.releaseLock();}
}
