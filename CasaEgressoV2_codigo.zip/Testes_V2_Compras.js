/** Execute 42 a 46. Cria uma solicitação fictícia; não gera lançamento financeiro. */
function fixtureComV2_(){return {item:'[TESTE-COM-V2-01] Material fictício',quantidade:2,prioridade:'Média',
  solicitante:'SOLICITANTE TESTE V2',dataSolicitacao:'30/09/2026',valorEstimado:50,
  observacoes:'Solicitação fictícia de 2 unidades; estimativa total de R$ 50,00.'};}
function compraTesteComV2_(){
  const d=fixtureComV2_(),lista=listarComprasV2().filter(function(r){return r.Item===d.item;});
  if(lista.length>1) throw new Error('Solicitação de teste duplicada.');
  if(lista.length&&lista[0].Solicitante!==d.solicitante) throw new Error('Solicitante do registro de teste divergente.');
  return lista[0]||null;
}
function TESTE_V2_42_VALIDAR_COMPRAS(){const r=VALIDAR_COMPRAS_V2();console.log(JSON.stringify(r,null,2));return r;}
function TESTE_V2_43_REGISTRAR_COMPRA(){
  const existente=compraTesteComV2_(),r=existente?{ok:true,reutilizado:true,compra:existente}:registrarCompraV2(fixtureComV2_());
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_44_CONSULTAR_COMPRA(){
  const teste=compraTesteComV2_();if(!teste) throw new Error('Execute o teste 43.');
  const r=obterCompraV2PorId(teste.ID_Compra),d=fixtureComV2_();
  if(!r||r.Quantidade!==2||r['Valor Estimado']!==50||r['Data Solicitação']!==d.dataSolicitacao||
      !listarComprasV2({solicitante:d.solicitante,prioridade:d.prioridade}).some(function(v){return v.ID_Compra===r.ID_Compra;})) {
    throw new Error('Dados gravados ou consulta divergentes.');
  }
  const resultado={ok:true,consultaPorSolicitante:true,compra:r};console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_45_CONCLUIR_COMPRA(){
  let r=compraTesteComV2_();if(!r) throw new Error('Execute o teste 43.');
  if(r.Status==='Solicitada') r=atualizarCompraV2({idCompra:r.ID_Compra,status:'Em cotação',observacoes:'Cotação fictícia iniciada.'}).compra;
  if(r.Status==='Em cotação') r=atualizarCompraV2({idCompra:r.ID_Compra,status:'Aprovada',observacoes:'Aprovação fictícia para o teste.'}).compra;
  const resultado=atualizarCompraV2({idCompra:r.ID_Compra,status:'Comprada',
    observacoes:r.Status==='Comprada'?'':'[TESTE-COM-CONCLUSAO] Compra fictícia concluída, sem pagamento real.'});
  const salvo=obterCompraV2PorId(r.ID_Compra);
  if(salvo.Status!=='Comprada'||salvo['Observações'].indexOf(fixtureComV2_().observacoes)<0||
    salvo['Observações'].indexOf('[TESTE-COM-CONCLUSAO]')<0) throw new Error('Falha na conclusão ou preservação do histórico.');
  resultado.observacoesPreservadas=true;console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_46_BLOQUEAR_COMPRAS_INVALIDAS(){
  const d=fixtureComV2_(),casos=[
    {nome:'Item vazio',dados:{item:''},erro:'Campo obrigatório: item'},
    {nome:'Quantidade zero',dados:{quantidade:0},erro:'Quantidade inválido'},
    {nome:'Quantidade negativa',dados:{quantidade:-1},erro:'Quantidade inválido'},
    {nome:'Solicitante vazio',dados:{solicitante:''},erro:'Campo obrigatório: solicitante'},
    {nome:'Valor negativo',dados:{valorEstimado:-1},erro:'Valor estimado inválido'},
    {nome:'Prioridade inválida',dados:{prioridade:'Inexistente'},erro:'Prioridade inválida'},
    {nome:'Data inexistente',dados:{dataSolicitacao:'31/02/2026'},erro:'data inválida'}
  ];
  const testes=casos.map(function(c){
    try{validarCompraComV2_(Object.assign({},d,c.dados));}catch(e){
      if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;
    }throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
