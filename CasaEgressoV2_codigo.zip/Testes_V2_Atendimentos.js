/** Execute 06, 07, 08 e 09, uma função por vez. Usa somente o cadastro de teste. */
function fixtureAtendimentoV2_() {
  const pessoa = obterPessoaV2PorId_('PES-F1C07550EC5D');
  if (!pessoa || pessoa['Nome Completo'] !== 'PESSOA TESTE V2') {
    throw new Error('Cadastro de teste não confirmado; nenhum dado foi escrito.');
  }
  const passagem = obterPassagemV2PorId_('PAS-F5E882F87A8E');
  if (!passagem || passagem.ID_Pessoa !== pessoa.ID_Pessoa) {
    throw new Error('Passagem de teste não confirmada.');
  }
  return {
    idPessoa: pessoa.ID_Pessoa, idPassagem: passagem.ID_Passagem,
    data: '30/09/2026', hora: '10:00', tipo: 'Acolhimento / Escuta',
    assunto: '[TESTE-ATE-V2-01] Validação de atendimento',
    responsavel: 'Responsável Teste',
    registro: 'Registro fictício para testar o módulo de atendimentos V2.',
    resultado: 'Orientações registradas no teste.',
    proximosPassos: 'Conferir consulta por passagem e por pessoa.',
    status: 'Concluído', anexos: ''
  };
}

function TESTE_V2_06_VALIDAR_ATENDIMENTOS() {
  const r = VALIDAR_ATENDIMENTOS_V2();
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_07_REGISTRAR_ATENDIMENTO() {
  const d = fixtureAtendimentoV2_();
  const existentes = obterAtendimentosPassagemV2(d.idPassagem).filter(function(a) {
    return a['Assunto / Motivo'] === d.assunto;
  });
  if (existentes.length > 1) throw new Error('Mais de um atendimento com o marcador do teste.');
  // Reexecução não acrescenta outra linha do mesmo teste.
  const r = existentes.length ? {ok: true, reutilizado: true, atendimento: existentes[0]} :
    registrarAtendimentoV2(d);
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_08_CONSULTAR_ATENDIMENTO() {
  const d = fixtureAtendimentoV2_();
  const lista = obterAtendimentosPassagemV2(d.idPassagem);
  const teste = lista.filter(function(a) { return a['Assunto / Motivo'] === d.assunto; });
  if (teste.length !== 1) throw new Error('Execute o teste 07; esperado um atendimento de teste.');
  const a = obterAtendimentoV2PorId(teste[0].ID_Atendimento);
  if (!a || a.ID_Pessoa !== d.idPessoa || a.ID_Passagem !== d.idPassagem ||
      a.Registro !== d.registro || a.Status !== d.status) {
    throw new Error('Dados gravados diferentes dos esperados.');
  }
  if (!obterAtendimentosPessoaV2(d.idPessoa).some(function(v) {
    return v.ID_Atendimento === a.ID_Atendimento;
  })) throw new Error('Atendimento ausente no histórico da pessoa.');
  const r = {ok: true, atendimento: a, consultaPorPessoa: true, consultaPorPassagem: true};
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_09_BLOQUEAR_DADOS_INVALIDOS() {
  const d = fixtureAtendimentoV2_();
  const casos = [
    {nome: 'Pessoa divergente', alteracao: {idPessoa: 'PES-TESTE-DIVERGENTE'}, erro: 'não corresponde'},
    {nome: 'Data inexistente', alteracao: {data: '31/02/2026'}, erro: 'data inválida'},
    {nome: 'Antes da entrada', alteracao: {data: '24/09/2026'}, erro: 'anterior à entrada'},
    {nome: 'Hora inválida', alteracao: {hora: '25:70'}, erro: 'Hora inválida'},
    {nome: 'Registro vazio', alteracao: {registro: ''}, erro: 'Campo obrigatório: registro'}
  ];
  const r = casos.map(function(caso) {
    try { validarDadosAtendimentoV2_(Object.assign({}, d, caso.alteracao)); }
    catch (e) {
      if (String(e.message).indexOf(caso.erro) >= 0) return {teste: caso.nome, bloqueado: true};
      throw e;
    }
    throw new Error('Falha: dados inválidos aceitos em ' + caso.nome);
  });
  console.log(JSON.stringify({ok: true, testes: r}, null, 2));
  return r;
}
