function findOpenPassage_(idPessoa){
  const sh=getSpreadsheet_().getSheetByName("PASSAGENS"); if(sh.getLastRow()<2)return null;
  const hs=headers_(sh), rows=sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues();
  const ip=hs.indexOf("ID_Pessoa"), is=hs.indexOf("Status");
  for(let i=0;i<rows.length;i++) if(String(rows[i][ip])===String(idPessoa) && String(rows[i][is]).toUpperCase()==="ABERTA") return {row:i+2,data:rowObject_(hs,rows[i])};
  return null;
}
function criarPassagem(d){
  return withLock_(function(){
    const u=requireRole_(["ADMIN","COORDENACAO","TECNICO"]);
    const ps=getSpreadsheet_().getSheetByName("PESSOAS"), sh=getSpreadsheet_().getSheetByName("PASSAGENS");
    const pessoa=findRowByField_(ps,"ID_Pessoa",d.ID_Pessoa); if(!pessoa)throw new Error("Pessoa não encontrada.");
    if(findOpenPassage_(d.ID_Pessoa))throw new Error("Já existe uma passagem aberta para esta pessoa.");
    const id=newId_("PAS"), now=now_();
    const obj={"ID_Passagem":id,"ID_Pessoa":d.ID_Pessoa,"Data de Entrada":d["Data de Entrada"]||now,"Data de Saída Prevista":d["Data de Saída Prevista"]||"","Data de Saída Efetiva":"","Tipo":d.Tipo||"Acolhimento","Motivo / Objetivo":d["Motivo / Objetivo"]||"","Modalidade":d.Modalidade||"","Quarto":d.Quarto||"","Responsável":d.Responsável||"","Status":"Aberta","ID_Pasta_Drive":"","Link_Pasta_Drive":"","Observações":d.Observações||"","Criado_Em":now,"Criado_Por":u["E-mail"],"Atualizado_Em":now,"Atualizado_Por":u["E-mail"],"Versao":1};
    appendObject_(sh,obj); log_("CRIAR","PASSAGENS",id,"SUCESSO","Apps Script","Passagem criada"); return obj;
  });
}
