/** Execute 15 a 19. Teste 16 cria um pequeno TXT na pasta da passagem fictícia.
 * Não altera arquivos existentes nem suas permissões. Reexecuções reutilizam o TXT.
 */
function fixtureDocV2_() {
  const p=obterPessoaV2PorId_('PES-F1C07550EC5D');
  const s=obterPassagemV2PorId_('PAS-F5E882F87A8E');
  if (!p || p['Nome Completo']!=='PESSOA TESTE V2' || !s || s.ID_Pessoa!==p.ID_Pessoa) {
    throw new Error('Cadastro fictício não confirmado; teste interrompido.');
  }
  return {pessoa:p,passagem:s};
}
function arquivoTesteDocV2_(criar) {
  const f=fixtureDocV2_();
  const pasta=DriveApp.getFolderById(f.passagem.ID_Pasta_Drive);
  const nome='TESTE_DOC_V2_PAS-F5E882F87A8E.txt';
  const arquivos=pasta.getFilesByName(nome);
  if (arquivos.hasNext()) {
    const arquivo=arquivos.next();
    if (arquivos.hasNext()) throw new Error('Mais de um arquivo com o nome de teste.');
    return arquivo;
  }
  if (!criar) throw new Error('Execute o teste 16 primeiro.');
  return pasta.createFile(nome,'Arquivo fictício para validação de DOCUMENTOS V2. Sem dados reais.');
}
function dadosTesteDocV2_(idArquivo) {
  const f=fixtureDocV2_();
  return {idPessoa:f.pessoa.ID_Pessoa,idPassagem:f.passagem.ID_Passagem,
    categoria:'Teste',tipoDocumento:'Comprovante fictício',data:'30/09/2026',
    idArquivoDrive:idArquivo,observacoes:'[TESTE-DOC-V2-01] Registro documental fictício.'};
}
function localizarTesteDocV2_() {
  const arquivo=arquivoTesteDocV2_(false);
  const d=dadosTesteDocV2_(arquivo.getId());
  const lista=obterDocumentosPassagemV2(d.idPassagem).filter(function(r) {
    return r.ID_Arquivo_Drive===d.idArquivoDrive;
  });
  if (lista.length!==1) throw new Error('Esperado um documento de teste; execute 16.');
  return lista[0];
}
function TESTE_V2_15_VALIDAR_DOCUMENTOS() {
  const r=VALIDAR_DOCUMENTOS_V2(); console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_16_REGISTRAR_DOCUMENTO() {
  // Não adquire o mesmo lock dentro de registrarDocumentoV2.
  VALIDAR_DOCUMENTOS_V2();
  const lock=LockService.getScriptLock(); lock.waitLock(20000);
  let arquivo;
  try { arquivo=arquivoTesteDocV2_(true); } finally { lock.releaseLock(); }
  const r=registrarDocumentoV2(dadosTesteDocV2_(arquivo.getId()));
  console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_17_CONSULTAR_DOCUMENTO() {
  const teste=localizarTesteDocV2_(), d=dadosTesteDocV2_(teste.ID_Arquivo_Drive);
  const r=obterDocumentoV2PorId(teste.ID_Documento);
  if (!r || r.ID_Pessoa!==d.idPessoa || r.ID_Passagem!==d.idPassagem ||
      r.Categoria!==d.categoria || r['Tipo de Documento']!==d.tipoDocumento ||
      r.Link_Arquivo!==arquivoTesteDocV2_(false).getUrl()) throw new Error('Divergência nos dados gravados.');
  if (!obterDocumentosPessoaV2(d.idPessoa).some(function(v) { return v.ID_Documento===r.ID_Documento; })) {
    throw new Error('Documento ausente no histórico da pessoa.');
  }
  const resultado={ok:true,consultaPorPessoa:true,consultaPorPassagem:true,documento:r};
  console.log(JSON.stringify(resultado,null,2)); return resultado;
}
function TESTE_V2_18_CONFERIR_DOCUMENTO() {
  const d=localizarTesteDocV2_();
  const r=conferirDocumentoV2({idDocumento:d.ID_Documento,observacoes:'Conferência fictícia para testar o sistema.'});
  if (r.documento.Status!=='Conferido' ||
      r.documento['Observações'].indexOf('[TESTE-DOC-V2-01]')<0 ||
      r.documento['Observações'].indexOf('Conferência fictícia para testar o sistema.')<0) {
    throw new Error('Falha na conferência ou preservação das observações.');
  }
  console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_19_BLOQUEAR_DOCUMENTOS_INVALIDOS() {
  const d=dadosTesteDocV2_('ID_FICTICIO_VALIDACAO_SEM_ACESSO_DRIVE');
  const casos=[
    {nome:'Pessoa divergente',dados:{idPessoa:'PES-DIVERGENTE'},erro:'não corresponde'},
    {nome:'Data inexistente',dados:{data:'31/02/2026'},erro:'data inválida'},
    {nome:'Categoria vazia',dados:{categoria:''},erro:'Campo obrigatório: categoria'},
    {nome:'Arquivo sem ID',dados:{idArquivoDrive:''},erro:'Campo obrigatório: idArquivoDrive'},
    {nome:'Link no lugar do ID',dados:{idArquivoDrive:'https://drive.google.com/file/d/exemplo/view'},erro:'apenas o ID'}
  ];
  const resultados=casos.map(function(c) {
    try { validarDadosDocV2_(Object.assign({},d,c.dados)); }
    catch(e) {
      if (String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};
      throw e;
    }
    throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const r={ok:true,testes:resultados}; console.log(JSON.stringify(r,null,2)); return r;
}
