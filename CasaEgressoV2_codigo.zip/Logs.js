function log_(operacao,entidade,id,resultado,origem,detalhes){
  const sh=getSpreadsheet_().getSheetByName("LOG");
  const u=currentUser_();
  appendObject_(sh,{ID_Log:newId_("LOG"),DataHora:now_(),Usuario:u["E-mail"],Perfil:u.Perfil,Operacao:operacao,Entidade:entidade,ID_Registro:id||"",Resultado:resultado,Origem:origem||"Apps Script",Detalhes:detalhes||""});
}
