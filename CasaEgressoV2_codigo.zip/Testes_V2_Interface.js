/** 67–69: somente leitura e validações locais; não criam cadastros. */
function TESTE_V2_67_VALIDAR_INTERFACE() {
  const r = uiInicioV2();
  const html = HtmlService.createHtmlOutputFromFile('V2_Painel').getContent();
  if (html.indexOf('uiConsultarPessoaV2') < 0 || html.indexOf('uiEncerrarPassagemV2') < 0) throw new Error('HTML incompleto.');
  r.htmlEncontrado = true;
  console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_68_CONSULTAR_PESSOA_INTERFACE() {
  const r = uiConsultarPessoaV2('529.982.247-25');
  if (!r.encontrada || !r.pessoa.id || !Array.isArray(r.passagens)) throw new Error('Pessoa fictícia não encontrada ou resposta inválida.');
  const serializado = JSON.stringify(r);
  if (serializado.indexOf('T07:00') >= 0) throw new Error('Data não normalizada.');
  console.log(serializado); return r;
}
function TESTE_V2_69_VALIDAR_FORMULARIOS() {
  exigirAcessoPlanilhaV2_();
  const base = {idPessoa:'PES-TESTE',dataEntrada:'2026-10-01',tipo:'Teste',modalidade:'Teste'};
  const casos = [
    ['CPF inválido',function(){cpfUiV2_('00000000000');},/CPF/],
    ['Nome vazio',function(){prepararPessoaUiV2_({cpf:'52998224725'});},/Nome completo/],
    ['Data inexistente',function(){prepararPassagemUiV2_(Object.assign({},base,{dataEntrada:'2026-02-30'}));},/data inválida/],
    ['Previsão anterior',function(){prepararPassagemUiV2_(Object.assign({},base,{dataPrevistaSaida:'2026-09-30'}));},/anterior/],
    ['Tipo vazio',function(){prepararPassagemUiV2_(Object.assign({},base,{tipo:''}));},/obrigatório/]
  ];
  const testes = casos.map(function(c){let erro;try{c[1]();}catch(e){erro=e;}
    if(!erro || !c[2].test(erro.message)) throw new Error('Falha no caso '+c[0]);
    return {teste:c[0],bloqueado:true};});
  if(textoUiV2_('=1+1','Teste',false)!=="'=1+1") throw new Error('Proteção de texto falhou.');
  const r={ok:true,testes:testes,textoProtegido:true,somenteLeitura:true};
  console.log(JSON.stringify(r,null,2));return r;
}
