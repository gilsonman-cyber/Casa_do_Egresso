/** Testes 82–84: não registram entradas, saídas nem retornos. */
function TESTE_V2_82_VALIDAR_PAINEL_PORTARIA() {
  const r=uiInicioV2();VALIDAR_VISITANTES_V2();VALIDAR_VEICULOS_V2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Portaria').getContent();
  ['uiEntradaVisitanteV2','uiSaidaVisitanteV2','uiSaidaVeiculoV2','uiRetornoVeiculoV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_83_CONSULTAR_PORTARIA_INTERFACE() {
  const r=uiConsultarPortariaV2();
  const visitante=uiHistoricoPortariaV2({tipo:'Visitante',chave:'DOC-TESTE-VIS-V2-01'});
  const veiculo=uiHistoricoPortariaV2({tipo:'Veículo',chave:'VEICULO-TESTE-V2-01'});
  if(!Array.isArray(r.presentes)||!Array.isArray(r.veiculosFora)||!Array.isArray(visitante.registros)||!Array.isArray(veiculo.registros))throw new Error('Listas inválidas.');
  const resultado={ok:true,presentes:r.presentes.length,veiculosFora:r.veiculosFora.length,
    historicoVisitante:visitante.registros.length,historicoVeiculo:veiculo.registros.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_84_VALIDAR_DADOS_PORTARIA() {
  exigirAcessoPlanilhaV2_();const agora=agoraMovV2_();
  const vis={data:agora.slice(0,10),hora:agora.slice(11,16),nomeVisitante:'Teste',documento:'TESTE',destinoMotivo:'Teste'};
  const vei={data:vis.data,hora:vis.hora,veiculo:'TESTE',condutor:'Teste',km:'100',destinoObjetivo:'Teste'};
  const casos=[['Nome vazio',function(){validarEntradaVisV2_(Object.assign({},vis,{nomeVisitante:''}));},/nomeVisitante/],
    ['Documento vazio',function(){validarEntradaVisV2_(Object.assign({},vis,{documento:''}));},/documento/],
    ['Hora inválida',function(){validarEntradaVisV2_(Object.assign({},vis,{hora:'25:00'}));},/hora inválida/],
    ['Condutor vazio',function(){validarSaidaVeiV2_(Object.assign({},vei,{condutor:''}));},/condutor/],
    ['Km negativo',function(){validarSaidaVeiV2_(Object.assign({},vei,{km:'-1'}));},/Km|km/],
    ['Consulta inválida',function(){uiHistoricoPortariaV2({tipo:'Outro',chave:'TESTE'});},/Tipo de consulta inválido/]];
  const testes=casos.map(function(c){let erro;try{c[1]();}catch(e){erro=e;}
    if(!erro||!c[2].test(erro.message))throw new Error('Bloqueio não confirmado: '+c[0]+(erro?' — '+erro.message:''));
    return {teste:c[0],bloqueado:true};});
  const r={ok:true,testes:testes,somenteLeitura:true};console.log(JSON.stringify(r,null,2));return r;
}
