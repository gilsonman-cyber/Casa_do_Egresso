/** Execute 59 a 63 com a conta ADMIN já cadastrada. Não modifica EQUIPE.
 * Cria/atualiza apenas CONFIG.TESTE_V2_CONTROLES, nove indicadores e logs.
 */
function TESTE_V2_59_VALIDAR_CONTROLES(){
  const r=VALIDAR_CONTROLES_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_60_CONFERIR_USUARIO(){
  const r=obterMeuPerfilV2();
  if(!r.usuario.ativo||r.usuario.perfil!=='ADMIN') throw new Error('Execute esta rodada com o ADMIN cadastrado.');
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_61_CONFIGURACAO_E_LOG(){
  const r=definirConfiguracaoV2({parametro:'TESTE_V2_CONTROLES',valor:'Validado',descricao:'Parâmetro fictício da implantação V2, sem efeito nos módulos.'});
  const salvo=obterConfiguracaoV2('TESTE_V2_CONTROLES');
  if(!salvo||salvo.Valor!=='Validado') throw new Error('Configuração não gravada como esperado.');
  const logs=linhasCtrlV2_('LOG').map(function(v){return v.registro;});
  if(!logs.some(function(l){return l.Origem==='V2_Controles'&&l.Operacao==='DEFINIR_CONFIG'&&
      l.ID_Registro==='TESTE_V2_CONTROLES'&&l.Resultado==='CONCLUIDO'&&l.Perfil==='ADMIN';})) {
    throw new Error('Log administrativo não encontrado.');
  }
  r.consultaConfirmada=true;r.logConfirmado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_62_ATUALIZAR_INDICADORES(){
  const r=atualizarIndicadoresV2();
  const mapa=indicesUnicosCtrlV2_(linhasCtrlV2_('INDICADORES'),'Indicador');
  Object.keys(r.indicadores).forEach(function(nome){
    if(!Object.prototype.hasOwnProperty.call(mapa,nome)||mapa[nome].registro.Valor!==r.indicadores[nome]||
        !mapa[nome].registro['Atualizado em']) throw new Error('Indicador não gravado corretamente: '+nome);
  });
  const logs=linhasCtrlV2_('LOG').map(function(v){return v.registro;});
  if(!logs.some(function(l){return l.ID_Log===r.idLog&&l.Resultado==='CONCLUIDO'&&l.Perfil==='ADMIN';})) {
    throw new Error('Log da atualização de indicadores não encontrado.');
  }
  r.gravacaoConferida=true;r.logConfirmado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_63_BLOQUEAR_CONTROLES_INVALIDOS(){
  // Casos simulados em memória; não inclui, remove ou desativa membros reais.
  const equipe=validarEquipeCtrlV2_([
    {'E-mail':'admin@example.invalid',Nome:'ADMIN FICTÍCIO',Perfil:'ADMIN',Ativo:true},
    {'E-mail':'leitura@example.invalid',Nome:'LEITOR FICTÍCIO',Perfil:'CONSULTA',Ativo:true},
    {'E-mail':'inativo@example.invalid',Nome:'INATIVO FICTÍCIO',Perfil:'ADMIN',Ativo:false}
  ]);
  const casos=[
    {nome:'Usuário não identificado',acao:function(){autorizarEquipeCtrlV2_('',equipe,true);},erro:'não identificado'},
    {nome:'Usuário não cadastrado',acao:function(){autorizarEquipeCtrlV2_('fora@example.invalid',equipe,true);},erro:'não cadastrado'},
    {nome:'Usuário inativo',acao:function(){autorizarEquipeCtrlV2_('inativo@example.invalid',equipe,true);},erro:'inativo'},
    {nome:'Perfil sem ADMIN',acao:function(){autorizarEquipeCtrlV2_('leitura@example.invalid',equipe,true);},erro:'exige perfil ADMIN'},
    {nome:'E-mail duplicado',acao:function(){validarEquipeCtrlV2_([
      {'E-mail':'a@example.invalid',Nome:'A',Perfil:'ADMIN',Ativo:true},
      {'E-mail':'A@example.invalid',Nome:'B',Perfil:'ADMIN',Ativo:true}]);},erro:'duplicado'},
    {nome:'Ativo inválido',acao:function(){ativoCtrlV2_('talvez');},erro:'TRUE ou FALSE'},
    {nome:'Parâmetro inválido',acao:function(){validarConfigCtrlV2_({parametro:'nome com espaço',valor:'teste',descricao:'Teste'});},erro:'Parâmetro inválido'},
    {nome:'Valor não suportado',acao:function(){validarConfigCtrlV2_({parametro:'TESTE',valor:{a:1},descricao:'Teste'});},erro:'texto, número finito ou booleano'}
  ];
  const testes=casos.map(function(c){
    try{c.acao();}catch(e){if(String(e.message).indexOf(c.erro)>=0)return {teste:c.nome,bloqueado:true};throw e;}
    throw new Error('Caso inválido aceito: '+c.nome);
  });
  const r={ok:true,simuladoSemAlterarEquipe:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
