/** CONTATOS + CAPTACAO V2
 * Depende do núcleo, V2_Atendimentos (datas) e V2_Financeiro (validação monetária).
 * Mantém os cabeçalhos. Não envia mensagens/propostas e não gera lançamentos.
 * CAPTACAO.Valor é meta/valor solicitado, não dinheiro recebido.
 * Instituição em CAPTACAO é texto: a estrutura atual não possui ID_Contato.
 * Históricos de alterações ficam em Observações. Sem controle EQUIPE nesta etapa.
 */
const V2_REDE_SCHEMAS={
  CONTATOS:['ID_Contato','Nome / Instituição','Tipo','Responsável','Telefone','E-mail','Endereço','Observações'],
  CAPTACAO:['ID_Captacao','Projeto / Oportunidade','Tipo','Instituição','Prazo','Valor','Status','Responsável','Observações']
};
const V2_REDE_STATUS_CAP=['Identificada','Em elaboração','Enviada','Aprovada','Não aprovada','Cancelada'];
function textoRedeV2_(v){return v===undefined||v===null?'':String(v).trim();}
function seguroRedeV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function estruturaRedeV2_(nome){
  if(!Object.prototype.hasOwnProperty.call(V2_REDE_SCHEMAS,nome)) throw new Error('Módulo desconhecido.');
  const aba=obterAbaV2Core_(nome);if(!aba.getLastColumn()) throw new Error(nome+' sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoRedeV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em '+nome);
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);mapa[c]=i;
  });
  V2_REDE_SCHEMAS[nome].forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_CONTATOS_CAPTACAO_V2(){
  if(typeof dataAtendimentoV2_!=='function'||typeof centavosFinV2_!=='function') throw new Error('Mantenha V2_Atendimentos e V2_Financeiro no projeto.');
  const r={ok:true};Object.keys(V2_REDE_SCHEMAS).forEach(function(nome){
    const e=estruturaRedeV2_(nome);r[nome]={camposObrigatorios:V2_REDE_SCHEMAS[nome].length,registros:Math.max(0,e.aba.getLastRow()-1)};
  });return r;
}
function registrosRedeV2_(nome){
  const e=estruturaRedeV2_(nome),n=e.aba.getLastRow()-1,lista=[],ids={};if(n<1) return lista;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i){
    if(linha.every(function(v){return textoRedeV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,j){r[c]=linha[j];});
    const id=textoRedeV2_(r[V2_REDE_SCHEMAS[nome][0]]);
    if(!id||ids[id]) throw new Error('ID ausente ou duplicado em '+nome);ids[id]=true;
    lista.push({registro:r,linha:i+2});
  });return lista;
}
function localizarRedeV2_(nome,id){
  id=textoRedeV2_(id);if(!id) throw new Error('ID é obrigatório.');
  return registrosRedeV2_(nome).filter(function(v){return v.registro[V2_REDE_SCHEMAS[nome][0]]===id;})[0]||null;
}
function obterContatoV2PorId(id){const v=localizarRedeV2_('CONTATOS',id);return v?v.registro:null;}
function obterCaptacaoV2PorId(id){const v=localizarRedeV2_('CAPTACAO',id);return v?v.registro:null;}
function listarContatosV2(filtros){
  filtros=filtros||{};const busca=textoRedeV2_(filtros.busca).toLowerCase();
  return registrosRedeV2_('CONTATOS').map(function(v){return v.registro;}).filter(function(r){
    return (!filtros.tipo||r.Tipo===filtros.tipo)&&(!busca||
      [r['Nome / Instituição'],r['Responsável'],r['E-mail'],r.Telefone].join(' ').toLowerCase().indexOf(busca)>=0);
  });
}
function listarCaptacoesV2(filtros){
  filtros=filtros||{};
  return registrosRedeV2_('CAPTACAO').map(function(v){return v.registro;}).filter(function(r){
    return (!filtros.status||r.Status===filtros.status)&&(!filtros.responsavel||r['Responsável']===filtros.responsavel)&&
      (!filtros.instituicao||r['Instituição']===filtros.instituicao);
  });
}
function gravarRedeV2_(nome,r,prefixo){
  const e=estruturaRedeV2_(nome),campo=V2_REDE_SCHEMAS[nome][0];r[campo]=gerarIdV2Core_(prefixo);
  if(localizarRedeV2_(nome,r[campo])) throw new Error('ID já existente; tente novamente.');
  const n=e.aba.getLastRow()+1;
  if(nome==='CONTATOS') e.aba.getRange(n,e.mapa.Telefone+1).setNumberFormat('@');
  else {e.aba.getRange(n,e.mapa.Prazo+1).setNumberFormat('@');e.aba.getRange(n,e.mapa.Valor+1).setNumberFormat('0.00');}
  e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroRedeV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();return r;
}
function alterarCamposRedeV2_(nome,achado,campos){
  const e=estruturaRedeV2_(nome);
  Object.keys(campos).forEach(function(c){
    if(c==='Telefone'||c==='Prazo') e.aba.getRange(achado.linha,e.mapa[c]+1).setNumberFormat('@');
    if(c==='Valor') e.aba.getRange(achado.linha,e.mapa[c]+1).setNumberFormat('0.00');
    e.aba.getRange(achado.linha,e.mapa[c]+1).setValue(seguroRedeV2_(campos[c]));
  });SpreadsheetApp.flush();
}
function historicoRedeV2_(anterior,acao,nota){
  const quando=Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm:ss');
  return [textoRedeV2_(anterior),quando+' | '+usuarioV2Core_()+' | '+acao+(nota?'\n'+nota:'')].filter(Boolean).join('\n\n');
}
function validarContatoRedeV2_(dados){
  dados=dados||{};
  ['nomeInstituicao','tipo'].forEach(function(c){if(!textoRedeV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  const email=textoRedeV2_(dados.email);
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('E-mail inválido.');
  return {'Nome / Instituição':textoRedeV2_(dados.nomeInstituicao),'Tipo':textoRedeV2_(dados.tipo),
    'Responsável':textoRedeV2_(dados.responsavel),'Telefone':textoRedeV2_(dados.telefone),'E-mail':email,
    'Endereço':textoRedeV2_(dados.endereco),'Observações':textoRedeV2_(dados.observacoes)};
}
function criarContatoV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{return {ok:true,contato:gravarRedeV2_('CONTATOS',validarContatoRedeV2_(dados),'CON')};}finally{lock.releaseLock();}
}
function atualizarContatoV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const achado=localizarRedeV2_('CONTATOS',dados.idContato);if(!achado) throw new Error('Contato não encontrado.');
    const antes=achado.registro,mapa={nomeInstituicao:'Nome / Instituição',tipo:'Tipo',responsavel:'Responsável',telefone:'Telefone',email:'E-mail',endereco:'Endereço'};
    const proposta={observacoes:antes['Observações']};
    Object.keys(mapa).forEach(function(k){proposta[k]=dados[k]===undefined?antes[mapa[k]]:dados[k];});
    const validado=validarContatoRedeV2_(proposta),mudancas={},detalhes=[];
    Object.keys(mapa).forEach(function(k){const c=mapa[k];if(textoRedeV2_(antes[c])!==validado[c]){
      mudancas[c]=validado[c];detalhes.push(c+': '+textoRedeV2_(antes[c])+' → '+validado[c]);
    }});
    if(!Object.keys(mudancas).length) return {ok:true,semAlteracao:true,contato:antes};
    const motivo=textoRedeV2_(dados.motivo);if(!motivo) throw new Error('Motivo da alteração é obrigatório.');
    const obs=historicoRedeV2_(antes['Observações'],'Contato atualizado',motivo+'\n'+detalhes.join('\n'));
    alterarCamposRedeV2_('CONTATOS',achado,Object.assign({'Observações':obs},mudancas));
    return {ok:true,contato:obterContatoV2PorId(antes.ID_Contato)};
  }finally{lock.releaseLock();}
}
function valorCaptacaoRedeV2_(v){
  if(textoRedeV2_(v)==='') return '';
  if(v===0||textoRedeV2_(v)==='0'||textoRedeV2_(v)==='0,00'||textoRedeV2_(v)==='0.00') return 0;
  return centavosFinV2_(v)/100;
}
function validarCaptacaoRedeV2_(dados){
  dados=dados||{};
  ['projeto','tipo','instituicao','responsavel'].forEach(function(c){if(!textoRedeV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  return {'Projeto / Oportunidade':textoRedeV2_(dados.projeto),'Tipo':textoRedeV2_(dados.tipo),'Instituição':textoRedeV2_(dados.instituicao),
    'Prazo':textoRedeV2_(dados.prazo)?dataAtendimentoV2_(dados.prazo,'Prazo da captação').br:'',
    'Valor':valorCaptacaoRedeV2_(dados.valor),'Status':'Identificada','Responsável':textoRedeV2_(dados.responsavel),
    'Observações':textoRedeV2_(dados.observacoes)};
}
function criarCaptacaoV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{return {ok:true,captacao:gravarRedeV2_('CAPTACAO',validarCaptacaoRedeV2_(dados),'CAP')};}finally{lock.releaseLock();}
}
function atualizarStatusCaptacaoV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const achado=localizarRedeV2_('CAPTACAO',dados.idCaptacao);if(!achado) throw new Error('Captação não encontrada.');
    const r=achado.registro,status=textoRedeV2_(dados.status),nota=textoRedeV2_(dados.observacoes);
    if(V2_REDE_STATUS_CAP.indexOf(r.Status)<0||V2_REDE_STATUS_CAP.indexOf(status)<0) throw new Error('Status de captação inválido.');
    if(status===r.Status) return {ok:true,semAlteracao:true,captacao:r};
    const permitidos={'Identificada':['Em elaboração','Enviada','Cancelada'],
      'Em elaboração':['Enviada','Cancelada'],'Enviada':['Aprovada','Não aprovada','Cancelada']};
    if(!permitidos[r.Status]||permitidos[r.Status].indexOf(status)<0) throw new Error('Transição de captação não permitida.');
    if(!nota) throw new Error('Observação da mudança de status é obrigatória.');
    alterarCamposRedeV2_('CAPTACAO',achado,{'Observações':historicoRedeV2_(r['Observações'],r.Status+' → '+status,nota),'Status':status});
    return {ok:true,captacao:obterCaptacaoV2PorId(r.ID_Captacao)};
  }finally{lock.releaseLock();}
}
