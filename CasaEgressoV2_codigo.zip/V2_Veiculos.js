/** VEICULOS V2: depende do núcleo, V2_Atendimentos e V2_Movimentacoes.
 * Controle de uso dos veículos: Saída e Retorno em linhas distintas.
 * ID_VeiculoRegistro identifica cada evento; Veículo / Placa identifica o veículo.
 * Km = leitura do hodômetro; distância é calculada, sem nova coluna.
 * Não cria cadastro de veículos, pastas ou colunas. Não controla autorização EQUIPE.
 */
const V2_VEI_CAMPOS=['ID_VeiculoRegistro','Data','Hora','Veículo / Placa','Condutor','Km',
  'Movimentação','Destino / Objetivo','Observações','Usuário'];
function textoVeiV2_(v){return v===undefined||v===null?'':String(v).trim();}
function chaveVeiV2_(v){return textoVeiV2_(v).toUpperCase().replace(/[^A-Z0-9]/g,'');}
function seguroVeiV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function kmVeiV2_(valor){
  if(typeof valor!=='number' && !(typeof valor==='string' && /^\d+(?:[.,]\d{1,2})?$/.test(valor.trim()))){
    throw new Error('Km inválido: use número sem separador de milhar, como 10000 ou 10000,5.');
  }
  const n=typeof valor==='number'?valor:Number(valor.trim().replace(',','.'));
  if(!Number.isFinite(n)||n<0||n>Number.MAX_SAFE_INTEGER/100) throw new Error('Km inválido: informe valor não negativo.');
  if(Math.abs(n*100-Math.round(n*100))>0.00001) throw new Error('Km inválido: use no máximo duas casas decimais.');
  return n;
}
function estruturaVeiV2_(){
  const aba=obterAbaV2Core_('VEICULOS');
  if(!aba.getLastColumn()) throw new Error('VEICULOS sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoVeiV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em VEICULOS.');
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);
    mapa[c]=i;
  });
  V2_VEI_CAMPOS.forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_VEICULOS_V2(){
  if(typeof momentoMovV2_!=='function') throw new Error('Mantenha V2_Movimentacoes.gs no projeto.');
  const e=estruturaVeiV2_();
  return {ok:true,aba:'VEICULOS',camposObrigatorios:10,registros:Math.max(0,e.aba.getLastRow()-1)};
}
function registrosVeiV2_(){
  const e=estruturaVeiV2_(),n=e.aba.getLastRow()-1,lista=[],ids={};
  if(n<1) return lista;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha){
    if(linha.every(function(v){return textoVeiV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,i){r[c]=linha[i];});
    const id=textoVeiV2_(r.ID_VeiculoRegistro);
    if(!id||ids[id]) throw new Error('ID_VeiculoRegistro ausente ou duplicado.');
    ids[id]=true;lista.push(r);
  });
  return lista;
}
function obterRegistroVeiculoV2PorId(idRegistro){
  const id=textoVeiV2_(idRegistro);if(!id) throw new Error('ID_VeiculoRegistro é obrigatório.');
  return registrosVeiV2_().filter(function(r){return textoVeiV2_(r.ID_VeiculoRegistro)===id;})[0]||null;
}
function sequenciaVeiV2_(veiculo,registros){
  const chave=chaveVeiV2_(veiculo);if(!chave) throw new Error('Veículo / Placa é obrigatório.');
  const lista=(registros||registrosVeiV2_()).filter(function(r){return chaveVeiV2_(r['Veículo / Placa'])===chave;});
  let horaAnterior='',kmAnterior=-1;
  lista.forEach(function(r,i){
    if(r['Movimentação']!==(i%2===0?'Saída':'Retorno')) throw new Error('Sequência de saída/retorno inconsistente.');
    const momento=momentoMovV2_(r.Data,r.Hora,'Evento existente'),km=kmVeiV2_(r.Km);
    if(momento.chave<horaAnterior) throw new Error('Histórico do veículo fora de ordem cronológica.');
    if(km<kmAnterior) throw new Error('Quilometragem regressiva no histórico existente.');
    horaAnterior=momento.chave;kmAnterior=km;
  });
  return lista;
}
function obterHistoricoVeiculoV2(veiculo){return sequenciaVeiV2_(veiculo);}
function obterVeiculosForaV2(){
  const registros=registrosVeiV2_(),chaves={},fora=[];
  registros.forEach(function(r){
    const chave=chaveVeiV2_(r['Veículo / Placa']);if(!chave) throw new Error('Registro sem veículo.');chaves[chave]=true;
  });
  Object.keys(chaves).forEach(function(chave){
    const lista=sequenciaVeiV2_(chave,registros);if(lista.length%2===1) fora.push(lista[lista.length-1]);
  });
  return fora;
}
function validarSaidaVeiV2_(dados){
  dados=dados||{};
  ['veiculo','condutor','destinoObjetivo'].forEach(function(c){if(!textoVeiV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  if(!chaveVeiV2_(dados.veiculo)) throw new Error('Identificação do veículo inválida.');
  const momento=momentoMovV2_(dados.data,dados.hora,'Saída do veículo');
  if(momento.chave>agoraMovV2_()) throw new Error('Saída efetiva não pode ser futura.');
  return {'Data':momento.data,'Hora':momento.hora,'Veículo / Placa':textoVeiV2_(dados.veiculo),
    'Condutor':textoVeiV2_(dados.condutor),'Km':kmVeiV2_(dados.km),'Movimentação':'Saída',
    'Destino / Objetivo':textoVeiV2_(dados.destinoObjetivo),'Observações':textoVeiV2_(dados.observacoes)};
}
function gravarEventoVeiV2_(r){
  const e=estruturaVeiV2_();r.ID_VeiculoRegistro=gerarIdV2Core_('VEI');
  if(obterRegistroVeiculoV2PorId(r.ID_VeiculoRegistro)) throw new Error('ID já existente; tente novamente.');
  r['Usuário']=usuarioV2Core_();const n=e.aba.getLastRow()+1;
  ['Data','Hora','Veículo / Placa'].forEach(function(c){e.aba.getRange(n,e.mapa[c]+1).setNumberFormat('@');});
  e.aba.getRange(n,e.mapa.Km+1).setNumberFormat('0.##');
  e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroVeiV2_(r[c]===undefined?'':r[c]);})]);
  SpreadsheetApp.flush();return r;
}
function registrarSaidaVeiculoV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    estruturaVeiV2_();const r=validarSaidaVeiV2_(dados),lista=sequenciaVeiV2_(r['Veículo / Placa']);
    if(lista.length%2===1) throw new Error('Veículo já possui saída sem retorno.');
    if(lista.length){
      const ultimo=lista[lista.length-1];
      if(momentoMovV2_(r.Data,r.Hora,'Saída').chave<momentoMovV2_(ultimo.Data,ultimo.Hora,'Último retorno').chave) {
        throw new Error('Saída anterior ao último retorno.');
      }
      if(r.Km<kmVeiV2_(ultimo.Km)) throw new Error('Km menor que o último registro do veículo.');
    }
    return {ok:true,saida:gravarEventoVeiV2_(r)};
  }finally{lock.releaseLock();}
}
function validarRetornoVeiV2_(saida,dados){
  const momento=momentoMovV2_(dados.data,dados.hora,'Retorno do veículo'),km=kmVeiV2_(dados.km);
  if(momento.chave<momentoMovV2_(saida.Data,saida.Hora,'Saída').chave) throw new Error('Retorno anterior à saída.');
  if(momento.chave>agoraMovV2_()) throw new Error('Retorno efetivo não pode ser futuro.');
  if(km<kmVeiV2_(saida.Km)) throw new Error('Km do retorno menor que o da saída.');
  const condutor=dados.condutor===undefined?textoVeiV2_(saida.Condutor):textoVeiV2_(dados.condutor);
  if(!condutor) throw new Error('Condutor do retorno é obrigatório.');
  return {momento:momento,km:km,condutor:condutor,distanciaKm:Math.round((km-kmVeiV2_(saida.Km))*100)/100};
}
function registrarRetornoVeiculoV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const saida=obterRegistroVeiculoV2PorId(dados.idSaida);
    if(!saida||saida['Movimentação']!=='Saída') throw new Error('Saída do veículo não encontrada.');
    const dadosRetorno=validarRetornoVeiV2_(saida,dados),lista=sequenciaVeiV2_(saida['Veículo / Placa']);
    const i=lista.findIndex(function(r){return r.ID_VeiculoRegistro===saida.ID_VeiculoRegistro;});
    if(i<0) throw new Error('Saída ausente no histórico.');
    const existente=lista[i+1];
    if(existente){
      if(momentoMovV2_(existente.Data,existente.Hora,'Retorno existente').chave!==dadosRetorno.momento.chave||
        kmVeiV2_(existente.Km)!==dadosRetorno.km||existente.Condutor!==dadosRetorno.condutor) {
        throw new Error('Retorno já registrado com dados diferentes.');
      }
      return {ok:true,reutilizado:true,idSaida:saida.ID_VeiculoRegistro,retorno:existente,distanciaKm:dadosRetorno.distanciaKm};
    }
    const r=Object.assign({},saida,{'Data':dadosRetorno.momento.data,'Hora':dadosRetorno.momento.hora,
      'Km':dadosRetorno.km,'Condutor':dadosRetorno.condutor,'Movimentação':'Retorno',
      'Observações':['Retorno vinculado à saída '+saida.ID_VeiculoRegistro,textoVeiV2_(dados.observacoes)].filter(Boolean).join('\n\n')});
    return {ok:true,idSaida:saida.ID_VeiculoRegistro,retorno:gravarEventoVeiV2_(r),distanciaKm:dadosRetorno.distanciaKm};
  }finally{lock.releaseLock();}
}
