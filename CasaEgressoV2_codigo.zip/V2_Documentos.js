/** DOCUMENTOS V2. Depende do núcleo V2 e de dataAtendimentoV2_ (V2_Atendimentos).
 * Registra arquivos existentes; não move, exclui ou compartilha arquivos.
 * Data = data do registro documental (não data de emissão do documento).
 * Permite registro após saída da Casa; rejeita passagem cancelada.
 * Status: Registrado -> Conferido. Conferência é uma marcação manual,
 * não uma validação automática do conteúdo ou autenticidade do documento.
 * Não implementa interface, autorização EQUIPE ou integração Notion.
 */
const V2_DOC_CAMPOS = ['ID_Documento','ID_Pessoa','ID_Passagem','Categoria',
  'Tipo de Documento','Data','ID_Arquivo_Drive','Link_Arquivo','Status','Observações','Usuário'];

function textoDocV2_(v) { return v === undefined || v === null ? '' : String(v).trim(); }
function seguroDocV2_(v) { return typeof v === 'string' && /^[=+@-]/.test(v) ? "'" + v : v; }

function estruturaDocV2_() {
  const aba = obterAbaV2Core_('DOCUMENTOS');
  if (!aba.getLastColumn()) throw new Error('DOCUMENTOS sem cabeçalhos.');
  const cab = aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoDocV2_);
  const mapa = {};
  cab.forEach(function(c,i) {
    if (!c) throw new Error('Cabeçalho vazio em DOCUMENTOS.');
    if (Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: ' + c);
    mapa[c] = i;
  });
  V2_DOC_CAMPOS.forEach(function(c) {
    if (!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: ' + c);
  });
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_DOCUMENTOS_V2() {
  if (typeof dataAtendimentoV2_ !== 'function') throw new Error('Mantenha V2_Atendimentos.gs no projeto.');
  const e = estruturaDocV2_();
  return {ok:true,aba:'DOCUMENTOS',camposObrigatorios:11,registros:Math.max(0,e.aba.getLastRow()-1)};
}
function buscarDocV2_(campo,valor) {
  const e = estruturaDocV2_(), n = e.aba.getLastRow()-1, resultado = [];
  if (n < 1) return resultado;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i) {
    if (textoDocV2_(linha[e.mapa[campo]]) !== valor) return;
    const r = {};
    e.cab.forEach(function(c,j) { r[c]=linha[j]; });
    resultado.push({registro:r,linha:i+2});
  });
  return resultado;
}
function obterDocumentoV2PorId(idDocumento) {
  const id = textoDocV2_(idDocumento);
  if (!id) throw new Error('ID_Documento é obrigatório.');
  const lista = buscarDocV2_('ID_Documento',id);
  if (lista.length>1) throw new Error('ID_Documento duplicado.');
  return lista.length ? lista[0].registro : null;
}
function obterDocumentosPessoaV2(idPessoa) {
  const id = textoDocV2_(idPessoa);
  if (!id || !obterPessoaV2PorId_(id)) throw new Error('Pessoa não encontrada.');
  return buscarDocV2_('ID_Pessoa',id).map(function(v) { return v.registro; });
}
function obterDocumentosPassagemV2(idPassagem) {
  const id = textoDocV2_(idPassagem);
  if (!id || !obterPassagemV2PorId_(id)) throw new Error('Passagem não encontrada.');
  return buscarDocV2_('ID_Passagem',id).map(function(v) { return v.registro; });
}
function validarDadosDocV2_(dados) {
  dados = dados || {};
  const id = textoDocV2_(dados.idPassagem);
  if (!id) throw new Error('ID_Passagem é obrigatório.');
  const p = obterPassagemV2PorId_(id);
  if (!p) throw new Error('Passagem não encontrada.');
  if (['Aberta','Encerrada'].indexOf(p.Status)<0) throw new Error('Passagem cancelada ou inválida.');
  const pessoa = textoDocV2_(p.ID_Pessoa);
  if (!obterPessoaV2PorId_(pessoa)) throw new Error('Pessoa da passagem não encontrada.');
  if (dados.idPessoa && textoDocV2_(dados.idPessoa)!==pessoa) throw new Error('Pessoa não corresponde à passagem.');
  ['categoria','tipoDocumento','idArquivoDrive'].forEach(function(c) {
    if (!textoDocV2_(dados[c])) throw new Error('Campo obrigatório: '+c);
  });
  const arquivo = textoDocV2_(dados.idArquivoDrive);
  if (!/^[A-Za-z0-9_-]+$/.test(arquivo)) throw new Error('Informe apenas o ID do arquivo, não o link.');
  const data = dataAtendimentoV2_(dados.data,'Data do registro documental');
  if (data.iso > Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')) {
    throw new Error('Data do registro não pode ser futura.');
  }
  return {'ID_Pessoa':pessoa,'ID_Passagem':id,'Categoria':textoDocV2_(dados.categoria),
    'Tipo de Documento':textoDocV2_(dados.tipoDocumento),'Data':data.br,
    'ID_Arquivo_Drive':arquivo,'Observações':textoDocV2_(dados.observacoes)};
}
function arquivoDocumentoV2_(id) {
  let arquivo;
  try { arquivo = DriveApp.getFileById(id); }
  catch (e) { throw new Error('Arquivo não encontrado ou sem acesso no Drive.'); }
  if (arquivo.isTrashed()) throw new Error('Arquivo está na lixeira.');
  return arquivo;
}
function registrarDocumentoV2(dados) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const e = estruturaDocV2_();
    const r = validarDadosDocV2_(dados);
    const arquivo = arquivoDocumentoV2_(r.ID_Arquivo_Drive);
    const encontrados = buscarDocV2_('ID_Arquivo_Drive',r.ID_Arquivo_Drive)
      .filter(function(v) { return v.registro.ID_Passagem===r.ID_Passagem; });
    if (encontrados.length>1) throw new Error('Arquivo duplicado nesta passagem; revise a aba.');
    if (encontrados.length) {
      const existente = encontrados[0].registro;
      if (existente.ID_Pessoa!==r.ID_Pessoa || existente.Categoria!==r.Categoria ||
          existente['Tipo de Documento']!==r['Tipo de Documento'] ||
          dataAtendimentoV2_(existente.Data,'Data existente').iso!==dataAtendimentoV2_(r.Data,'Data').iso) {
        throw new Error('Arquivo já registrado com dados diferentes nesta passagem.');
      }
      // Não sobrescreve observações de um registro anterior ou conferido.
      if (r['Observações'] && textoDocV2_(existente['Observações'])!==r['Observações'] &&
          textoDocV2_(existente['Observações']).indexOf(r['Observações']+'\n\n')!==0) {
        throw new Error('Arquivo já registrado com observações diferentes.');
      }
      return {ok:true,reutilizado:true,documento:existente};
    }
    r.ID_Documento=gerarIdV2Core_('DOC');
    if (obterDocumentoV2PorId(r.ID_Documento)) throw new Error('ID já existente; tente novamente.');
    r.Link_Arquivo=arquivo.getUrl(); r.Status='Registrado'; r['Usuário']=usuarioV2Core_();
    const n=e.aba.getLastRow()+1;
    e.aba.getRange(n,e.mapa.Data+1).setNumberFormat('@');
    e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c) {
      return seguroDocV2_(r[c]===undefined?'':r[c]);
    })]);
    SpreadsheetApp.flush();
    return {ok:true,documento:r};
  } finally { lock.releaseLock(); }
}
function conferirDocumentoV2(dados) {
  dados=dados||{};
  const id=textoDocV2_(dados.idDocumento);
  if (!id) throw new Error('ID_Documento é obrigatório.');
  const lock=LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const e=estruturaDocV2_(), lista=buscarDocV2_('ID_Documento',id);
    if (lista.length!==1) throw new Error('Documento não encontrado ou ID duplicado.');
    const r=lista[0].registro;
    arquivoDocumentoV2_(r.ID_Arquivo_Drive);
    if (r.Status==='Conferido') return {ok:true,semAlteracao:true,documento:r};
    if (r.Status!=='Registrado') throw new Error('Status atual não permite conferência.');
    const nota=textoDocV2_(dados.observacoes);
    if (!nota) throw new Error('Observação da conferência é obrigatória.');
    const hora=Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm:ss');
    r['Observações']=[textoDocV2_(r['Observações']),hora+' | '+usuarioV2Core_()+' | Conferido\n'+nota]
      .filter(Boolean).join('\n\n');
    r.Status='Conferido';
    // Observação primeiro: se ocorrer falha antes do status, não marca conferência incompleta.
    e.aba.getRange(lista[0].linha,e.mapa['Observações']+1).setValue(seguroDocV2_(r['Observações']));
    e.aba.getRange(lista[0].linha,e.mapa.Status+1).setValue(r.Status);
    SpreadsheetApp.flush();
    return {ok:true,documento:obterDocumentoV2PorId(id)};
  } finally { lock.releaseLock(); }
}
