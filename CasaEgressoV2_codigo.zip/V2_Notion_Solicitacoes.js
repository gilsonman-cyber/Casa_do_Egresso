/** CASA V2 — Solicitações Notion -> núcleo. Requer V2_Notion_Conexao,
 * núcleo V2, V2_Atendimentos e a substituição de exigirAcessoPlanilhaV2_ fornecida no pacote.
 * Não altera onOpen. Não usa dados digitados para identificar o autor.
 * Diário NOTION_SOLICITACOES é autoritativo: não apagar linhas para repetir pedidos.
 */
const N3_SOURCE_='4717c861-1dea-43ff-9295-d3929bf9baf3';
const N3_AUTORES_=Object.freeze({
  '3f0d872b594c81cdb2a20002801c6bf4':'cc.egresso@gmail.com'
});
const N3_CAB_=['ID_Solicitacao','Estado','Autor_Notion','Autor_Email','Acao','Hash','Dados_JSON','ID_Pessoa','ID_Passagem','Mensagem','Criado_Em','Atualizado_Em','Resposta_Enviada','Executor'];
const N3_MAPA_={
 'CPF':'cpf','Nome Completo':'nomeCompleto','Nome Social / Alcunha':'nomeSocial','RG':'rg',
 'Nome da Mãe':'nomeMae','Gênero':'genero','Telefone':'telefone','Contato de Emergência':'contatoEmergencia',
 'Escolaridade':'escolaridade','Profissões / Habilidades':'profissoesHabilidades','Interesse em Cursos':'interesseCursos',
 'Informações Familiares':'informacoesFamiliares','Tipo':'tipo','Modalidade':'modalidade',
 'Motivo / Objetivo':'motivoObjetivo','Quarto':'quarto','Responsável':'responsavel','Observações':'observacoes'
};
var contextoNotionSolicitacaoV2_=null;
function n3Id_(s){return String(s||'').replace(/-/g,'').toLowerCase();}
function n3Falhar_(s){throw new Error(s);}
function n3MesmaBase_(page,source){return page && page.parent && n3Id_(page.parent.data_source_id)===n3Id_(source);}
function n3Campo_(page,nome,tipo){
 const p=page.properties[nome];
 if(!p||p.type!==tipo) n3Falhar_('Campo ausente ou tipo alterado: '+nome);
 return p;
}
function n3Texto_(page,nome){
 const p=n3Campo_(page,nome,'rich_text');
 return (p.rich_text||[]).map(x=>x.plain_text!==undefined?x.plain_text:(x.text||{}).content||'').join('').trim();
}
function n3Dia_(page,nome){
 const d=n3Campo_(page,nome,'date').date;if(!d)return '';
 if(d.end || !/^\d{4}-\d{2}-\d{2}$/.test(d.start)) n3Falhar_('Use uma data sem horário e sem intervalo: '+nome);
 return d.start;
}
function n3Rel_(page,nome){
 const p=n3Campo_(page,nome,'relation');
 if(p.has_more || p.relation.length>1)n3Falhar_('Selecione no máximo um registro: '+nome);
 return p.relation.length?p.relation[0].id:'';
}
function n3Extrair_(page){
 if(!n3MesmaBase_(page,N3_SOURCE_)||page.in_trash||page.archived)n3Falhar_('Solicitação fora da base autorizada ou na lixeira.');
 const d={};Object.keys(N3_MAPA_).forEach(k=>d[N3_MAPA_[k]]=n3Texto_(page,k));
 [['Data de Nascimento','dataNascimento'],['Data de Entrada','dataEntrada'],['Data de Saída Prevista','dataPrevistaSaida'],['Data de Saída Efetiva','dataSaidaEfetiva']].forEach(a=>d[a[1]]=n3Dia_(page,a[0]));
 d.pessoaPagina=n3Rel_(page,'Pessoa');d.passagemPagina=n3Rel_(page,'Passagem');
 const a=n3Campo_(page,'Ação','select').select;d.acao=a?a.name:'';
 if(!['Cadastrar pessoa','Abrir passagem','Encerrar passagem'].includes(d.acao))n3Falhar_('Selecione uma ação válida.');
 if(JSON.stringify(d).length>25000)n3Falhar_('Solicitação muito longa; limite total de 25 mil caracteres.');
 return d;
}
function n3Autor_(page,ss){
 const criador=n3Id_((page.created_by||{}).id),editor=n3Id_((page.last_edited_by||{}).id);
 if(!criador||criador!==editor)n3Falhar_('Crie e envie a solicitação pela mesma conta pessoal do Notion. Não use pedidos criados por uma integração ou editados por outra conta.');
 const email=N3_AUTORES_[criador];if(!email)n3Falhar_('Autor do Notion não habilitado nesta instalação.');
 const a=ss.getSheetByName('EQUIPE');if(!a)n3Falhar_('EQUIPE ausente.');
 const v=a.getDataRange().getValues();
 const usuario=autorizarSegV2_(email,registrosEquipeSegV2_(v[0],v.slice(1)));
 return {notionId:criador,usuario:usuario};
}
function n3ComAutor_(autor,ss,fn){
 if(contextoNotionSolicitacaoV2_)n3Falhar_('Contexto de solicitação já ocupado.');
 contextoNotionSolicitacaoV2_=Object.freeze({id:N2_PLANILHA_,planilha:ss,usuario:Object.freeze(autor.usuario),
   executor:String(Session.getEffectiveUser().getEmail()||'').trim().toLowerCase(),notionId:autor.notionId});
 try{return fn();}finally{contextoNotionSolicitacaoV2_=null;contextoSegV2_=null;}
}
function exigirContextoNotionSolicitacaoV2_(){
 const c=contextoNotionSolicitacaoV2_;
 const efetivo=String(Session.getEffectiveUser().getEmail()||'').trim().toLowerCase();
 if(!c||!efetivo||efetivo!==c.executor||efetivo!==n2Props_().getProperty('CASA_V2_NOTION_EXECUTOR')||
    c.id!==String(configV2Core_().SPREADSHEET_ID)||N3_AUTORES_[c.notionId]!==c.usuario.email)n3Falhar_('Contexto Notion não autorizado.');
 return c;
}
function n3Diario_(ss,criar){
 let a=ss.getSheetByName('NOTION_SOLICITACOES');
 if(!a && criar){a=ss.insertSheet('NOTION_SOLICITACOES');a.getRange(1,1,1,N3_CAB_.length).setValues([N3_CAB_]);a.setFrozenRows(1);}
 if(!a)n3Falhar_('Execute NOTION_V2_INSTALAR_SOLICITACOES primeiro.');
 const cab=a.getRange(1,1,1,a.getLastColumn()).getValues()[0];
 if(JSON.stringify(cab)!==JSON.stringify(N3_CAB_))n3Falhar_('Cabeçalhos do diário foram alterados.');
 return a;
}
function n3Linhas_(a){
 if(a.getLastRow()<2)return [];
 const ids=new Set();return a.getRange(2,1,a.getLastRow()-1,N3_CAB_.length).getValues().map((v,i)=>{
  const r={_linha:i+2};N3_CAB_.forEach((k,j)=>r[k]=v[j]);
  if(!r.ID_Solicitacao||ids.has(r.ID_Solicitacao))n3Falhar_('Diário contém ID vazio ou duplicado.');ids.add(r.ID_Solicitacao);return r;
 });
}
function n3Salvar_(a,r){
 r.Atualizado_Em=new Date().toISOString();
 const vals=N3_CAB_.map(k=>{const v=r[k]===undefined?'':r[k];return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;});
 a.getRange(r._linha,1,1,vals.length).setValues([vals]);SpreadsheetApp.flush();
 const conf=a.getRange(r._linha,1,1,2).getValues()[0];
 if(conf[0]!==r.ID_Solicitacao||conf[1]!==r.Estado)n3Falhar_('Não foi possível confirmar o diário.');
}
function n3Reserva_(a,page,autor,d){
 const lock=LockService.getScriptLock();lock.waitLock(20000);
 try{
  const id=n3Id_(page.id), existente=n3Linhas_(a).find(r=>r.ID_Solicitacao===id);
  if(existente)return {novo:false,registro:existente};
  const json=JSON.stringify(d),r={_linha:a.getLastRow()+1,ID_Solicitacao:id,Estado:'Processando',
   Autor_Notion:autor.notionId,Autor_Email:autor.usuario.email,Acao:d.acao,
   Hash:Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,json,Utilities.Charset.UTF_8)),
   Dados_JSON:json,Mensagem:'Pedido reservado. Não reenviar.',Criado_Em:new Date().toISOString(),Resposta_Enviada:false,
   Executor:String(Session.getEffectiveUser().getEmail()||'')};
  n3Salvar_(a,r);return {novo:true,registro:r};
 }finally{lock.releaseLock();}
}
function n3Responder_(a,r){
 n2Api_('patch','pages/'+r.ID_Solicitacao,{properties:{
  Estado:{select:{name:r.Estado}},Enviar:{checkbox:false},Resultado:{rich_text:n2Texto_(r.Mensagem||'')},
  'ID_Pessoa confirmado':{rich_text:n2Texto_(r.ID_Pessoa||'')},'ID_Passagem confirmado':{rich_text:n2Texto_(r.ID_Passagem||'')},
  'Processado em':{date:{start:new Date(r.Atualizado_Em).toISOString()}}
 }});
 r.Resposta_Enviada=true;n3Salvar_(a,r);
}
function n3Recuperar_(a){
 let total=0;
 for(const r of n3Linhas_(a)){
  if(total>=5)break;
  if(r.Estado==='Processando'){
   // Só alcançado com UserLock exclusivo: a execução anterior já terminou.
   r.Estado='Revisão necessária';r.Mensagem='Execução anterior interrompida. Pode haver gravação parcial. Não reenviar; conferir diário, pessoa, passagem e Drive.';
   r.Resposta_Enviada=false;n3Salvar_(a,r);
  }
  if(r.Resposta_Enviada!==true){n3Responder_(a,r);total++;}
 }
 return total;
}
function n3IdRelacionado_(pagina,base){
 if(!pagina)n3Falhar_('Selecione '+base+' na solicitação.');
 const p=n2Api_('get','pages/'+pagina),b=N2_BASES_[base];
 if(!n3MesmaBase_(p,b.source)||p.archived||p.in_trash)n3Falhar_('Relação fora da base operacional: '+base);
 const v=p.properties[b.id];if(!v)n3Falhar_('ID ausente no registro selecionado.');
 const arr=v.type==='title'?v.title:v.rich_text;
 const id=(arr||[]).map(x=>x.plain_text!==undefined?x.plain_text:(x.text||{}).content||'').join('').trim();
 if(!id)n3Falhar_('Registro selecionado ainda sem ID oficial.');return id;
}
// Validações próprias: não dependem dos painéis da planilha.
function n3CpfEntrada_(valor) {
  const cpf = normalizarCPFV2Core_(valor);
  if (!validarCPFV2Core_(cpf)) throw new Error('Informe um CPF válido.');
  return cpf;
}
function n3DataEntrada_(v, campo, obrigatoria) {
  if (!String(v || '').trim()) {
    if (obrigatoria) throw new Error(campo + ' é obrigatória.');
    return null;
  }
  return dataAtendimentoV2_(v, campo);
}
function n3TextoEntrada_(v, campo, obrigatorio) {
  const s = String(v === undefined || v === null ? '' : v).trim();
  if (obrigatorio && !s) throw new Error(campo + ' é obrigatório.');
  if (s.length > 5000) throw new Error(campo + ': máximo de 5000 caracteres.');
  // Impede interpretação como fórmula ao encaminhar texto para o núcleo.
  return /^[=+@-]/.test(s) ? "'" + s : s;
}
function n3PrepararPessoa_(d) {
  d = d || {};
  const r = {cpf:n3CpfEntrada_(d.cpf), nomeCompleto:n3TextoEntrada_(d.nomeCompleto,'Nome completo',true)};
  ['nomeSocial','rg','nomeMae','genero','telefone','contatoEmergencia','escolaridade',
   'profissoesHabilidades','interesseCursos','informacoesFamiliares','observacoesGerais'].forEach(function(c) {
    r[c] = n3TextoEntrada_(d[c],c,false);
  });
  const nascimento = n3DataEntrada_(d.dataNascimento,'Data de nascimento',false);
  const hoje = Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd');
  if (nascimento && nascimento.iso > hoje) throw new Error('Nascimento não pode ser futuro.');
  r.dataNascimento = nascimento ? nascimento.br : '';
  return r;
}
function n3PrepararPassagem_(d) {
  d = d || {};
  const r = {idPessoa:n3TextoEntrada_(d.idPessoa,'Pessoa',true)};
  const entrada = n3DataEntrada_(d.dataEntrada,'Data de entrada',true);
  const prevista = n3DataEntrada_(d.dataPrevistaSaida,'Saída prevista',false);
  if (prevista && prevista.iso < entrada.iso) throw new Error('Saída prevista anterior à entrada.');
  r.dataEntrada = entrada.br; r.dataPrevistaSaida = prevista ? prevista.br : '';
  ['tipo','modalidade','motivoObjetivo','quarto','responsavel','observacoesEntrada'].forEach(function(c) {
    r[c] = n3TextoEntrada_(d[c],c,c === 'tipo' || c === 'modalidade');
  }); return r;
}

function n3Preparar_(d,id){
 const marca='[NOTION-SOL:'+id+']';
 if(d.acao==='Cadastrar pessoa'){
  if(d.pessoaPagina||d.passagemPagina)n3Falhar_('Cadastro novo não deve selecionar Pessoa ou Passagem.');
  const x=n3PrepararPessoa_(Object.assign({},d,{observacoesGerais:d.observacoes}));
  if(obterPessoaV2PorCPF_(x.cpf))n3Falhar_('CPF já cadastrado. Selecione a pessoa existente para abrir passagem.');
  x.observacoesGerais=(x.observacoesGerais?x.observacoesGerais+'\n\n':'')+marca;return x;
 }
 const idPessoa=n3IdRelacionado_(d.pessoaPagina,'PESSOAS');
 const pessoa=obterPessoaV2PorId_(idPessoa);if(!pessoa)n3Falhar_('Pessoa não encontrada na planilha.');
 if(d.acao==='Abrir passagem'){
  if(d.passagemPagina)n3Falhar_('Para abrir uma nova passagem deixe Passagem vazia.');
  const x=n3PrepararPassagem_(Object.assign({},d,{idPessoa:idPessoa,observacoesEntrada:d.observacoes}));
  if(obterPassagemAbertaV2_(idPessoa))n3Falhar_('Já existe passagem aberta para a pessoa.');
  x.observacoesEntrada=(x.observacoesEntrada?x.observacoesEntrada+'\n\n':'')+marca;return x;
 }
 const idPassagem=n3IdRelacionado_(d.passagemPagina,'PASSAGENS'),p=obterPassagemV2PorId_(idPassagem);
 if(!p||String(p.ID_Pessoa)!==idPessoa)n3Falhar_('Pessoa e passagem divergentes.');
 if(p.Status!=='Aberta')n3Falhar_('A passagem não está aberta.');
 const saida=n3DataEntrada_(d.dataSaidaEfetiva,'Saída efetiva',true),entrada=n3DataEntrada_(p['Data de Entrada'],'Entrada',true);
 if(saida.iso<entrada.iso)n3Falhar_('Saída efetiva anterior à entrada.');
 exigirSemSaidaPendenteV2_(idPassagem);
 return {idPessoa:idPessoa,idPassagem:idPassagem,dataSaidaEfetiva:saida.br,
  observacoesSaida:n3TextoEntrada_(d.observacoes,'Observações',false)+'\n\n'+marca};
}
function n3Executar_(acao,x,id){
 let pessoa,passagem;
 if(acao==='Cadastrar pessoa'){
  pessoa=criarPessoaV2(x);
  pessoa=obterPessoaV2PorId_(pessoa.ID_Pessoa);
  if(!pessoa||!String(pessoa['Observações Gerais']||'').includes('[NOTION-SOL:'+id+']'))n3Falhar_('Cadastro não confirmado como originado deste pedido.');
 }else if(acao==='Abrir passagem'){
  const r=abrirPassagemV2(x);passagem=obterPassagemV2PorId_(r.passagem.ID_Passagem);
  if(!passagem||!String(passagem.Observações||'').includes('[NOTION-SOL:'+id+']'))n3Falhar_('Abertura não confirmada.');
 }else{
  encerrarPassagemV2(x);passagem=obterPassagemV2PorId_(x.idPassagem);
  if(!passagem||passagem.Status!=='Encerrada'||!String(passagem.Observações||'').includes('[NOTION-SOL:'+id+']'))n3Falhar_('Encerramento não confirmado.');
 }
 return {idPessoa:pessoa?pessoa.ID_Pessoa:passagem.ID_Pessoa,idPassagem:passagem?passagem.ID_Passagem:''};
}
function n3Mensagem_(e){return String(e&&e.message||'Falha não identificada.').slice(0,1200);}
function n3Processar_(a,ss,page){
 const existente=n3Linhas_(a).find(r=>r.ID_Solicitacao===n3Id_(page.id));
 if(existente){n3Responder_(a,existente);return 'jaRegistrado';}
 if(!n3Campo_(page,'Enviar','checkbox').checkbox)return 'ignorado';
 // Erros de autoria também ficam registrados; nenhuma identidade de texto é aceita.
 let autor,d,erro;
 try{autor=n3Autor_(page,ss);d=n3Extrair_(page);}catch(e){erro=e;}
 if(erro){
  const reserva=n3Reserva_(a,page,{notionId:n3Id_((page.created_by||{}).id),usuario:{email:''}},{acao:'Não executada'});
  const r=reserva.registro;if(reserva.novo){r.Estado='Rejeitado';r.Mensagem=n3Mensagem_(erro);n3Salvar_(a,r);}n3Responder_(a,r);return r.Estado;
 }
 const res=n3Reserva_(a,page,autor,d),r=res.registro;
 if(!res.novo){n3Responder_(a,r);return 'jaRegistrado';}
 let x;
 try{x=n3ComAutor_(autor,ss,()=>n3Preparar_(d,r.ID_Solicitacao));}
 catch(e){r.Estado='Rejeitado';r.Mensagem=n3Mensagem_(e);n3Salvar_(a,r);n3Responder_(a,r);return r.Estado;}
 // Verifica edição ou cancelamento enquanto validávamos; congela este snapshot.
 const atual=n2Api_('get','pages/'+page.id);
 if(atual.last_edited_time!==page.last_edited_time||!n3Campo_(atual,'Enviar','checkbox').checkbox){
  r.Estado='Rejeitado';r.Mensagem='O pedido mudou durante a validação. Crie um novo pedido com os dados finais.';n3Salvar_(a,r);n3Responder_(a,r);return r.Estado;
 }
 n2Api_('patch','pages/'+page.id,{properties:{Estado:{select:{name:'Processando'}},Resultado:{rich_text:n2Texto_('Pedido recebido. Não editar nem reenviar.')}}});
 // Persistência anterior ao núcleo já concluída. Qualquer falha daqui em diante é incerta.
 try{
  // Revalidar executor e autor na equipe imediatamente antes da mutação.
  n2Autorizar_();
  const v=ss.getSheetByName('EQUIPE').getDataRange().getValues();
  autor.usuario=autorizarSegV2_(autor.usuario.email,registrosEquipeSegV2_(v[0],v.slice(1)));
  const out=n3ComAutor_(autor,ss,()=>n3Executar_(d.acao,x,r.ID_Solicitacao));
  r.ID_Pessoa=out.idPessoa;r.ID_Passagem=out.idPassagem;r.Estado='Confirmado';
  r.Mensagem='Operação confirmada no Sheets. As bases Pessoas e Passagens serão atualizadas pelo ciclo de sincronização.';
 }catch(e){r.Estado='Revisão necessária';r.Mensagem='O núcleo não confirmou a conclusão. Não reenviar antes de conferir possíveis gravações. Detalhe: '+n3Mensagem_(e);}
 r.Resposta_Enviada=false;n3Salvar_(a,r);n3Responder_(a,r);return r.Estado;
}
function NOTION_V2_INSTALAR_SOLICITACOES(){
 exigirAcessoPlanilhaV2_();const ss=n2Autorizar_();
 const lock=LockService.getUserLock();lock.waitLock(1000);
 try{n3Diario_(ss,true);}finally{lock.releaseLock();}
 return NOTION_V2_VALIDAR_SOLICITACOES();
}
function NOTION_V2_VALIDAR_SOLICITACOES(){
 const ss=n2Autorizar_();n3Diario_(ss,false);
 if(!String(exigirAcessoPlanilhaV2_).includes('exigirContextoNotionSolicitacaoV2_'))n3Falhar_('Instale a substituição de exigirAcessoPlanilhaV2_ fornecida no pacote.');
 const dependencias = {
  normalizarCPFV2Core_: typeof normalizarCPFV2Core_,
  validarCPFV2Core_: typeof validarCPFV2Core_,
  configV2Core_: typeof configV2Core_,
  dataAtendimentoV2_: typeof dataAtendimentoV2_,
  exigirSemSaidaPendenteV2_: typeof exigirSemSaidaPendenteV2_,
  criarPessoaV2: typeof criarPessoaV2,
  abrirPassagemV2: typeof abrirPassagemV2,
  encerrarPassagemV2: typeof encerrarPassagemV2,
  obterPessoaV2PorCPF_: typeof obterPessoaV2PorCPF_,
  obterPessoaV2PorId_: typeof obterPessoaV2PorId_,
  obterPassagemAbertaV2_: typeof obterPassagemAbertaV2_,
  obterPassagemV2PorId_: typeof obterPassagemV2PorId_
 };
 Object.keys(dependencias).forEach(function(nome){
  if(dependencias[nome]!=='function')n3Falhar_('Dependência ausente no núcleo: '+nome);
 });
 if(!String(encerrarPassagemV2).includes('exigirSemSaidaPendenteV2_'))n3Falhar_('O encerramento do núcleo deve conter o bloqueio de saída pendente já instalado.');
 const s=n2Api_('get','data_sources/'+N3_SOURCE_);
 ['Solicitação','Ação','Enviar','Estado','Pessoa','Passagem','Resultado','ID_Pessoa confirmado','ID_Passagem confirmado','Processado em'].concat(Object.keys(N3_MAPA_),['Data de Nascimento','Data de Entrada','Data de Saída Prevista','Data de Saída Efetiva']).forEach(k=>{if(!s.properties[k])n3Falhar_('Campo ausente na fila: '+k);});
 const v=ss.getSheetByName('EQUIPE').getDataRange().getValues();
 Object.values(N3_AUTORES_).forEach(e=>autorizarSegV2_(e,registrosEquipeSegV2_(v[0],v.slice(1))));
 const r={ok:true,diario:'NOTION_SOLICITACOES',autoresHabilitados:Object.keys(N3_AUTORES_).length,executouPedidos:false};console.log(JSON.stringify(r));return r;
}
function NOTION_V2_PROCESSAR_SOLICITACOES(){
 // UserLock separa processadores sem reter o ScriptLock utilizado pelo núcleo.
 const lock=LockService.getUserLock();if(!lock.tryLock(1000))return {ok:false,motivo:'Processador já em execução.'};
 try{
  const inicio=Date.now(),ss=n2Autorizar_(),a=n3Diario_(ss,false),recuperados=n3Recuperar_(a);
  const q=n2Api_('post','data_sources/'+N3_SOURCE_+'/query',{
   filter:{property:'Enviar',checkbox:{equals:true}},sorts:[{timestamp:'created_time',direction:'ascending'}],page_size:3
  });
  const resultados=[];
  for(const p of q.results){
   if(Date.now()-inicio>180000)break;
   // GET fresco: query serve apenas para descobrir IDs.
   const atual=n2Api_('get','pages/'+p.id);
   resultados.push({solicitacao:n3Id_(p.id),estado:n3Processar_(a,ss,atual)});
  }
  const r={ok:true,respostasRecuperadas:recuperados,resultados:resultados};console.log(JSON.stringify(r));return r;
 }finally{contextoNotionSolicitacaoV2_=null;lock.releaseLock();}
}
function NOTION_V2_ATIVAR_SOLICITACOES(){
 exigirAcessoPlanilhaV2_();NOTION_V2_VALIDAR_SOLICITACOES();
 const fn='NOTION_V2_PROCESSAR_SOLICITACOES';
 if(!ScriptApp.getProjectTriggers().some(t=>t.getHandlerFunction()===fn))ScriptApp.newTrigger(fn).timeBased().everyMinutes(5).create();
 return {ok:true,intervaloMinutos:5};
}
function NOTION_V2_PAUSAR_SOLICITACOES(){
 exigirAcessoPlanilhaV2_();
 ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='NOTION_V2_PROCESSAR_SOLICITACOES').forEach(t=>ScriptApp.deleteTrigger(t));
 return {ok:true,pausado:true};
}
