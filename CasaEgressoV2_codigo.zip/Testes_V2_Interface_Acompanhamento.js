/** Testes 70–72: sem gravações. */
function TESTE_V2_70_VALIDAR_PAINEL_ACOMPANHAMENTO() {
  const r=uiInicioV2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Acompanhamento').getContent();
  ['uiRegistrarAtendimentoV2','uiRegistrarEncaminhamentoV2','uiAtualizarEncaminhamentoV2'].forEach(function(n){
    if(html.indexOf(n)<0) throw new Error('HTML incompleto: '+n);
  });
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_71_CONSULTAR_ACOMPANHAMENTO_INTERFACE() {
  const pessoa=uiConsultarPessoaV2('529.982.247-25');
  if(!pessoa.encontrada) throw new Error('Pessoa fictícia não encontrada.');
  const p=pessoa.passagens.filter(function(p){return p.id==='PAS-F5E882F87A8E';})[0];
  if(!p) throw new Error('Passagem dos testes anteriores não encontrada.');
  const r=uiConsultarAcompanhamentoV2({idPessoa:pessoa.pessoa.id,idPassagem:p.id});
  if(!Array.isArray(r.atendimentos)||!Array.isArray(r.encaminhamentos)) throw new Error('Listas inválidas.');
  const resultado={ok:true,idPassagem:p.id,atendimentos:r.atendimentos.length,encaminhamentos:r.encaminhamentos.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_72_BLOQUEAR_VINCULOS_INTERFACE() {
  exigirAcessoPlanilhaV2_();
  const d={idPessoa:'PESSOA-INEXISTENTE-TESTE',idPassagem:'PAS-F5E882F87A8E'};
  const chamadas=[['Consulta',uiConsultarAcompanhamentoV2],['Atendimento',uiRegistrarAtendimentoV2],
    ['Encaminhamento',uiRegistrarEncaminhamentoV2],['Atualização',uiAtualizarEncaminhamentoV2]];
  const testes=chamadas.map(function(c){let erro;try{c[1](d);}catch(e){erro=e;}
    if(!erro||erro.message.indexOf('Pessoa e passagem divergentes')<0) throw new Error('Bloqueio não confirmado: '+c[0]);
    return {teste:c[0],bloqueado:true};});
  const r={ok:true,testes:testes,somenteLeitura:true};console.log(JSON.stringify(r,null,2));return r;
}
