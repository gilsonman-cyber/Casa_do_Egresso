/** Interface de contatos e captação; utiliza os módulos existentes. */
function abrirContatosCaptacaoV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Contatos_Captacao')
    .setWidth(920).setHeight(720),'Casa • Contatos e Captação');
}
function uiConsultarContatosCaptacaoV2() {
  exigirAcessoPlanilhaV2_();
  return {ok:true,contatos:serializarAcompV2_(listarContatosV2({})),captacoes:serializarAcompV2_(listarCaptacoesV2({}))};
}
function uiCriarContatoV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['nomeInstituicao','tipo','responsavel','telefone','email','endereco','observacoes']);
  const r=criarContatoV2(d);return {ok:true,id:r.contato.ID_Contato,mensagem:'Contato criado.'};
}
function uiAtualizarContatoV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['idContato','nomeInstituicao','tipo','responsavel','telefone','email','endereco','motivo']);
  const r=atualizarContatoV2(d);return {ok:true,id:r.contato.ID_Contato,mensagem:r.semAlteracao?'Nenhum dado do contato foi alterado.':'Contato atualizado.'};
}
function uiCriarCaptacaoV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['projeto','tipo','instituicao','responsavel','prazo','valor','observacoes']);
  const r=criarCaptacaoV2(d);return {ok:true,id:r.captacao.ID_Captacao,mensagem:'Oportunidade cadastrada.'};
}
function uiStatusCaptacaoV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['idCaptacao','status','observacoes']);
  const r=atualizarStatusCaptacaoV2(d);return {ok:true,id:r.captacao.ID_Captacao,mensagem:r.semAlteracao?'Oportunidade já estava nesse status.':'Status atualizado.'};
}
