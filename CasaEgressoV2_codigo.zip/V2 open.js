function onOpen(e) {
  criarMenuCasaV2();
}



function criarMenuCasaV2() {
  const ui = SpreadsheetApp.getUi();

    ui.createMenu('Casa • V2')
    .addItem('Indicadores', 'abrirIndicadoresV2')
    .addSeparator()
    .addSubMenu(
      ui.createMenu('Pessoas e passagens')
        .addItem('Abrir painel', 'abrirPainelCasaV2')
    )
    .addSubMenu(
      ui.createMenu('Acompanhamento')
        .addItem('Atendimentos e encaminhamentos', 'abrirAcompanhamentoV2')
    )
    .addSubMenu(
      ui.createMenu('Documentos')
        .addItem('Consultar e registrar documentos', 'abrirDocumentosV2')
    )
    .addSubMenu(
      ui.createMenu('Movimentações')
        .addItem('Saídas e retornos', 'abrirMovimentacoesV2')
    )
    .addSubMenu(
      ui.createMenu('Portaria')
        .addItem('Visitantes e veículos', 'abrirPortariaV2')
    )
    .addSeparator()
        .addSubMenu(
      ui.createMenu('Administrativo')
        .addItem('Financeiro e Compras', 'abrirAdministrativoV2')
        .addItem('Tarefas e Rotinas', 'abrirTarefasRotinasV2')
        .addItem('Contatos e Captação', 'abrirContatosCaptacaoV2')
    )
    .addToUi();
}