/** Interface de tarefas e rotinas. Reutiliza backend e autorização existentes. */
function abrirTarefasRotinasV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Tarefas_Rotinas')
    .setWidth(920).setHeight(720),'Casa • Tarefas e Rotinas');
}
function uiConsultarTarefasRotinasV2() {
  exigirAcessoPlanilhaV2_();
  const converter=function(lista){return lista.map(function(r){const c=Object.assign({},r);
    ['Prazo','Próxima Execução'].forEach(function(k){if(c[k])c[k]=dataAtendimentoV2_(c[k],k).br;});
    return serializarAcompV2_([c])[0];});};
  return {ok:true,tarefas:converter(listarTarefasV2({})),rotinas:converter(listarRotinasV2('')),
    hoje:Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')};
}
function uiCriarTarefaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['titulo','descricao','responsavel','prioridade','prazo','cpfPessoa','idPassagem']);
  if(d.cpfPessoa){const p=obterPessoaV2PorCPF_(cpfUiV2_(d.cpfPessoa));if(!p)throw new Error('Pessoa não encontrada pelo CPF.');d.idPessoa=p.ID_Pessoa;}
  if(d.idPassagem&&!d.idPessoa)throw new Error('Informe o CPF da pessoa para vincular uma passagem.');
  const r=criarTarefaV2(d);return {ok:true,id:r.tarefa.ID_Tarefa,mensagem:'Tarefa criada.'};
}
function uiStatusTarefaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['idTarefa','status','observacoes']);
  const r=atualizarStatusTarefaV2(d);return {ok:true,id:r.tarefa.ID_Tarefa,mensagem:r.semAlteracao?'Tarefa já estava nesse status; nenhuma alteração.':'Tarefa atualizada.'};
}
function uiCriarRotinaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['rotina','responsavel','frequencia','proximaExecucao','observacoes']);
  const r=criarRotinaV2(d);return {ok:true,id:r.rotina.ID_Rotina,mensagem:'Rotina criada.'};
}
function uiExecutarRotinaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['idRotina','dataPrevista','dataExecucao','observacoes']);
  const r=registrarExecucaoRotinaV2(d);
  return {ok:true,id:r.rotina.ID_Rotina,mensagem:'Execução registrada. Próxima execução: '+dataAtendimentoV2_(r.rotina['Próxima Execução'],'Próxima execução').br};
}
function uiStatusRotinaV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['idRotina','status','observacoes']);
  const r=atualizarStatusRotinaV2(d);return {ok:true,id:r.rotina.ID_Rotina,mensagem:r.semAlteracao?'Rotina já estava nesse status; nenhuma alteração.':'Status da rotina atualizado.'};
}
