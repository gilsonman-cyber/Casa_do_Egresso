/** Execute 53 a 58. Um contato e uma oportunidade fictícios. Nenhum envio externo. */
function fixtureRedeV2_(){return {
  contato:{nomeInstituicao:'[TESTE-CON-V2-01] Instituição fictícia',tipo:'Parceiro',responsavel:'CONTATO TESTE V2',
    telefone:'TELEFONE FICTÍCIO INICIAL',email:'contato@example.invalid',endereco:'Endereço fictício',observacoes:'Observação original do contato de teste.'},
  captacao:{projeto:'[TESTE-CAP-V2-01] Oportunidade fictícia',tipo:'Edital',instituicao:'Instituição fictícia',prazo:'31/10/2026',
    valor:1000,responsavel:'RESPONSÁVEL TESTE V2',observacoes:'Observação original da oportunidade de teste.'}
};}
function contatoTesteRedeV2_(){
  const d=fixtureRedeV2_().contato,lista=listarContatosV2().filter(function(r){return r['Nome / Instituição']===d.nomeInstituicao;});
  if(lista.length>1) throw new Error('Contato de teste duplicado.');return lista[0]||null;
}
function captacaoTesteRedeV2_(){
  const d=fixtureRedeV2_().captacao,lista=listarCaptacoesV2().filter(function(r){return r['Projeto / Oportunidade']===d.projeto;});
  if(lista.length>1) throw new Error('Captação de teste duplicada.');return lista[0]||null;
}
function TESTE_V2_53_VALIDAR_CONTATOS_CAPTACAO(){
  const r=VALIDAR_CONTATOS_CAPTACAO_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_54_CRIAR_CONTATO(){
  const existente=contatoTesteRedeV2_(),r=existente?{ok:true,reutilizado:true,contato:existente}:criarContatoV2(fixtureRedeV2_().contato);
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_55_CONSULTAR_E_ATUALIZAR_CONTATO(){
  const teste=contatoTesteRedeV2_();if(!teste) throw new Error('Execute o teste 54.');
  if(!listarContatosV2({tipo:'Parceiro',busca:'TESTE-CON-V2-01'}).some(function(r){return r.ID_Contato===teste.ID_Contato;})) {
    throw new Error('Contato ausente na busca.');
  }
  const r=atualizarContatoV2({idContato:teste.ID_Contato,telefone:'TELEFONE FICTÍCIO ATUALIZADO',motivo:'[TESTE-CON-ATUALIZACAO] Atualização fictícia.'});
  const salvo=obterContatoV2PorId(teste.ID_Contato);
  if(salvo.Telefone!=='TELEFONE FICTÍCIO ATUALIZADO'||salvo['E-mail']!=='contato@example.invalid'||
    salvo['Observações'].indexOf(fixtureRedeV2_().contato.observacoes)<0||salvo['Observações'].indexOf('[TESTE-CON-ATUALIZACAO]')<0) {
    throw new Error('Falha na atualização ou preservação dos dados.');
  }
  r.observacoesPreservadas=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_56_CRIAR_CAPTACAO(){
  const existente=captacaoTesteRedeV2_(),r=existente?{ok:true,reutilizado:true,captacao:existente}:criarCaptacaoV2(fixtureRedeV2_().captacao);
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_57_CONSULTAR_E_APROVAR_CAPTACAO(){
  let cap=captacaoTesteRedeV2_();if(!cap) throw new Error('Execute o teste 56.');
  if(!listarCaptacoesV2({responsavel:fixtureRedeV2_().captacao.responsavel,instituicao:'Instituição fictícia'}).some(function(r){return r.ID_Captacao===cap.ID_Captacao;})) {
    throw new Error('Captação ausente na consulta.');
  }
  if(cap.Status==='Identificada') cap=atualizarStatusCaptacaoV2({idCaptacao:cap.ID_Captacao,status:'Em elaboração',observacoes:'Elaboração fictícia iniciada.'}).captacao;
  if(cap.Status==='Em elaboração') cap=atualizarStatusCaptacaoV2({idCaptacao:cap.ID_Captacao,status:'Enviada',observacoes:'Simulação de envio; nenhuma proposta enviada.'}).captacao;
  const r=atualizarStatusCaptacaoV2({idCaptacao:cap.ID_Captacao,status:'Aprovada',observacoes:'[TESTE-CAP-APROVACAO] Aprovação fictícia; nenhum recurso recebido.'});
  const salvo=obterCaptacaoV2PorId(cap.ID_Captacao);
  if(salvo.Status!=='Aprovada'||salvo.Valor!==1000||salvo.Prazo!=='31/10/2026'||
    salvo['Observações'].indexOf(fixtureRedeV2_().captacao.observacoes)<0||salvo['Observações'].indexOf('[TESTE-CAP-APROVACAO]')<0) {
    throw new Error('Falha na atualização ou preservação da oportunidade.');
  }
  r.observacoesPreservadas=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_58_BLOQUEAR_CONTATOS_CAPTACAO_INVALIDOS(){
  const d=fixtureRedeV2_(),casos=[
    {nome:'Contato sem nome',tipo:'contato',dados:{nomeInstituicao:''},erro:'Campo obrigatório: nomeInstituicao'},
    {nome:'Contato sem tipo',tipo:'contato',dados:{tipo:''},erro:'Campo obrigatório: tipo'},
    {nome:'E-mail inválido',tipo:'contato',dados:{email:'email-sem-arroba'},erro:'E-mail inválido'},
    {nome:'Projeto vazio',tipo:'captacao',dados:{projeto:''},erro:'Campo obrigatório: projeto'},
    {nome:'Instituição vazia',tipo:'captacao',dados:{instituicao:''},erro:'Campo obrigatório: instituicao'},
    {nome:'Valor negativo',tipo:'captacao',dados:{valor:-1},erro:'Valor inválido'},
    {nome:'Prazo inexistente',tipo:'captacao',dados:{prazo:'31/02/2026'},erro:'data inválida'}
  ];
  const testes=casos.map(function(c){
    try{(c.tipo==='contato'?validarContatoRedeV2_:validarCaptacaoRedeV2_)(Object.assign({},d[c.tipo],c.dados));}
    catch(e){if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;}
    throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const cap=captacaoTesteRedeV2_();if(!cap) throw new Error('Execute o teste 56.');
  let bloqueado=false;
  try{atualizarStatusCaptacaoV2({idCaptacao:cap.ID_Captacao,status:'Inexistente',observacoes:'Teste sem gravação.'});}
  catch(e){if(String(e.message).indexOf('Status de captação inválido')<0) throw e;bloqueado=true;}
  if(!bloqueado) throw new Error('Status inválido aceito.');testes.push({teste:'Status inválido',bloqueado:true});
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
