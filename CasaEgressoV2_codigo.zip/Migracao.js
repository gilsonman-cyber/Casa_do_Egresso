function gerarRelatorioMigracaoV1(){ return {status:"PREVIA",mensagem:"Migração ainda não executada. V1 permanece intacta."}; }
