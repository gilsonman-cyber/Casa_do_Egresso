function setupV2() {
  const ss = getSpreadsheet_();
  const required = {
    PESSOAS:["ID_Pessoa","Nome Completo","Nome Social / Alcunha","CPF","RG","Data de Nascimento","Nome da Mãe","Gênero","Telefone","Contato de Emergência","Escolaridade","Profissões / Habilidades","Interesse em Cursos","Informações Familiares","Observações Gerais","ID_Pasta_Drive","Link_Pasta_Drive","Data de Cadastro","Status da Pessoa","Criado_Por","Atualizado_Em","Atualizado_Por","Versao"],
    PASSAGENS:["ID_Passagem","ID_Pessoa","Data de Entrada","Data de Saída Prevista","Data de Saída Efetiva","Tipo","Motivo / Objetivo","Modalidade","Quarto","Responsável","Status","ID_Pasta_Drive","Link_Pasta_Drive","Observações","Criado_Em","Criado_Por","Atualizado_Em","Atualizado_Por","Versao"],
    EQUIPE:["E-mail","Nome","Perfil","Ativo"],
    LOG:["ID_Log","DataHora","Usuario","Perfil","Operacao","Entidade","ID_Registro","Resultado","Origem","Detalhes"]
  };
  Object.keys(required).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const headers = required[name];
    const current = sh.getLastColumn() ? sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String) : [];
    if (!current.length || current.every(x => !x.trim())) sh.getRange(1,1,1,headers.length).setValues([headers]);
  });
  return "OK";
}
function doGet(){ return ContentService.createTextOutput(JSON.stringify({ok:true,app:"Casa do Egresso V2"})).setMimeType(ContentService.MimeType.JSON); }
