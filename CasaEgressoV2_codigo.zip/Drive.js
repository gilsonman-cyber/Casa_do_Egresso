function getDriveRoot_(){ const id=getConfig_("DRIVE_ROOT_ID"); if(!id)throw new Error("DRIVE_ROOT_ID não configurado."); return DriveApp.getFolderById(id); }
