/** Execute 10 a 14, uma função por vez. Somente dados fictícios. */
function fixtureEncV2_() {
  const pessoa = obterPessoaV2PorId_('PES-F1C07550EC5D');
  const passagem = obterPassagemV2PorId_('PAS-F5E882F87A8E');
  if (!pessoa || pessoa['Nome Completo'] !== 'PESSOA TESTE V2' || !passagem ||
      passagem.ID_Pessoa !== pessoa.ID_Pessoa) throw new Error('Cadastro de teste não confirmado.');
  return {idPessoa: pessoa.ID_Pessoa, idPassagem: passagem.ID_Passagem,
    data: '30/09/2026', area: 'Documentação', destino: 'Instituição fictícia de teste',
    motivo: '[TESTE-ENC-V2-01] Validação de encaminhamento', responsavel: 'Responsável Teste',
    prazo: '05/10/2026', status: 'Pendente', observacoes: 'Registro fictício; não representa encaminhamento real.'};
}

function localizarTesteEncV2_() {
  const d = fixtureEncV2_();
  const lista = obterEncaminhamentosPassagemV2(d.idPassagem).filter(function(r) { return r.Motivo === d.motivo; });
  if (lista.length > 1) throw new Error('Marcador do teste duplicado.');
  return lista[0] || null;
}

function TESTE_V2_10_VALIDAR_ENCAMINHAMENTOS() {
  const r = VALIDAR_ENCAMINHAMENTOS_V2();
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_11_REGISTRAR_ENCAMINHAMENTO() {
  const existente = localizarTesteEncV2_();
  const r = existente ? {ok: true, reutilizado: true, encaminhamento: existente} :
    registrarEncaminhamentoV2(fixtureEncV2_());
  console.log(JSON.stringify(r, null, 2));
  return r;
}

function TESTE_V2_12_CONSULTAR_ENCAMINHAMENTO() {
  const teste = localizarTesteEncV2_();
  if (!teste) throw new Error('Execute o teste 11.');
  const d = fixtureEncV2_();
  const r = obterEncaminhamentoV2PorId(teste.ID_Encaminhamento);
  if (!r || r.ID_Pessoa !== d.idPessoa || r.ID_Passagem !== d.idPassagem ||
      r.Motivo !== d.motivo || r['Instituição / Destino'] !== d.destino || r.Prazo !== d.prazo) {
    throw new Error('Dados gravados diferentes dos esperados.');
  }
  if (!obterEncaminhamentosPessoaV2(d.idPessoa).some(function(v) {
    return v.ID_Encaminhamento === r.ID_Encaminhamento;
  })) throw new Error('Registro não encontrado no histórico da pessoa.');
  const resultado = {ok: true, consultaPorPessoa: true, consultaPorPassagem: true, encaminhamento: r};
  console.log(JSON.stringify(resultado, null, 2));
  return resultado;
}

function TESTE_V2_13_CONCLUIR_ENCAMINHAMENTO() {
  let r = localizarTesteEncV2_();
  if (!r) throw new Error('Execute o teste 11.');
  if (r.Status === 'Pendente') {
    r = atualizarEncaminhamentoV2({idEncaminhamento: r.ID_Encaminhamento,
      status: 'Em andamento', observacoes: 'Acompanhamento fictício iniciado.'}).encaminhamento;
  }
  const resultado = atualizarEncaminhamentoV2({idEncaminhamento: r.ID_Encaminhamento,
    status: 'Concluído', resultado: 'Teste concluído; documentação fictícia conferida.'});
  const salvo = obterEncaminhamentoV2PorId(r.ID_Encaminhamento);
  if (salvo.Status !== 'Concluído' || salvo.Resultado !== 'Teste concluído; documentação fictícia conferida.' ||
      salvo['Observações'].indexOf(fixtureEncV2_().observacoes) < 0 ||
      salvo['Observações'].indexOf('Acompanhamento fictício iniciado.') < 0) {
    throw new Error('Falha na conclusão ou preservação do histórico.');
  }
  console.log(JSON.stringify(resultado, null, 2));
  return resultado;
}

function TESTE_V2_14_BLOQUEAR_ENCAMINHAMENTOS_INVALIDOS() {
  const d = fixtureEncV2_();
  const casos = [
    {nome: 'Pessoa divergente', dados: {idPessoa: 'PES-DIVERGENTE'}, erro: 'não corresponde'},
    {nome: 'Data inexistente', dados: {data: '31/02/2026'}, erro: 'data inválida'},
    {nome: 'Prazo anterior', dados: {prazo: '29/09/2026'}, erro: 'Prazo anterior'},
    {nome: 'Destino vazio', dados: {destino: ''}, erro: 'Campo obrigatório: destino'},
    {nome: 'Status inicial inválido', dados: {status: 'Concluído'}, erro: 'deve iniciar'}
  ];
  const resultados = casos.map(function(c) {
    try { validarRegistroEncV2_(Object.assign({}, d, c.dados)); }
    catch (e) {
      if (String(e.message).indexOf(c.erro) >= 0) return {teste: c.nome, bloqueado: true};
      throw e;
    }
    throw new Error('Dados inválidos aceitos: ' + c.nome);
  });
  const r = {ok: true, testes: resultados};
  console.log(JSON.stringify(r, null, 2));
  return r;
}
