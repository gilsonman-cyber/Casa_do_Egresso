/** ATENDIMENTOS V2 — adicionar ao mesmo projeto do núcleo Pessoas + Passagens.
 * Não recria abas. Não altera Pessoas, Passagens nem o Drive.
 * Regra desta versão: aceita registro histórico em passagem encerrada,
 * desde que a data esteja dentro do período; rejeita passagem cancelada.
 * Não implementa interface, sincronização Notion nem autorização por EQUIPE.
 */
const V2_ATE_CAMPOS = [
  'ID_Atendimento','ID_Pessoa','ID_Passagem','Data','Hora',
  'Tipo de Atendimento','Assunto / Motivo','Profissional / Responsável',
  'Registro','Resultado','Próximos Passos','Status','Anexos','Usuário','Criado_Em'
];

function estruturaAtendimentosV2_() {
  const aba = obterAbaV2Core_('ATENDIMENTOS');
  const cab = aba.getRange(1, 1, 1, aba.getLastColumn()).getDisplayValues()[0]
    .map(function(v) { return String(v).trim(); });
  const mapa = {};
  cab.forEach(function(c, i) {
    if (!c) throw new Error('Cabeçalho vazio em ATENDIMENTOS, coluna ' + (i + 1));
    if (Object.prototype.hasOwnProperty.call(mapa, c)) {
      throw new Error('Cabeçalho duplicado em ATENDIMENTOS: ' + c);
    }
    mapa[c] = i;
  });
  V2_ATE_CAMPOS.forEach(function(c) {
    if (!Object.prototype.hasOwnProperty.call(mapa, c)) {
      throw new Error('Campo ausente em ATENDIMENTOS: ' + c);
    }
  });
  return {aba: aba, cab: cab, mapa: mapa};
}

function VALIDAR_ATENDIMENTOS_V2() {
  const e = estruturaAtendimentosV2_();
  const r = {ok: true, aba: 'ATENDIMENTOS', camposObrigatorios: V2_ATE_CAMPOS.length,
    registros: Math.max(0, e.aba.getLastRow() - 1)};
  return r;
}

function textoAtendimentoV2_(v) {
  return v === undefined || v === null ? '' : String(v).trim();
}

function dataAtendimentoV2_(valor, campo) {
  let s;
  if (Object.prototype.toString.call(valor) === '[object Date]') {
    if (isNaN(valor.getTime())) throw new Error(campo + ': data inválida.');
    s = Utilities.formatDate(valor, configV2Core_().TIMEZONE, 'yyyy-MM-dd');
  } else {
    s = textoAtendimentoV2_(valor);
  }
  const br = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
  if (br) s = br[3] + '-' + br[2] + '-' + br[1];
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m || Number(m[1]) < 1900 || Number(m[1]) > 9999) {
    throw new Error(campo + ': informe dd/MM/aaaa ou aaaa-MM-dd.');
  }
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  if (d.getUTCFullYear() !== Number(m[1]) || d.getUTCMonth() + 1 !== Number(m[2]) ||
      d.getUTCDate() !== Number(m[3])) throw new Error(campo + ': data inválida.');
  return {iso: s, br: m[3] + '/' + m[2] + '/' + m[1]};
}

function validarDadosAtendimentoV2_(dados) {
  dados = dados || {};
  const idPassagem = textoAtendimentoV2_(dados.idPassagem);
  if (!idPassagem) throw new Error('ID_Passagem é obrigatório.');
  const passagem = obterPassagemV2PorId_(idPassagem);
  if (!passagem) throw new Error('Passagem não encontrada.');
  if (passagem.Status !== 'Aberta' && passagem.Status !== 'Encerrada') {
    throw new Error('Passagem cancelada ou com status inválido.');
  }
  const idPessoa = textoAtendimentoV2_(passagem.ID_Pessoa);
  if (!obterPessoaV2PorId_(idPessoa)) throw new Error('Pessoa da passagem não encontrada.');
  if (dados.idPessoa && textoAtendimentoV2_(dados.idPessoa) !== idPessoa) {
    throw new Error('Pessoa informada não corresponde à pessoa da passagem.');
  }
  const data = dataAtendimentoV2_(dados.data, 'Data do atendimento');
  const entrada = dataAtendimentoV2_(passagem['Data de Entrada'], 'Data de entrada');
  if (data.iso < entrada.iso) throw new Error('Atendimento anterior à entrada.');
  if (passagem.Status === 'Encerrada') {
    const saida = dataAtendimentoV2_(passagem['Data de Saída Efetiva'], 'Saída efetiva');
    if (data.iso > saida.iso) throw new Error('Atendimento posterior à saída efetiva.');
  }
  const hoje = Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'yyyy-MM-dd');
  if (data.iso > hoje) throw new Error('Atendimento realizado não pode ter data futura.');
  const hora = textoAtendimentoV2_(dados.hora);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(hora)) throw new Error('Hora inválida; use HH:mm.');
  ['tipo','assunto','responsavel','registro'].forEach(function(c) {
    if (!textoAtendimentoV2_(dados[c])) throw new Error('Campo obrigatório: ' + c);
  });
  const status = textoAtendimentoV2_(dados.status) || 'Concluído';
  if (['Concluído', 'Em acompanhamento'].indexOf(status) < 0) {
    throw new Error('Status deve ser Concluído ou Em acompanhamento.');
  }
  return {
    'ID_Pessoa': idPessoa, 'ID_Passagem': idPassagem, 'Data': data.br, 'Hora': hora,
    'Tipo de Atendimento': textoAtendimentoV2_(dados.tipo),
    'Assunto / Motivo': textoAtendimentoV2_(dados.assunto),
    'Profissional / Responsável': textoAtendimentoV2_(dados.responsavel),
    'Registro': textoAtendimentoV2_(dados.registro),
    'Resultado': textoAtendimentoV2_(dados.resultado),
    'Próximos Passos': textoAtendimentoV2_(dados.proximosPassos),
    'Status': status, 'Anexos': textoAtendimentoV2_(dados.anexos)
  };
}

function registrarAtendimentoV2(dados) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const e = estruturaAtendimentosV2_();
    const registro = validarDadosAtendimentoV2_(dados);
    registro.ID_Atendimento = gerarIdV2Core_('ATE');
    if (obterAtendimentoV2PorId(registro.ID_Atendimento)) {
      throw new Error('ID de atendimento já existente; tente novamente.');
    }
    registro['Usuário'] = usuarioV2Core_();
    registro.Criado_Em = new Date();
    const linha = e.cab.map(function(c) {
      const v = registro[c] === undefined ? '' : registro[c];
      // Texto vindo do cadastro não deve ser interpretado como fórmula.
      return typeof v === 'string' && /^[=+@-]/.test(v) ? "'" + v : v;
    });
    const n = e.aba.getLastRow() + 1;
    // Evita conversão automática de datas/horas e mantém formato previsível.
    e.aba.getRange(n, e.mapa.Data + 1).setNumberFormat('@');
    e.aba.getRange(n, e.mapa.Hora + 1).setNumberFormat('@');
    e.aba.getRange(n, 1, 1, linha.length).setValues([linha]);
    SpreadsheetApp.flush();
    return {ok: true, atendimento: registro};
  } finally {
    lock.releaseLock();
  }
}

function listarAtendimentosV2_(campo, valor) {
  const e = estruturaAtendimentosV2_();
  const n = e.aba.getLastRow() - 1;
  if (n < 1) return [];
  return e.aba.getRange(2, 1, n, e.cab.length).getValues()
    .filter(function(linha) { return textoAtendimentoV2_(linha[e.mapa[campo]]) === valor; })
    .map(function(linha) {
      const obj = {};
      e.cab.forEach(function(c, i) { obj[c] = linha[i]; });
      return obj;
    });
}

function obterAtendimentoV2PorId(idAtendimento) {
  const id = textoAtendimentoV2_(idAtendimento);
  if (!id) throw new Error('ID_Atendimento é obrigatório.');
  const lista = listarAtendimentosV2_('ID_Atendimento', id);
  if (lista.length > 1) throw new Error('ID_Atendimento duplicado: ' + id);
  return lista[0] || null;
}

function obterAtendimentosPassagemV2(idPassagem) {
  const id = textoAtendimentoV2_(idPassagem);
  if (!id || !obterPassagemV2PorId_(id)) throw new Error('Passagem não encontrada.');
  return listarAtendimentosV2_('ID_Passagem', id);
}

function obterAtendimentosPessoaV2(idPessoa) {
  const id = textoAtendimentoV2_(idPessoa);
  if (!id || !obterPessoaV2PorId_(id)) throw new Error('Pessoa não encontrada.');
  return listarAtendimentosV2_('ID_Pessoa', id);
}
