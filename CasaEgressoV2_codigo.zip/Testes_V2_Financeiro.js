/** Execute 47 a 52. Três lançamentos fictícios; saldo final realizado R$ 60.
 * Categoria exclusiva evita misturar estes valores com quaisquer outros registros.
 */
function fixtureFinV2_(){
  return {categoria:'TESTE-FIN-V2-01',responsavel:'RESPONSÁVEL TESTE V2',data:'30/09/2026'};
}
function lancamentoTesteFinV2_(descricao){
  const lista=listarLancamentosFinanceirosV2({categoria:fixtureFinV2_().categoria}).filter(function(r){return r['Descrição']===descricao;});
  if(lista.length>1) throw new Error('Lançamento de teste duplicado: '+descricao);
  return lista[0]||null;
}
function TESTE_V2_47_VALIDAR_FINANCEIRO(){
  const r=VALIDAR_FINANCEIRO_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_48_REGISTRAR_LANCAMENTOS(){
  const d=fixtureFinV2_(),casos=[
    {descricao:'[TESTE-FIN-ENTRADA] Entrada fictícia',tipo:'Entrada',valor:100,status:'Realizado'},
    {descricao:'[TESTE-FIN-SAIDA] Despesa fictícia',tipo:'Saída',valor:40,status:'Previsto'},
    {descricao:'[TESTE-FIN-CANCELAR] Previsão fictícia',tipo:'Saída',valor:25,status:'Previsto'}
  ];
  const resultados=casos.map(function(c){
    const existente=lancamentoTesteFinV2_(c.descricao);
    if(existente){
      if(existente.Tipo!==c.tipo||existente.Valor!==(c.tipo==='Saída'?-c.valor:c.valor)||existente['Responsável']!==d.responsavel) {
        throw new Error('Registro de teste existente com valores divergentes.');
      }
      return {ok:true,reutilizado:true,lancamento:existente};
    }
    return registrarLancamentoFinanceiroV2(Object.assign({},d,c));
  });
  const r={ok:true,resultados:resultados};console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_49_CONSULTAR_FINANCEIRO(){
  const d=fixtureFinV2_(),lista=listarLancamentosFinanceirosV2({categoria:d.categoria});
  if(lista.length!==3) throw new Error('Esperados três lançamentos; execute o teste 48.');
  lista.forEach(function(r){
    const salvo=obterLancamentoFinanceiroV2PorId(r.ID_Lancamento);
    if(!salvo||salvo.Valor!==r.Valor||salvo.Tipo!==r.Tipo) throw new Error('Consulta divergente.');
  });
  const r={ok:true,consultaPorId:true,resumo:resumoFinanceiroV2({categoria:d.categoria})};
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_50_EFETIVAR_DESPESA(){
  const despesa=lancamentoTesteFinV2_('[TESTE-FIN-SAIDA] Despesa fictícia');if(!despesa) throw new Error('Execute o teste 48.');
  const r=atualizarStatusFinanceiroV2({idLancamento:despesa.ID_Lancamento,status:'Realizado',
    dataEfetiva:'30/09/2026',motivo:'Efetivação fictícia para testar o sistema; nenhum pagamento real.'});
  const resumo=resumoFinanceiroV2({categoria:fixtureFinV2_().categoria});
  if(r.lancamento.Status!=='Realizado'||resumo.realizado.entradas!==100||resumo.realizado.saidas!==40||resumo.realizado.saldo!==60) {
    throw new Error('Efetivação ou saldo realizado incorreto.');
  }
  r.resumo=resumo;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_51_CANCELAR_PREVISAO(){
  const previsto=lancamentoTesteFinV2_('[TESTE-FIN-CANCELAR] Previsão fictícia');if(!previsto) throw new Error('Execute o teste 48.');
  const r=atualizarStatusFinanceiroV2({idLancamento:previsto.ID_Lancamento,status:'Cancelado',motivo:'Cancelamento fictício para validação.'});
  const resumo=resumoFinanceiroV2({categoria:fixtureFinV2_().categoria});
  if(r.lancamento.Status!=='Cancelado'||resumo.cancelados!==1||resumo.previsto.saldo!==0||resumo.realizado.saldo!==60) {
    throw new Error('Cancelamento ou totais incorretos; execute o teste 50 antes.');
  }
  const e=estruturaFinV2_('LOG'),n=e.aba.getLastRow()-1;
  const logs=n>0?e.aba.getRange(2,1,n,e.cab.length).getValues():[];
  if(!logs.some(function(l){return l[e.mapa.ID_Registro]===previsto.ID_Lancamento&&
      l[e.mapa.Operacao]==='ALTERAR_STATUS'&&l[e.mapa.Resultado]==='CONCLUIDO';})) {
    throw new Error('Log de conclusão do cancelamento não encontrado.');
  }
  r.auditoriaConfirmada=true;r.resumo=resumo;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_52_BLOQUEAR_FINANCEIRO_INVALIDO(){
  const d=Object.assign({},fixtureFinV2_(),{tipo:'Entrada',descricao:'Teste de validação sem gravação',valor:10,status:'Realizado'});
  const casos=[
    {nome:'Valor zero',dados:{valor:0},erro:'Valor inválido'},
    {nome:'Valor negativo na entrada da API',dados:{valor:-10},erro:'Valor inválido'},
    {nome:'Mais de duas casas decimais',dados:{valor:1.234},erro:'Valor inválido'},
    {nome:'Tipo inválido',dados:{tipo:'Inexistente'},erro:'Tipo deve ser'},
    {nome:'Categoria vazia',dados:{categoria:''},erro:'Campo obrigatório: categoria'},
    {nome:'Data inexistente',dados:{data:'31/02/2026'},erro:'data inválida'},
    {nome:'Status inicial cancelado',dados:{status:'Cancelado'},erro:'Status inicial inválido'}
  ];
  const testes=casos.map(function(c){
    try{validarLancamentoFinV2_(Object.assign({},d,c.dados));}catch(e){
      if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;
    }throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
