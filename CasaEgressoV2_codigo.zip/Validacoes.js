function validarReferencias_(){ return {ok:true}; }
