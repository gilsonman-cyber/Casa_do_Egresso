/** Execute 20 a 24. Reutiliza a passagem fictícia encerrada, sem criar outra.
 * Datas/horários fixos representam histórico de teste; não são movimentos reais.
 */
function fixtureMovV2_() {
  const p=obterPessoaV2PorId_('PES-F1C07550EC5D');
  const s=obterPassagemV2PorId_('PAS-F5E882F87A8E');
  if (!p || p['Nome Completo']!=='PESSOA TESTE V2' || !s || s.ID_Pessoa!==p.ID_Pessoa) {
    throw new Error('Cadastro fictício não confirmado.');
  }
  return {idPessoa:p.ID_Pessoa,idPassagem:s.ID_Passagem,data:'30/09/2026',hora:'09:00',
    retornoPrevisto:'30/09/2026 11:00',destino:'Local fictício de teste',
    motivo:'[TESTE-MOV-V2-01] Validação de saída e retorno',
    observacoes:'Movimentação fictícia para testar o sistema.',historico:true,
    justificativaHistorico:'Teste de lançamento histórico na passagem fictícia encerrada.'};
}
function localizarTesteMovV2_() {
  const d=fixtureMovV2_();
  const lista=obterMovimentacoesPassagemV2(d.idPassagem).filter(function(r) { return r.Motivo===d.motivo; });
  if (lista.length>1) throw new Error('Marcador de teste duplicado.');
  return lista[0]||null;
}
function TESTE_V2_20_VALIDAR_MOVIMENTACOES() {
  const r=VALIDAR_MOVIMENTACOES_V2(); console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_21_REGISTRAR_SAIDA() {
  const existente=localizarTesteMovV2_();
  const r=existente?{ok:true,reutilizado:true,movimentacao:existente}:registrarSaidaV2(fixtureMovV2_());
  console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_22_CONSULTAR_SAIDA_E_BLOQUEIOS() {
  const d=fixtureMovV2_(), teste=localizarTesteMovV2_();
  if (!teste) throw new Error('Execute o teste 21.');
  const r=obterMovimentacaoV2PorId(teste['ID_Movimentação']);
  if (!r || r.ID_Pessoa!==d.idPessoa || r.ID_Passagem!==d.idPassagem || r.Destino!==d.destino ||
      r['Data/Hora Prevista de Retorno']!==d.retornoPrevisto) throw new Error('Dados gravados diferentes dos esperados.');
  if (!obterMovimentacoesPessoaV2(d.idPessoa).some(function(v) { return v['ID_Movimentação']===r['ID_Movimentação']; })) {
    throw new Error('Movimentação ausente na consulta por pessoa.');
  }
  const resultado={ok:true,consultaPorPessoa:true,consultaPorPassagem:true,movimentacao:r};
  if (!r['Data/Hora Real de Retorno']) {
    let bloqueou=false;
    try { registrarSaidaV2(d); }
    catch(e) { if (String(e.message).indexOf('Já existe saída sem retorno')<0) throw e; bloqueou=true; }
    if (!bloqueou) throw new Error('Falha: segunda saída aceita sem retorno.');
    resultado.segundaSaidaBloqueada=true;
    bloqueou=false;
    try { exigirSemSaidaPendenteV2_(d.idPassagem); }
    catch(e) { if (String(e.message).indexOf('saída sem retorno')<0) throw e; bloqueou=true; }
    if (!bloqueou) throw new Error('Falha na proteção do encerramento.');
    resultado.protecaoEncerramentoValidada=true;
  } else {
    resultado.nota='Retorno já registrado. Consultas conferidas; bloqueios de pendência não repetidos.';
  }
  console.log(JSON.stringify(resultado,null,2)); return resultado;
}
function TESTE_V2_23_REGISTRAR_RETORNO() {
  const teste=localizarTesteMovV2_();
  if (!teste) throw new Error('Execute o teste 21.');
  const r=registrarRetornoV2({idMovimentacao:teste['ID_Movimentação'],retornoEfetivo:'30/09/2026 10:30',
    observacoes:'Retorno fictício confirmado no teste.'});
  const salvo=obterMovimentacaoV2PorId(teste['ID_Movimentação']);
  if (!salvo || salvo.Situacao!=='Retornado' || salvo['Data/Hora Real de Retorno']!=='30/09/2026 10:30' ||
      salvo['Observações'].indexOf(fixtureMovV2_().observacoes)<0 ||
      salvo['Observações'].indexOf('Retorno fictício confirmado no teste.')<0) {
    throw new Error('Falha no registro do retorno ou no histórico.');
  }
  exigirSemSaidaPendenteV2_(teste.ID_Passagem);
  r.semSaidasPendentes=true;
  console.log(JSON.stringify(r,null,2)); return r;
}
function TESTE_V2_24_BLOQUEAR_MOVIMENTACOES_INVALIDAS() {
  const d=fixtureMovV2_();
  const casos=[
    {nome:'Pessoa divergente',dados:{idPessoa:'PES-DIVERGENTE'},erro:'não corresponde'},
    {nome:'Hora inválida',dados:{hora:'25:00'},erro:'hora inválida'},
    {nome:'Previsão anterior à saída',dados:{retornoPrevisto:'30/09/2026 08:00'},erro:'posterior à saída'},
    {nome:'Destino vazio',dados:{destino:''},erro:'Campo obrigatório: destino'},
    {nome:'Saída anterior à entrada',dados:{data:'24/09/2026'},erro:'anterior à entrada'}
  ];
  const testes=casos.map(function(c) {
    try { validarSaidaMovV2_(Object.assign({},d,c.dados)); }
    catch(e) {
      if (String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};
      throw e;
    }
    throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const registro=localizarTesteMovV2_();
  if (!registro) throw new Error('Execute o teste 21.');
  let bloqueou=false;
  try { validarRetornoMovV2_(registro,{retornoEfetivo:'30/09/2026 08:00'}); }
  catch(e) { if (String(e.message).indexOf('Retorno anterior à saída')<0) throw e; bloqueou=true; }
  if (!bloqueou) throw new Error('Retorno anterior à saída foi aceito.');
  testes.push({teste:'Retorno anterior à saída',bloqueado:true});
  const r={ok:true,testes:testes}; console.log(JSON.stringify(r,null,2)); return r;
}
