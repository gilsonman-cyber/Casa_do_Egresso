/** Painel de indicadores. Depende de V2_Controles e Segurança. */
const V2_UI_INDICADORES = [
  ['Pessoas ativas','Pessoas com status Ativa no cadastro.','quantidade','Atendimento'],
  ['Passagens abertas','Passagens com status Aberta.','quantidade','Atendimento'],
  ['Atendimentos registrados','Todos os atendimentos registrados na base.','quantidade','Atendimento'],
  ['Encaminhamentos pendentes','Status Pendente ou Em andamento.','quantidade','Acompanhamento'],
  ['Tarefas pendentes','Status Pendente ou Em andamento.','quantidade','Acompanhamento'],
  ['Rotinas ativas','Rotinas com status Ativa, independentemente da data prevista.','quantidade','Acompanhamento'],
  ['Receitas realizadas','Entradas com status Realizado.','moeda','Financeiro'],
  ['Despesas realizadas','Saídas com status Realizado, exibidas como valor positivo.','moeda','Financeiro'],
  ['Saldo financeiro realizado','Receitas realizadas menos despesas realizadas; não é saldo bancário conciliado.','moeda','Financeiro']
];
function abrirIndicadoresV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Indicadores')
    .setWidth(920).setHeight(720),'Casa • Indicadores');
}
function prepararIndicadoresUiV2_(valores) {
  return V2_UI_INDICADORES.map(function(m){
    const valor=valores&&valores[m[0]];
    if(typeof valor!=='number'||!Number.isFinite(valor))throw new Error('Indicador ausente ou inválido: '+m[0]);
    if(m[2]==='quantidade'&&(!Number.isSafeInteger(valor)||valor<0))throw new Error('Contagem inválida: '+m[0]);
    if(m[0]!=='Saldo financeiro realizado'&&valor<0)throw new Error('Valor negativo inválido: '+m[0]);
    return {nome:m[0],descricao:m[1],valor:valor,formato:m[2],grupo:m[3]};
  });
}
function respostaIndicadoresUiV2_(r,gravado) {
  return {ok:true,indicadores:prepararIndicadoresUiV2_(r.indicadores),gravado:gravado,
    incluiDadosDeTeste:true,consultadoEm:Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm:ss'),
    fuso:configV2Core_().TIMEZONE,idLog:r.idLog||''};
}
function uiConsultarIndicadoresV2() {
  exigirAcessoPlanilhaV2_();
  return respostaIndicadoresUiV2_(consultarIndicadoresV2(),false);
}
function uiGravarIndicadoresV2() {
  exigirAcessoPlanilhaV2_();
  return respostaIndicadoresUiV2_(atualizarIndicadoresV2(),true);
}
