/** COMPRAS V2 — depende do núcleo V2 e de V2_Atendimentos.
 * Mantém os 9 cabeçalhos da aba. Valor Estimado = TOTAL da solicitação, não unitário.
 * Não registra pagamento nem altera FINANCEIRO. Quantidade pode ser fracionária.
 * Fluxo: Solicitada -> Em cotação -> Aprovada -> Comprada; cancelamento antes da compra.
 * Também permite Solicitada -> Aprovada. Aprovação é status administrativo;
 * não implementa controle de perfis EQUIPE, interface ou envio a fornecedores.
 * Estados finais não podem ser reabertos por este módulo.
 */
const V2_COM_CAMPOS=['ID_Compra','Item','Quantidade','Prioridade','Solicitante','Data Solicitação','Status','Valor Estimado','Observações'];
const V2_COM_STATUS=['Solicitada','Em cotação','Aprovada','Comprada','Cancelada'];
const V2_COM_PRIORIDADES=['Baixa','Média','Alta','Urgente'];
function textoComV2_(v){return v===undefined||v===null?'':String(v).trim();}
function seguroComV2_(v){return typeof v==='string'&&/^[=+@-]/.test(v)?"'"+v:v;}
function numeroComV2_(valor,campo,casas,permiteZero){
  const padrao=new RegExp('^\\d+(?:[.,]\\d{1,'+casas+'})?$');
  if(typeof valor!=='number'&&!(typeof valor==='string'&&padrao.test(valor.trim()))) {
    throw new Error(campo+' inválido: use número sem separador de milhar.');
  }
  const n=typeof valor==='number'?valor:Number(valor.trim().replace(',','.'));
  const fator=Math.pow(10,casas);
  if(!Number.isFinite(n)||n<0||(!permiteZero&&n===0)||n>Number.MAX_SAFE_INTEGER/fator||
    Math.abs(n*fator-Math.round(n*fator))>0.00001) throw new Error(campo+' inválido.');
  return n;
}
function valorEstimadoComV2_(v){return textoComV2_(v)===''?'':numeroComV2_(v,'Valor estimado',2,true);}
function estruturaComV2_(){
  const aba=obterAbaV2Core_('COMPRAS');if(!aba.getLastColumn()) throw new Error('COMPRAS sem cabeçalhos.');
  const cab=aba.getRange(1,1,1,aba.getLastColumn()).getDisplayValues()[0].map(textoComV2_),mapa={};
  cab.forEach(function(c,i){
    if(!c) throw new Error('Cabeçalho vazio em COMPRAS.');
    if(Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Cabeçalho duplicado: '+c);mapa[c]=i;
  });
  V2_COM_CAMPOS.forEach(function(c){if(!Object.prototype.hasOwnProperty.call(mapa,c)) throw new Error('Campo ausente: '+c);});
  return {aba:aba,cab:cab,mapa:mapa};
}
function VALIDAR_COMPRAS_V2(){
  if(typeof dataAtendimentoV2_!=='function') throw new Error('Mantenha V2_Atendimentos.gs no projeto.');
  const e=estruturaComV2_();return {ok:true,aba:'COMPRAS',camposObrigatorios:9,registros:Math.max(0,e.aba.getLastRow()-1)};
}
function registrosComV2_(){
  const e=estruturaComV2_(),n=e.aba.getLastRow()-1,lista=[],ids={};if(n<1) return lista;
  e.aba.getRange(2,1,n,e.cab.length).getValues().forEach(function(linha,i){
    if(linha.every(function(v){return textoComV2_(v)==='';})) return;
    const r={};e.cab.forEach(function(c,j){r[c]=linha[j];});
    const id=textoComV2_(r.ID_Compra);if(!id||ids[id]) throw new Error('ID_Compra ausente ou duplicado.');
    ids[id]=true;lista.push({registro:r,linha:i+2});
  });return lista;
}
function localizarComV2_(id){
  id=textoComV2_(id);if(!id) throw new Error('ID_Compra é obrigatório.');
  return registrosComV2_().filter(function(v){return v.registro.ID_Compra===id;})[0]||null;
}
function obterCompraV2PorId(id){const v=localizarComV2_(id);return v?v.registro:null;}
function listarComprasV2(filtros){
  filtros=filtros||{};
  return registrosComV2_().map(function(v){return v.registro;}).filter(function(r){
    return (!filtros.status||r.Status===filtros.status)&&(!filtros.solicitante||r.Solicitante===filtros.solicitante)&&
      (!filtros.prioridade||r.Prioridade===filtros.prioridade);
  });
}
function validarCompraComV2_(dados){
  dados=dados||{};
  ['item','solicitante'].forEach(function(c){if(!textoComV2_(dados[c])) throw new Error('Campo obrigatório: '+c);});
  const prioridade=textoComV2_(dados.prioridade)||'Média';
  if(V2_COM_PRIORIDADES.indexOf(prioridade)<0) throw new Error('Prioridade inválida.');
  const data=dataAtendimentoV2_(dados.dataSolicitacao,'Data da solicitação');
  if(data.iso>Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'yyyy-MM-dd')) throw new Error('Data da solicitação não pode ser futura.');
  return {'Item':textoComV2_(dados.item),'Quantidade':numeroComV2_(dados.quantidade,'Quantidade',3,false),
    'Prioridade':prioridade,'Solicitante':textoComV2_(dados.solicitante),'Data Solicitação':data.br,
    'Status':'Solicitada','Valor Estimado':valorEstimadoComV2_(dados.valorEstimado),'Observações':textoComV2_(dados.observacoes)};
}
function registrarCompraV2(dados){
  const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const e=estruturaComV2_(),r=validarCompraComV2_(dados);r.ID_Compra=gerarIdV2Core_('COM');
    if(localizarComV2_(r.ID_Compra)) throw new Error('ID já existente; tente novamente.');
    const n=e.aba.getLastRow()+1;
    e.aba.getRange(n,e.mapa['Data Solicitação']+1).setNumberFormat('@');
    e.aba.getRange(n,e.mapa.Quantidade+1).setNumberFormat('0.###');
    e.aba.getRange(n,e.mapa['Valor Estimado']+1).setNumberFormat('0.00');
    e.aba.getRange(n,1,1,e.cab.length).setValues([e.cab.map(function(c){return seguroComV2_(r[c]===undefined?'':r[c]);})]);
    SpreadsheetApp.flush();return {ok:true,compra:r};
  }finally{lock.releaseLock();}
}
function atualizarCompraV2(dados){
  dados=dados||{};const lock=LockService.getScriptLock();lock.waitLock(20000);
  try{
    const e=estruturaComV2_(),achado=localizarComV2_(dados.idCompra);if(!achado) throw new Error('Compra não encontrada.');
    const r=achado.registro,status=textoComV2_(dados.status),nota=textoComV2_(dados.observacoes);
    if(V2_COM_STATUS.indexOf(r.Status)<0||V2_COM_STATUS.indexOf(status)<0) throw new Error('Status de compra inválido.');
    const valor=dados.valorEstimado===undefined?valorEstimadoComV2_(r['Valor Estimado']):valorEstimadoComV2_(dados.valorEstimado);
    if(status===r.Status&&valor===r['Valor Estimado']&&!nota) return {ok:true,semAlteracao:true,compra:r};
    if(['Comprada','Cancelada'].indexOf(r.Status)>=0) throw new Error('Compra finalizada; alteração não permitida.');
    const permitidos={'Solicitada':['Solicitada','Em cotação','Aprovada','Cancelada'],
      'Em cotação':['Em cotação','Aprovada','Cancelada'],'Aprovada':['Aprovada','Comprada','Cancelada']};
    if(permitidos[r.Status].indexOf(status)<0) throw new Error('Transição de compra não permitida: '+r.Status+' → '+status);
    if(!nota) throw new Error('Observação da atualização é obrigatória.');
    if(['Aprovada','Comprada'].indexOf(status)>=0&&valor==='') throw new Error('Informe o valor estimado total antes de aprovar ou concluir.');
    const hora=Utilities.formatDate(new Date(),configV2Core_().TIMEZONE,'dd/MM/yyyy HH:mm:ss');
    let texto=hora+' | '+usuarioV2Core_()+' | '+r.Status+' → '+status+'\n'+nota;
    if(valor!==r['Valor Estimado']) texto+='\nValor estimado total: '+(r['Valor Estimado']===''?'não informado':r['Valor Estimado'])+' → '+(valor===''?'não informado':valor);
    const obs=[textoComV2_(r['Observações']),texto].filter(Boolean).join('\n\n');
    e.aba.getRange(achado.linha,e.mapa['Observações']+1).setValue(seguroComV2_(obs));
    e.aba.getRange(achado.linha,e.mapa['Valor Estimado']+1).setNumberFormat('0.00').setValue(valor);
    e.aba.getRange(achado.linha,e.mapa.Status+1).setValue(status);
    SpreadsheetApp.flush();return {ok:true,compra:obterCompraV2PorId(r.ID_Compra)};
  }finally{lock.releaseLock();}
}
