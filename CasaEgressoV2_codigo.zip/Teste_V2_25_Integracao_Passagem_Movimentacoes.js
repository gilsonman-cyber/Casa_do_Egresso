/** Adicionar ao mesmo projeto e executar somente TESTE_V2_25_INTEGRACAO_PASSAGEM_MOVIMENTACOES.
 * Cria uma passagem e uma pasta de teste para PESSOA TESTE V2 e uma movimentação.
 * Confirma bloqueio chamando encerrarPassagemV2 de verdade. Depois registra retorno
 * e encerra a passagem fictícia. Não exclui registros nem arquivos.
 * Reexecução reaproveita os registros identificados pelo marcador exclusivo.
 */
function TESTE_V2_25_INTEGRACAO_PASSAGEM_MOVIMENTACOES() {
  const marcador='[TESTE-INTEGRADO-V2-25]';
  const pessoa=obterPessoaV2PorId_('PES-F1C07550EC5D');
  if (!pessoa || pessoa['Nome Completo']!=='PESSOA TESTE V2' ||
      normalizarCPFV2Core_(pessoa.CPF)!=='52998224725') {
    throw new Error('Pessoa fictícia não confirmada. Nenhuma passagem foi criada.');
  }
  VALIDAR_MOVIMENTACOES_V2();
  const candidatas=obterPassagensPessoaV2(pessoa.ID_Pessoa).filter(function(p) {
    return p['Motivo / Objetivo']===marcador;
  });
  if (candidatas.length>1) throw new Error('Mais de uma passagem com o marcador deste teste.');
  let passagem=candidatas[0]||null;
  const aberta=obterPassagemAbertaV2_(pessoa.ID_Pessoa);
  if (aberta && (!passagem || aberta.ID_Passagem!==passagem.ID_Passagem)) {
    throw new Error('Já existe outra passagem aberta para a pessoa de teste. Ela não será alterada.');
  }
  const timezone=configV2Core_().TIMEZONE;
  const formatar=function(d,formato) { return Utilities.formatDate(d,timezone,formato); };
  if (!passagem) {
    // Entrada dois minutos antes de agora, para permitir saída fictícia no passado.
    const inicio=new Date(Date.now()-120000);
    passagem=abrirPassagemV2({idPessoa:pessoa.ID_Pessoa,
      dataEntrada:formatar(inicio,'dd/MM/yyyy'),tipo:'Teste de integração',modalidade:'Teste',
      motivoObjetivo:marcador,quarto:'Teste',responsavel:'Responsável Teste',
      observacoesEntrada:marcador+' Passagem fictícia para validar bloqueio de encerramento.'}).passagem;
  }
  const movimentos=obterMovimentacoesPassagemV2(passagem.ID_Passagem);
  if (movimentos.some(function(m) { return m.Motivo!==marcador; }) || movimentos.length>1) {
    throw new Error('Passagem contém movimentações inesperadas. Teste interrompido.');
  }
  let movimento=movimentos[0]||null;
  if (passagem.Status==='Encerrada') {
    if (!movimento || movimento.Situacao!=='Retornado' ||
        String(passagem['Observações']).indexOf(marcador+' Integração concluída após retorno.')<0) {
      throw new Error('Passagem de teste encerrada sem conclusão esperada. Não reabra nem exclua os registros; envie este erro.');
    }
    const resumo={ok:true,reutilizado:true,nota:'Teste já concluído; esta execução apenas conferiu os registros.',
      idPassagem:passagem.ID_Passagem,idMovimentacao:movimento['ID_Movimentação'],
      statusFinal:passagem.Status,situacaoFinal:movimento.Situacao};
    console.log(JSON.stringify(resumo,null,2)); return resumo;
  }
  if (passagem.Status!=='Aberta') throw new Error('Passagem do teste não está aberta.');
  if (!movimento) {
    const saida=new Date(Date.now()-60000), previsao=new Date(Date.now()+1800000);
    movimento=registrarSaidaV2({idPessoa:pessoa.ID_Pessoa,idPassagem:passagem.ID_Passagem,
      data:formatar(saida,'dd/MM/yyyy'),hora:formatar(saida,'HH:mm'),
      retornoPrevisto:formatar(previsao,'dd/MM/yyyy HH:mm'),destino:'Destino fictício',
      motivo:marcador,observacoes:marcador+' Saída fictícia.'}).movimentacao;
  }
  let bloqueioConfirmado=false;
  if (!movimento['Data/Hora Real de Retorno']) {
    const antes=obterPassagemV2PorId_(passagem.ID_Passagem);
    let mensagem='';
    try {
      encerrarPassagemV2({idPassagem:passagem.ID_Passagem,
        dataSaidaEfetiva:formatar(new Date(),'dd/MM/yyyy'),
        observacoesSaida:marcador+' Esta tentativa deveria ser bloqueada.'});
    } catch(e) { mensagem=String(e.message||e); }
    if (!mensagem) {
      throw new Error('FALHA: encerrarPassagemV2 encerrou a passagem com saída pendente. Confira a chamada exigirSemSaidaPendenteV2_. O teste parou; envie este erro.');
    }
    if (mensagem.indexOf('Passagem possui saída sem retorno')<0) {
      throw new Error('O encerramento falhou por outro motivo, não pela proteção esperada: '+mensagem);
    }
    const depois=obterPassagemV2PorId_(passagem.ID_Passagem);
    if (JSON.stringify(antes)!==JSON.stringify(depois)) {
      throw new Error('O bloqueio ocorreu, mas alterou dados da passagem.');
    }
    bloqueioConfirmado=true;
    console.log('BLOQUEIO CONFIRMADO: encerramento recusado e passagem preservada.');
    movimento=registrarRetornoV2({idMovimentacao:movimento['ID_Movimentação'],
      retornoEfetivo:formatar(new Date(),'dd/MM/yyyy HH:mm'),
      observacoes:marcador+' Retorno após confirmação do bloqueio.'}).movimentacao;
  } else {
    // Permite retomar somente se a rodada anterior passou pelo bloqueio e registrou retorno.
    if (String(movimento['Observações']).indexOf(marcador+' Retorno após confirmação do bloqueio.')<0) {
      throw new Error('Retorno existente sem evidência da etapa de bloqueio.');
    }
    bloqueioConfirmado=true;
  }
  const encerrada=encerrarPassagemV2({idPassagem:passagem.ID_Passagem,
    dataSaidaEfetiva:formatar(new Date(),'dd/MM/yyyy'),
    observacoesSaida:marcador+' Integração concluída após retorno.'});
  const finalMov=obterMovimentacaoV2PorId(movimento['ID_Movimentação']);
  if (encerrada.Status!=='Encerrada' || finalMov.Situacao!=='Retornado' ||
      String(encerrada['Observações']).indexOf('Passagem fictícia para validar bloqueio')<0 ||
      String(encerrada['Observações']).indexOf(marcador+' Integração concluída após retorno.')<0) {
    throw new Error('Resultado final ou preservação do histórico diferente do esperado.');
  }
  const resultado={ok:true,bloqueioEncerramentoConfirmado:bloqueioConfirmado,
    idPessoa:pessoa.ID_Pessoa,idPassagem:encerrada.ID_Passagem,
    idMovimentacao:finalMov['ID_Movimentação'],statusFinal:encerrada.Status,
    situacaoFinal:finalMov.Situacao,observacoesPreservadas:true};
  console.log(JSON.stringify(resultado,null,2)); return resultado;
}
