/** Execute 26 a 30. Produz somente dois eventos fictícios na aba VISITANTES. */
function fixtureVisV2_(){
  const pessoa=obterPessoaV2PorId_('PES-F1C07550EC5D');
  if(!pessoa||pessoa['Nome Completo']!=='PESSOA TESTE V2') throw new Error('Pessoa fictícia não confirmada.');
  return {idPessoa:pessoa.ID_Pessoa,nomeVisitante:'VISITANTE TESTE V2',documento:'DOC-TESTE-VIS-V2-01',
    data:'30/09/2026',hora:'09:30',destinoMotivo:'[TESTE-VIS-V2-01] Visita fictícia',observacoes:'Entrada fictícia para validação.'};
}
function entradaTesteVisV2_(){
  const d=fixtureVisV2_(),lista=obterRegistrosVisitanteV2(d.documento);
  if(lista.some(function(r){return r['Nome do Visitante']!==d.nomeVisitante||r['Destino / Motivo']!==d.destinoMotivo;})||lista.length>2){
    throw new Error('Histórico inesperado para o documento fictício.');
  }
  return lista[0]||null;
}
function TESTE_V2_26_VALIDAR_VISITANTES(){
  const r=VALIDAR_VISITANTES_V2();console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_27_REGISTRAR_ENTRADA_VISITANTE(){
  const existente=entradaTesteVisV2_();
  const r=existente?{ok:true,reutilizado:true,entrada:existente}:registrarEntradaVisitanteV2(fixtureVisV2_());
  console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_28_CONSULTAR_VISITANTE_E_BLOQUEIO(){
  const entrada=entradaTesteVisV2_(),d=fixtureVisV2_();
  if(!entrada) throw new Error('Execute o teste 27.');
  const registro=obterRegistroVisitanteV2PorId(entrada.ID_Visitante);
  if(!registro||registro.ID_Pessoa!==d.idPessoa||registro.Documento!==d.documento||registro['Pessoa Visitada']!=='PESSOA TESTE V2') {
    throw new Error('Dados da entrada diferentes dos esperados.');
  }
  if(!obterRegistrosVisitantesPessoaV2(d.idPessoa).some(function(r){return r.ID_Visitante===entrada.ID_Visitante;})) {
    throw new Error('Registro ausente na consulta por pessoa visitada.');
  }
  const historico=obterRegistrosVisitanteV2(d.documento);
  const presente=obterVisitantesPresentesV2().some(function(r){return r.ID_Visitante===entrada.ID_Visitante;});
  const resultado={ok:true,consultaPorPessoa:true,entrada:registro,presente:presente};
  if(historico.length===1){
    if(!presente) throw new Error('Visitante deveria constar como presente.');
    let bloqueado=false;
    try{registrarEntradaVisitanteV2(d);}catch(e){
      if(String(e.message).indexOf('entrada sem saída')<0) throw e;bloqueado=true;
    }
    if(!bloqueado) throw new Error('Segunda entrada foi aceita sem saída.');
    resultado.segundaEntradaBloqueada=true;
  }else if(presente){throw new Error('Visitante com saída ainda consta como presente.');}
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_29_REGISTRAR_SAIDA_VISITANTE(){
  const entrada=entradaTesteVisV2_();if(!entrada) throw new Error('Execute o teste 27.');
  const r=registrarSaidaVisitanteV2({idEntrada:entrada.ID_Visitante,data:'30/09/2026',hora:'10:00',observacoes:'Saída fictícia confirmada.'});
  const salvo=obterRegistroVisitanteV2PorId(r.saida.ID_Visitante);
  const original=obterRegistroVisitanteV2PorId(entrada.ID_Visitante);
  if(!salvo||salvo['Movimentação']!=='Saída'||salvo.ID_Visitante===entrada.ID_Visitante||salvo.Hora!=='10:00'||
    original['Observações']!==fixtureVisV2_().observacoes||obterRegistrosVisitanteV2(entrada.Documento).length!==2) {
    throw new Error('Falha na gravação da saída ou preservação da entrada.');
  }
  if(obterVisitantesPresentesV2().some(function(v){return documentoVisV2_(v.Documento)===documentoVisV2_(entrada.Documento);})) {
    throw new Error('Visitante ainda consta como presente.');
  }
  r.entradaPreservada=true;r.visitantePresente=false;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_30_BLOQUEAR_VISITANTES_INVALIDOS(){
  const d=fixtureVisV2_(),casos=[
    {nome:'Nome vazio',dados:{nomeVisitante:''},erro:'Campo obrigatório: nomeVisitante'},
    {nome:'Documento vazio',dados:{documento:''},erro:'Campo obrigatório: documento'},
    {nome:'Pessoa inexistente',dados:{idPessoa:'PES-INEXISTENTE-TESTE'},erro:'Pessoa visitada não encontrada'},
    {nome:'Hora inválida',dados:{hora:'25:70'},erro:'hora inválida'},
    {nome:'Data inexistente',dados:{data:'31/02/2026'},erro:'data inválida'}
  ];
  const testes=casos.map(function(c){
    try{validarEntradaVisV2_(Object.assign({},d,c.dados));}catch(e){
      if(String(e.message).indexOf(c.erro)>=0) return {teste:c.nome,bloqueado:true};throw e;
    }throw new Error('Dados inválidos aceitos: '+c.nome);
  });
  const entrada=entradaTesteVisV2_();if(!entrada) throw new Error('Execute o teste 27.');
  let bloqueado=false;
  try{registrarSaidaVisitanteV2({idEntrada:entrada.ID_Visitante,data:'30/09/2026',hora:'09:00'});}catch(e){
    if(String(e.message).indexOf('Saída anterior à entrada')<0) throw e;bloqueado=true;
  }
  if(!bloqueado) throw new Error('Saída anterior à entrada foi aceita.');
  testes.push({teste:'Saída anterior à entrada',bloqueado:true});
  const r={ok:true,testes:testes};console.log(JSON.stringify(r,null,2));return r;
}
