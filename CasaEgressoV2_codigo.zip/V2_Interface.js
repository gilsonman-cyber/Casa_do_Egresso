/** Painel administrativo: registros internos; não realiza pagamentos. */
function abrirAdministrativoV2() {
  exigirAcessoPlanilhaV2_();
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutputFromFile('V2_Painel_Administrativo')
    .setWidth(920).setHeight(720),'Casa • Administrativo');
}
function dadosAdmUiV2_(dados,campos) {
  dados=dados||{};const r={};
  campos.forEach(function(c){if(dados[c]===undefined)return;
    const v=String(dados[c]===null?'':dados[c]).trim();
    if(v.length>5000)throw new Error(c+': máximo de 5000 caracteres.');r[c]=v;
  });return r;
}
function serializarAdmUiV2_(lista) {
  return lista.map(function(r){const c=Object.assign({},r);
    if(c['Data Solicitação'])c['Data Solicitação']=dataAtendimentoV2_(c['Data Solicitação'],'Data Solicitação').br;
    return serializarAcompV2_([c])[0];});
}
function uiConsultarAdministrativoV2(dados) {
  exigirAcessoPlanilhaV2_();const d=dadosAdmUiV2_(dados,['dataInicio','dataFim']);
  return {ok:true,financeiro:serializarAdmUiV2_(listarLancamentosFinanceirosV2(d)),
    resumo:resumoFinanceiroV2(d),compras:serializarAdmUiV2_(listarComprasV2({}))};
}
function uiRegistrarFinanceiroV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['data','tipo','categoria','descricao','valor','responsavel','status','idComprovanteDrive']);
  if(d.idComprovanteDrive)d.idComprovanteDrive=idArquivoUiDocV2_(d.idComprovanteDrive);
  const r=registrarLancamentoFinanceiroV2(d);
  return {ok:true,id:r.lancamento.ID_Lancamento,mensagem:'Lançamento registrado.'};
}
function uiAtualizarFinanceiroV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['idLancamento','status','motivo','dataEfetiva']);
  const r=atualizarStatusFinanceiroV2(d);
  return {ok:true,id:r.lancamento.ID_Lancamento,semAlteracao:!!r.semAlteracao,mensagem:'Lançamento atualizado.'};
}
function uiRegistrarCompraV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['item','quantidade','prioridade','solicitante','dataSolicitacao','valorEstimado','observacoes']);
  const r=registrarCompraV2(d);
  return {ok:true,id:r.compra.ID_Compra,mensagem:'Solicitação de compra registrada.'};
}
function uiAtualizarCompraV2(dados) {
  exigirAcessoPlanilhaV2_();
  const d=dadosAdmUiV2_(dados,['idCompra','status','valorEstimado','observacoes']);
  const r=atualizarCompraV2(d);
  return {ok:true,id:r.compra.ID_Compra,semAlteracao:!!r.semAlteracao,mensagem:'Compra atualizada.'};
}

function uiInicioV2() {
  const c = exigirAcessoPlanilhaV2_();

  return {
    ok: true,
    usuario: c.usuario.email,
    hoje: Utilities.formatDate(
      new Date(),
      configV2Core_().TIMEZONE,
      'yyyy-MM-dd'
    )
  };
}
