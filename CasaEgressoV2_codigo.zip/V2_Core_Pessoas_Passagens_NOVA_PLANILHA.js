/**
 * CASA DO EGRESSO - V2
 * Núcleo: PESSOAS + PASSAGENS
 *
 * Este módulo trabalha exclusivamente com a nova planilha-base V2.
 * As abas PESSOAS e PASSAGENS já existem; este núcleo não as recria:
 *   PESSOA = identidade permanente
 *   PASSAGEM = cada permanência/retorno da pessoa
 *
 * Substitua o núcleo V2 anterior por este arquivo.
 * Ele não utiliza a CONFIG da V1.
 */

const CONFIG_V2_CORE = {
  // PLANILHA OFICIAL DO V2 — NÃO ALTERAR PARA A V1
  SPREADSHEET_ID: '1w1016P49nJJ-nUgXBZFODBtWUt5SsB5GcYmJ7q0gBxw',
  PASTA_MAE_ID: '17XOAx3qnG8302hgTIIZCnBnCqCyPY8DW',
  NOME_PASTA_ACOLHIDOS: '01 - ACOLHIDOS',
  TIMEZONE: 'America/Sao_Paulo'
};

const SCHEMAS_V2_CORE = {
  PESSOAS: [
    'ID_Pessoa','Nome Completo','Nome Social / Alcunha','CPF','RG',
    'Data de Nascimento','Nome da Mãe','Gênero','Telefone','Contato de Emergência',
    'Escolaridade','Profissões / Habilidades','Interesse em Cursos',
    'Informações Familiares','Observações Gerais','ID_Pasta_Drive','Link_Pasta_Drive',
    'Data de Cadastro','Status da Pessoa','Criado_Por','Atualizado_Em',
    'Atualizado_Por','Versao'
  ],

  PASSAGENS: [
    'ID_Passagem','ID_Pessoa','Data de Entrada','Data de Saída Prevista',
    'Data de Saída Efetiva','Tipo','Motivo / Objetivo','Modalidade','Quarto',
    'Responsável','Status','ID_Pasta_Drive','Link_Pasta_Drive','Observações',
    'Criado_Em','Criado_Por','Atualizado_Em','Atualizado_Por','Versao'
  ]
};

const V2_STATUS_PESSOA = 'Ativa';
const V2_STATUS_PASSAGEM_ABERTA = 'Aberta';
const V2_STATUS_PASSAGEM_ENCERRADA = 'Encerrada';
const V2_STATUS_PASSAGEM_CANCELADA = 'Cancelada';


/**
 * Dependências locais da V2.
 * O primeiro arquivo que fiz assumia que estas funções já estavam no projeto.
 * Para evitar esse acoplamento, a V2 agora possui seus próprios acessos.
 */
function configV2Core_() {
  return CONFIG_V2_CORE;
}

function obterSpreadsheetV2Core_() {
  return exigirAcessoPlanilhaV2_().planilha;
}

function encontrarSubpastaExataV2Core_(pai, nome) {
  const it = pai.getFoldersByName(nome);
  return it.hasNext() ? it.next() : null;
}

function obterPastaAcolhidosV2Core_() {
  const cfg = configV2Core_();
  const mae = DriveApp.getFolderById(cfg.PASTA_MAE_ID);
  let pasta = encontrarSubpastaExataV2Core_(mae, cfg.NOME_PASTA_ACOLHIDOS);
  if (!pasta) pasta = mae.createFolder(cfg.NOME_PASTA_ACOLHIDOS);
  return pasta;
}

/** Cria as duas novas estruturas sem alterar as abas antigas. */
function CONFIGURAR_NUCLEO_V2() {
  // A nova planilha já possui a estrutura oficial. Esta função apenas valida.
  return VALIDAR_NUCLEO_V2();
}

function obterAbaV2Core_(nomeAba) {
  const ss = obterSpreadsheetV2Core_();
  const aba = ss.getSheetByName(nomeAba);
  if (!aba) {
    throw new Error(
      'Aba "' + nomeAba + '" não encontrada. Execute CONFIGURAR_NUCLEO_V2() primeiro.'
    );
  }
  return aba;
}

function mapaCabecalhosV2Core_(aba) {
  const ultimaColuna = aba.getLastColumn();
  if (!ultimaColuna) return {};

  const cabecalhos = aba.getRange(1, 1, 1, ultimaColuna).getDisplayValues()[0];
  const mapa = {};

  cabecalhos.forEach(function(cabecalho, indice) {
    if (cabecalho) mapa[String(cabecalho).trim()] = indice + 1;
  });

  return mapa;
}

function linhaComoObjetoV2Core_(aba, linha) {
  const mapa = mapaCabecalhosV2Core_(aba);
  const valores = aba.getRange( linha, 1, 1, aba.getLastColumn()).getValues()[0];
  const obj = {};

  Object.keys(mapa).forEach(function(campo) {
    obj[campo] = valores[mapa[campo] - 1];
  });

  return obj;
}

function normalizarCPFV2Core_(cpf) {
  const valor = String(cpf || '').replace(/\D/g, '');
  return valor;
}

function validarCPFV2Core_(cpf) {
  const valor = normalizarCPFV2Core_(cpf);

  if (valor.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(valor)) return false;

  let soma = 0;
  for (let i = 0; i < 9; i++) soma += Number(valor.charAt(i)) * (10 - i);
  let digito1 = 11 - (soma % 11);
  if (digito1 >= 10) digito1 = 0;
  if (digito1 !== Number(valor.charAt(9))) return false;

  soma = 0;
  for (let i = 0; i < 10; i++) soma += Number(valor.charAt(i)) * (11 - i);
  let digito2 = 11 - (soma % 11);
  if (digito2 >= 10) digito2 = 0;

  return digito2 === Number(valor.charAt(10));
}

function usuarioV2Core_() {
  return exigirAcessoPlanilhaV2_().usuario.email;
}

function gerarIdV2Core_(prefixo) {
  try {
    if (typeof gerarId_ === 'function') return gerarId_(prefixo);
  } catch (e) {}

  return prefixo + '-' + Utilities.getUuid().replace(/-/g, '').substring(0, 12).toUpperCase();
}

function formatarDataV2Core_(valor) {
  if (!valor) return '';

  if (Object.prototype.toString.call(valor) === '[object Date]' && !isNaN(valor.getTime())) {
    return Utilities.formatDate(valor, configV2Core_().TIMEZONE, 'dd/MM/yyyy');
  }

  const texto = String(valor).trim();
  if (!texto) return '';

  // Mantém dd/MM/yyyy.
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(texto)) return texto;

  // Converte yyyy-MM-dd sem depender do fuso do navegador.
  const match = texto.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (match) return match[3] + '/' + match[2] + '/' + match[1];

  return texto;
}

function obterPessoaV2PorId_(idPessoa) {
  const id = String(idPessoa || '').trim();
  if (!id) return null;

  const aba = obterAbaV2Core_('PESSOAS');
  const mapa = mapaCabecalhosV2Core_(aba);
  const ultimaLinha = aba.getLastRow();
  if (ultimaLinha < 2) return null;

  const valores = aba.getRange(2, 1, ultimaLinha - 1, aba.getLastColumn()).getValues();
  let encontrada = null;

  valores.forEach(function(linha, indice) {
    const valorId = String(linha[mapa['ID_Pessoa'] - 1] || '').trim();
    if (valorId === id) {
      if (encontrada) {
        throw new Error('Existem duas pessoas com o mesmo ID_Pessoa: ' + id);
      }
      encontrada = linhaComoObjetoV2Core_(aba, indice + 2);
      encontrada._linha = indice + 2;
    }
  });

  return encontrada;
}

function obterPessoaV2PorCPF_(cpf) {
  const cpfNormalizado = normalizarCPFV2Core_(cpf);
  if (!cpfNormalizado) return null;

  const aba = obterAbaV2Core_('PESSOAS');
  const mapa = mapaCabecalhosV2Core_(aba);
  const ultimaLinha = aba.getLastRow();
  if (ultimaLinha < 2) return null;

  const valores = aba.getRange(2, 1, ultimaLinha - 1, aba.getLastColumn()).getValues();
  let encontrada = null;

  valores.forEach(function(linha, indice) {
    const cpfLinha = normalizarCPFV2Core_(linha[mapa['CPF'] - 1]);

    if (cpfLinha === cpfNormalizado) {
      if (encontrada) {
        throw new Error('CPF duplicado na aba PESSOAS: ' + cpfNormalizado);
      }
      encontrada = linhaComoObjetoV2Core_(aba, indice + 2);
      encontrada._linha = indice + 2;
    }
  });

  return encontrada;
}

function obterOuCriarPastaPessoaV2_(idPessoa, nomeCompleto, cpf) {
  // Reaproveita a raiz já usada pelo sistema atual.
  const raiz = obterPastaAcolhidosV2Core_();
  const nomeSeguro = String(nomeCompleto || 'SEM NOME')
    .replace(/[\\/:*?"<>|]/g, '-')
    .trim();
  const cpfSeguro = normalizarCPFV2Core_(cpf);
  const nomePasta = (cpfSeguro || idPessoa) + ' - ' + nomeSeguro;

  let pasta = encontrarSubpastaExataV2Core_(raiz, nomePasta);
  if (!pasta) pasta = raiz.createFolder(nomePasta);

  const subpastas = [
    '01 - Documentos Pessoais',
    '02 - Documentos Institucionais',
    '03 - Passagens',
    '04 - Relatórios'
  ];

  subpastas.forEach(function(nome) {
    if (!encontrarSubpastaExataV2Core_(pasta, nome)) {
      pasta.createFolder(nome);
    }
  });

  return pasta;
}

function localizarOuCriarPessoaV2_(dados) {
  const cpf = normalizarCPFV2Core_(dados.cpf || dados.CPF);

  if (!cpf) {
    throw new Error('CPF é obrigatório para localizar/criar a pessoa.');
  }

  if (!validarCPFV2Core_(cpf)) {
    throw new Error('CPF inválido.');
  }

  // Primeiro procura a pessoa já cadastrada.
  const existente = obterPessoaV2PorCPF_(cpf);

  if (existente) {
    return existente;
  }

  // O nome é necessário somente para uma pessoa nova.
  const nome = String(
    dados.nomeCompleto || dados.nome || dados['Nome Completo'] || ''
  ).trim();

  if (!nome) {
    throw new Error('Nome Completo é obrigatório para cadastrar uma nova pessoa.');
  }

  return criarPessoaV2(dados);
}

/**
 * Cria uma identidade permanente.
 * Se o CPF já existir, a função não cria duplicata: retorna a pessoa existente.
 */
function criarPessoaV2(dados) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);

  try {
    const cpf = normalizarCPFV2Core_(dados.cpf || dados.CPF);
    const nome = String(dados.nomeCompleto || dados.nome || dados['Nome Completo'] || '').trim();

    if (!nome) throw new Error('Nome Completo é obrigatório.');
    if (!cpf) throw new Error('CPF é obrigatório.');
    if (!validarCPFV2Core_(cpf)) throw new Error('CPF inválido.');

    const existente = obterPessoaV2PorCPF_(cpf);
    if (existente) return existente;

    const idPessoa = gerarIdV2Core_('PES');
    const pasta = obterOuCriarPastaPessoaV2_(idPessoa, nome, cpf);
    const agora = new Date();
    const usuario = usuarioV2Core_();

    const registro = {
      'ID_Pessoa': idPessoa,
      'Nome Completo': nome,
      'Nome Social / Alcunha': dados.nomeSocial || dados['Nome Social / Alcunha'] || '',
      'CPF': cpf,
      'RG': dados.rg || dados.RG || '',
      'Data de Nascimento': formatarDataV2Core_(dados.dataNascimento || dados['Data de Nascimento']),
      'Nome da Mãe': dados.nomeMae || dados['Nome da Mãe'] || '',
      'Gênero': dados.genero || dados.Gênero || '',
      'Telefone': dados.telefone || dados.Telefone || '',
      'Contato de Emergência': dados.contatoEmergencia || dados['Contato de Emergência'] || '',
      'Escolaridade': dados.escolaridade || dados.Escolaridade || '',
      'Profissões / Habilidades': dados.profissoesHabilidades || dados['Profissões / Habilidades'] || '',
      'Interesse em Cursos': dados.interesseCursos || dados['Interesse em Cursos'] || '',
      'Informações Familiares': dados.informacoesFamiliares || dados['Informações Familiares'] || dados.redeApoio || dados['Rede de Apoio'] || '',
      'Observações Gerais': dados.observacoesGerais || dados['Observações Gerais'] || '',
      'ID_Pasta_Drive': pasta.getId(),
      'Link_Pasta_Drive': pasta.getUrl(),
      'Data de Cadastro': agora,
      'Status da Pessoa': V2_STATUS_PESSOA,
      'Criado_Por': usuario,
      'Atualizado_Em': agora,
      'Atualizado_Por': usuario,
      'Versao': 1
    };

    const aba = obterAbaV2Core_('PESSOAS');
    const mapa = mapaCabecalhosV2Core_(aba);
    const linha = SCHEMAS_V2_CORE.PESSOAS.map(function(campo) {
      return registro[campo] !== undefined ? registro[campo] : '';
    });

    aba.getRange(aba.getLastRow() + 1, 1, 1, linha.length).setValues([linha]);

    return registro;
  } finally {
    lock.releaseLock();
  }
}

function obterPassagemV2PorId_(idPassagem) {
  const id = String(idPassagem || '').trim();
  if (!id) return null;

  const aba = obterAbaV2Core_('PASSAGENS');
  const mapa = mapaCabecalhosV2Core_(aba);
  const ultimaLinha = aba.getLastRow();
  if (ultimaLinha < 2) return null;

  const valores = aba.getRange(2, 1, ultimaLinha - 1, aba.getLastColumn()).getValues();
  let encontrada = null;

  valores.forEach(function(linha, indice) {
    const idLinha = String(linha[mapa['ID_Passagem'] - 1] || '').trim();
    if (idLinha === id) {
      if (encontrada) throw new Error('ID_Passagem duplicado: ' + id);
      encontrada = linhaComoObjetoV2Core_(aba, indice + 2);
      encontrada._linha = indice + 2;
    }
  });

  return encontrada;
}

function obterPassagemAbertaV2_(idPessoa) {
  const aba = obterAbaV2Core_('PASSAGENS');
  const mapa = mapaCabecalhosV2Core_(aba);
  const ultimaLinha = aba.getLastRow();
  if (ultimaLinha < 2) return null;

  const valores = aba.getRange(2, 1, ultimaLinha - 1, aba.getLastColumn()).getValues();
  let aberta = null;

  valores.forEach(function(linha, indice) {
    const pessoaLinha = String(linha[mapa['ID_Pessoa'] - 1] || '').trim();
    const status = String(linha[mapa['Status'] - 1] || '').trim();

    if (pessoaLinha === String(idPessoa).trim() && status === V2_STATUS_PASSAGEM_ABERTA) {
      if (aberta) {
        throw new Error('A pessoa possui mais de uma passagem aberta: ' + idPessoa);
      }
      aberta = linhaComoObjetoV2Core_(aba, indice + 2);
      aberta._linha = indice + 2;
    }
  });

  return aberta;
}

function obterPassagensPessoaV2(idPessoa) {
  const pessoa = obterPessoaV2PorId_(idPessoa);
  if (!pessoa) throw new Error('Pessoa não encontrada: ' + idPessoa);

  const aba = obterAbaV2Core_('PASSAGENS');
  const mapa = mapaCabecalhosV2Core_(aba);
  const ultimaLinha = aba.getLastRow();
  if (ultimaLinha < 2) return [];

  const valores = aba.getRange(2, 1, ultimaLinha - 1, aba.getLastColumn()).getValues();
  const resultado = [];

  valores.forEach(function(linha, indice) {
    if (String(linha[mapa['ID_Pessoa'] - 1] || '').trim() === String(idPessoa).trim()) {
      const registro = linhaComoObjetoV2Core_(aba, indice + 2);
      registro._linha = indice + 2;
      resultado.push(registro);
    }
  });

  return resultado;
}

function proximaPastaPassagemV2_(pessoa) {
  const pastaPessoa = DriveApp.getFolderById(pessoa['ID_Pasta_Drive']);
  const pastaPassagens = encontrarSubpastaExataV2Core_(pastaPessoa, '03 - Passagens') ||
    pastaPessoa.createFolder('03 - Passagens');

  const existentes = pastaPassagens.getFolders();
  let maior = 0;

  while (existentes.hasNext()) {
    const nome = existentes.next().getName();
    const m = nome.match(/^(\d{3})\s-/);
    if (m) maior = Math.max(maior, Number(m[1]));
  }

  return {
    pasta: pastaPassagens,
    numero: maior + 1
  };
}

function criarPastaPassagemV2_(pessoa, dataEntrada) {
  const info = proximaPastaPassagemV2_(pessoa);
  const data = formatarDataV2Core_(dataEntrada) ||
    Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'dd/MM/yyyy');
  const nomePasta = String(info.numero).padStart(3, '0') + ' - ' + data.replace(/\//g, '-');
  const pasta = info.pasta.createFolder(nomePasta);

  return {
    id: pasta.getId(),
    url: pasta.getUrl(),
    nome: nomePasta
  };
}

/**
 * Abre uma nova passagem.
 * Regra central:
 *   CPF encontrado -> reutiliza PESSOA
 *   CPF não encontrado -> cria PESSOA
 *   em ambos os casos -> cria nova PASSAGEM
 */
function abrirPassagemV2(dados) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);

  try {
    const dataEntrada = formatarDataV2Core_(dados.dataEntrada || dados['Data de Entrada']) ||
      Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'dd/MM/yyyy');
    const tipoPassagem = String(dados.tipoPassagem || dados.tipo || dados['Tipo'] || dados['Tipo de Passagem'] || '').trim();
    const modalidade = String(dados.modalidade || dados.Modalidade || '').trim();

    if (!tipoPassagem) throw new Error('Tipo é obrigatório.');
    if (!modalidade) throw new Error('Modalidade é obrigatória.');

    let pessoa;

    if (dados.idPessoa || dados.ID_Pessoa) {
      pessoa = obterPessoaV2PorId_(dados.idPessoa || dados.ID_Pessoa);
      if (!pessoa) throw new Error('ID_Pessoa não encontrado.');
    } else {
      pessoa = localizarOuCriarPessoaV2_(dados);
    }

    const passagemAberta = obterPassagemAbertaV2_(pessoa['ID_Pessoa']);
    if (passagemAberta) {
      throw new Error(
        'Já existe uma passagem aberta para esta pessoa: ' + passagemAberta.ID_Passagem
      );
    }

    const idPassagem = gerarIdV2Core_('PAS');
    const pastaPassagem = criarPastaPassagemV2_(pessoa, dataEntrada);
    const agora = new Date();
    const usuario = usuarioV2Core_();

    const registro = {
      'ID_Passagem': idPassagem,
      'ID_Pessoa': pessoa['ID_Pessoa'],
      'Data de Entrada': dataEntrada,
      'Data de Saída Prevista': formatarDataV2Core_(dados.dataPrevistaSaida || dados['Data de Saída Prevista'] || dados['Data Prevista de Saída']),
      'Data de Saída Efetiva': '',
      'Tipo': tipoPassagem,
      'Motivo / Objetivo': dados.motivoObjetivo || dados.motivoPassagem || dados['Motivo / Objetivo'] || dados['Motivo da Passagem'] || dados.objetivoPassagem || dados['Objetivo da Passagem'] || '',
      'Modalidade': modalidade,
      'Quarto': dados.quarto || dados.Quarto || '',
      'Responsável': dados.responsavel || dados.Responsável || '',
      'Status': V2_STATUS_PASSAGEM_ABERTA,
      'ID_Pasta_Drive': pastaPassagem.id,
      'Link_Pasta_Drive': pastaPassagem.url,
      'Observações': dados.observacoesEntrada || dados['Observações'] || dados['Observações de Entrada'] || '',
      'Criado_Em': agora,
      'Criado_Por': usuario,
      'Atualizado_Em': agora,
      'Atualizado_Por': usuario,
      'Versao': 1
    };


    const aba = obterAbaV2Core_('PASSAGENS');
    const linha = SCHEMAS_V2_CORE.PASSAGENS.map(function(campo) {
      return registro[campo] !== undefined ? registro[campo] : '';
    });

    aba.getRange(aba.getLastRow() + 1, 1, 1, linha.length).setValues([linha]);

    return {
      ok: true,
      pessoa: pessoa,
      passagem: registro,
      pastaPassagem: pastaPassagem
    };
  } finally {
    lock.releaseLock();
  }
}

/** Encerra somente a passagem indicada. Não exclui nem inativa a pessoa. */
function encerrarPassagemV2(dados) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);

  try {
    const idPassagem = String(dados.idPassagem || dados.ID_Passagem || '').trim();
    if (!idPassagem) throw new Error('ID_Passagem é obrigatório.');

    const passagem = obterPassagemV2PorId_(idPassagem);
    if (!passagem) throw new Error('Passagem não encontrada: ' + idPassagem);

    if (passagem.Status === V2_STATUS_PASSAGEM_ENCERRADA) {
      throw new Error('A passagem já está encerrada.');
    }

    if (passagem.Status === V2_STATUS_PASSAGEM_CANCELADA) {
      throw new Error('A passagem está cancelada.');
    }

    exigirSemSaidaPendenteV2_(idPassagem);

    const dataSaida = formatarDataV2Core_(dados.dataSaidaEfetiva || dados['Data de Saída Efetiva']) ||
      Utilities.formatDate(new Date(), configV2Core_().TIMEZONE, 'dd/MM/yyyy');
    const observacoes = String(
      dados.observacoesSaida || dados['Observações de Saída'] || ''
    ).trim();

    const aba = obterAbaV2Core_('PASSAGENS');
    const mapa = mapaCabecalhosV2Core_(aba);
    const linha = passagem._linha;

    aba.getRange(linha, mapa['Data de Saída Efetiva']).setValue(dataSaida);
    const observacoesAnteriores = String(passagem['Observações'] || '');

const observacoesCompletas = observacoes
  ? [
      observacoesAnteriores,
      'Encerramento em ' + dataSaida + ': ' + observacoes
    ].filter(Boolean).join('\n\n')
  : observacoesAnteriores;

aba.getRange(linha, mapa['Observações']).setValue(observacoesCompletas);;
    aba.getRange(linha, mapa['Status']).setValue(V2_STATUS_PASSAGEM_ENCERRADA);
    aba.getRange(linha, mapa['Atualizado_Em']).setValue(new Date());
    aba.getRange(linha, mapa['Atualizado_Por']).setValue(usuarioV2Core_());
    aba.getRange(linha, mapa['Versao']).setValue(Number(passagem.Versao || 1) + 1);

    return obterPassagemV2PorId_(idPassagem);
  } finally {
    lock.releaseLock();
  }
}

/** Retorna um resumo seguro para uso posterior pela interface/API. */
function obterResumoPessoaV2(idPessoa) {
  const pessoa = obterPessoaV2PorId_(idPessoa);
  if (!pessoa) throw new Error('Pessoa não encontrada: ' + idPessoa);

  const passagens = obterPassagensPessoaV2(idPessoa);
  const aberta = passagens.filter(function(p) {
    return p.Status === V2_STATUS_PASSAGEM_ABERTA;
  })[0] || null;

  return {
    pessoa: pessoa,
    passagemAberta: aberta,
    totalPassagens: passagens.length,
    passagens: passagens
  };
}

/** Validação somente de estrutura; não cria pessoas nem passagens de teste. */
function VALIDAR_NUCLEO_V2() {
  const ss = obterSpreadsheetV2Core_();
  const resultado = {};

  Object.keys(SCHEMAS_V2_CORE).forEach(function(nomeAba) {
    const aba = ss.getSheetByName(nomeAba);
    resultado[nomeAba] = {
      existe: !!aba,
      colunasEsperadas: SCHEMAS_V2_CORE[nomeAba].length,
      colunasAtuais: aba ? aba.getLastColumn() : 0,
      linhasAtuais: aba ? Math.max(aba.getLastRow() - 1, 0) : 0
    };
  });

  return resultado;
}
