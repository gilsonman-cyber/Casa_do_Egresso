/** Testes 73–75: não alteram planilha nem Drive. */
function TESTE_V2_73_VALIDAR_PAINEL_DOCUMENTOS() {
  const r=uiInicioV2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Documentos').getContent();
  ['uiConsultarDocumentosV2','uiRegistrarDocumentoV2','uiConferirDocumentoV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_74_CONSULTAR_DOCUMENTOS_INTERFACE() {
  const pessoa=uiConsultarPessoaV2('529.982.247-25');
  if(!pessoa.encontrada) throw new Error('Pessoa fictícia não encontrada.');
  const r=uiConsultarDocumentosV2({idPessoa:pessoa.pessoa.id,idPassagem:'PAS-F5E882F87A8E'});
  if(!Array.isArray(r.documentos)) throw new Error('Lista inválida.');
  const resultado={ok:true,documentos:r.documentos.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_75_VALIDAR_LINKS_E_VINCULOS_DOCUMENTOS() {
  exigirAcessoPlanilhaV2_();
  const id='ARQUIVO_TESTE-123';
  [id,'https://drive.google.com/file/d/'+id+'/view?usp=sharing',
    'https://docs.google.com/document/d/'+id+'/edit',
    'https://drive.google.com/open?id='+id].forEach(function(v){
      if(idArquivoUiDocV2_(v)!==id) throw new Error('Conversão incorreta.');});
  const testes=[];
  ['https://drive.google.com/drive/folders/PASTA','https://example.com/file/d/123','javascript:alert(1)',''].forEach(function(v){
    let erro;try{idArquivoUiDocV2_(v);}catch(e){erro=e;}
    if(!erro||erro.message.indexOf('Informe o ID')<0) throw new Error('Link inválido aceito.');
    testes.push({teste:'Referência inválida',bloqueado:true});});
  const d={idPessoa:'PESSOA-INEXISTENTE-TESTE',idPassagem:'PAS-F5E882F87A8E'};
  [uiConsultarDocumentosV2,uiRegistrarDocumentoV2,uiConferirDocumentoV2].forEach(function(f){
    let erro;try{f(d);}catch(e){erro=e;}
    if(!erro||erro.message.indexOf('Pessoa e passagem divergentes')<0) throw new Error('Vínculo inválido não bloqueado.');
    testes.push({teste:f.name,bloqueado:true});});
  const r={ok:true,linksValidosConvertidos:true,testes:testes,somenteLeitura:true};
  console.log(JSON.stringify(r,null,2));return r;
}
