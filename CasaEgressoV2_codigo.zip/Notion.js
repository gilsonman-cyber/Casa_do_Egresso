function notionRequest_(url,method,payload){
  const token=getConfig_("NOTION_TOKEN"); if(!token || token==="NAO_CONFIGURADO") throw new Error("NOTION_TOKEN ainda não configurado.");
  const opt={method:method||"get",headers:{Authorization:"Bearer "+token,"Notion-Version":"2022-06-28"},muteHttpExceptions:true};
  if(payload){opt.contentType="application/json";opt.payload=JSON.stringify(payload);}
  return UrlFetchApp.fetch(url,opt);
}
