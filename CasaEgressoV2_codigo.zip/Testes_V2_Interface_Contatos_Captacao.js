function TESTE_V2_88_VALIDAR_PAINEL_CONTATOS_CAPTACAO() {
  const r=uiInicioV2();VALIDAR_CONTATOS_CAPTACAO_V2();
  const html=HtmlService.createHtmlOutputFromFile('V2_Painel_Contatos_Captacao').getContent();
  ['uiCriarContatoV2','uiAtualizarContatoV2','uiCriarCaptacaoV2','uiStatusCaptacaoV2'].forEach(function(n){if(html.indexOf(n)<0)throw new Error('HTML incompleto: '+n);});
  r.htmlEncontrado=true;console.log(JSON.stringify(r,null,2));return r;
}
function TESTE_V2_89_CONSULTAR_CONTATOS_CAPTACAO_INTERFACE() {
  const r=uiConsultarContatosCaptacaoV2();
  if(!Array.isArray(r.contatos)||!Array.isArray(r.captacoes))throw new Error('Listas inválidas.');
  const resultado={ok:true,contatos:r.contatos.length,captacoes:r.captacoes.length,somenteLeitura:true};
  console.log(JSON.stringify(resultado,null,2));return resultado;
}
function TESTE_V2_90_VALIDAR_DADOS_CONTATOS_CAPTACAO() {
  exigirAcessoPlanilhaV2_();
  const c={nomeInstituicao:'Teste',tipo:'Teste'},p={projeto:'Teste',tipo:'Teste',instituicao:'Teste',responsavel:'Teste'};
  const casos=[['Nome vazio',function(){validarContatoRedeV2_(Object.assign({},c,{nomeInstituicao:''}));},/nomeInstituicao/],
    ['E-mail inválido',function(){validarContatoRedeV2_(Object.assign({},c,{email:'invalido'}));},/E-mail/],
    ['Instituição vazia',function(){validarCaptacaoRedeV2_(Object.assign({},p,{instituicao:''}));},/instituicao/],
    ['Valor negativo',function(){validarCaptacaoRedeV2_(Object.assign({},p,{valor:'-10'}));},/Valor/],
    ['Prazo inexistente',function(){validarCaptacaoRedeV2_(Object.assign({},p,{prazo:'31/02/2026'}));},/data inválida/]];
  const testes=casos.map(function(caso){let erro;try{caso[1]();}catch(e){erro=e;}
    if(!erro||!caso[2].test(erro.message))throw new Error('Bloqueio não confirmado: '+caso[0]);return {teste:caso[0],bloqueado:true};});
  const resultado={ok:true,testes:testes,somenteLeitura:true};console.log(JSON.stringify(resultado,null,2));return resultado;
}

