function registrarAtendimento(d){
  const u=requireRole_(["ADMIN","COORDENACAO","TECNICO"]);
  const sh=getSpreadsheet_().getSheetByName("ATENDIMENTOS"), id=newId_("ATE"), now=now_();
  const obj={"ID_Atendimento":id,"ID_Pessoa":d.ID_Pessoa,"ID_Passagem":d.ID_Passagem||"","Data":d.Data||now,"Hora":d.Hora||now,"Tipo de Atendimento":d["Tipo de Atendimento"]||"","Assunto / Motivo":d["Assunto / Motivo"]||"","Profissional / Responsável":d["Profissional / Responsável"]||u.Nome,"Registro":d.Registro||"","Resultado":d.Resultado||"","Próximos Passos":d["Próximos Passos"]||"","Status":d.Status||"Aberto","Anexos":d.Anexos||"","Usuário":u["E-mail"],"Criado_Em":now};
  appendObject_(sh,obj); log_("CRIAR","ATENDIMENTOS",id,"SUCESSO","Apps Script","Atendimento registrado"); return obj;
}
