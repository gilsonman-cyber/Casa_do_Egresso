const APP = {
  SHEETS: ["PESSOAS","PASSAGENS","ATENDIMENTOS","ENCAMINHAMENTOS","DOCUMENTOS","MOVIMENTACOES","VISITANTES","VEICULOS","TAREFAS","ROTINAS","FINANCEIRO","COMPRAS","CONTATOS","CAPTACAO","EQUIPE","CONFIG","LOG","INDICADORES","SYNC"]
};
function getConfig_(key) {
  const v = PropertiesService.getScriptProperties().getProperty(key);
  return v ? String(v).trim() : "";
}
function getSpreadsheet_() {
  const id = getConfig_("SPREADSHEET_ID");
  if (!id) throw new Error("SPREADSHEET_ID não configurado.");
  return SpreadsheetApp.openById(id);
}
function now_(){ return new Date(); }
function userEmail_(){
  return (Session.getActiveUser().getEmail() || "").trim().toLowerCase();
}
